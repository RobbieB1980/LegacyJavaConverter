package tnt.tarkovcraft.medsystem.common.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.exceptions.SimpleCommandExceptionType;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import net.minecraft.commands.CommandBuildContext;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import tnt.tarkovcraft.core.common.command.CoreTarkovcraftCommand;
import tnt.tarkovcraft.medsystem.common.health.HealthContainer;
import tnt.tarkovcraft.medsystem.common.health.HealthContainerDefinition;
import tnt.tarkovcraft.medsystem.common.health.HealthSystem;
import tnt.tarkovcraft.medsystem.common.health.LimbConfiguration;

public final class MedSystemTarkovCraftCommand {
   static final SimpleCommandExceptionType NO_VALID_TARGET_FOUND = new SimpleCommandExceptionType(
      Component.literal("No health containers found for given entity selector")
   );
   static final SimpleCommandExceptionType NO_BLOOD_DATA_FOUND = new SimpleCommandExceptionType(Component.literal("No blood data found for given entity"));
   static final SimpleCommandExceptionType UNCONSCIOUS_MODE_DISABLED = new SimpleCommandExceptionType(
      Component.literal("Unconscious mode is not allowed for given entity")
   );

   public static void create(CommandDispatcher<CommandSourceStack> dispatcher, CommandBuildContext context) {
      dispatcher.register(
         (LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)Commands.literal(
                              "tarkovcraft"
                           )
                           .then(StatusEffectSubCommand.node(context).requires(CoreTarkovcraftCommand.gameMasterOnly())))
                        .then(HurtSubCommand.node(context).requires(CoreTarkovcraftCommand.gameMasterOnly())))
                     .then(HealSubCommand.node().requires(CoreTarkovcraftCommand.gameMasterOnly())))
                  .then(BloodSubCommand.node().requires(CoreTarkovcraftCommand.gameMasterOnly())))
               .then(SetUnconsciousSubCommand.node().requires(CoreTarkovcraftCommand.gameMasterOnly())))
            .then(ReviveSubCommand.node().requires(CoreTarkovcraftCommand.gameMasterOnly()))
      );
   }

   static CompletableFuture<Suggestions> suggestAllEntityLimbs(CommandContext<CommandSourceStack> ctx, SuggestionsBuilder builder) throws CommandSyntaxException {
      Collection<? extends Entity> entities = EntityArgument.getOptionalEntities(ctx, "target");
      Set<String> suggestions = new HashSet<>();

      for (Entity entity : entities) {
         if (HealthSystem.hasCustomHealth(entity)) {
            HealthContainer container = HealthContainer.getAttached((LivingEntity)entity);
            HealthContainerDefinition definition = container.getDefinition();
            LimbConfiguration configuration = definition.limbConfiguration();
            suggestions.addAll(configuration.getLimbCodes());
         }
      }

      suggestions.forEach(builder::suggest);
      return builder.buildFuture();
   }
}
