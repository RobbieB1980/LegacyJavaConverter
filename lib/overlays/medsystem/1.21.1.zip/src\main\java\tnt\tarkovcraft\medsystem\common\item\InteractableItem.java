package tnt.tarkovcraft.medsystem.common.item;

import java.util.Locale;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.EntitySelector;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item.Properties;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.HitResult.Type;
import net.neoforged.neoforge.common.NeoForge;
import org.jspecify.annotations.Nullable;
import tnt.tarkovcraft.medsystem.MedicalSystem;
import tnt.tarkovcraft.medsystem.api.event.InteractableItemEvent;
import tnt.tarkovcraft.medsystem.common.config.MedSystemConfig;
import tnt.tarkovcraft.medsystem.common.init.MedSystemItemComponents;
import tnt.tarkovcraft.medsystem.util.InteractionHelper;

public abstract class InteractableItem extends Item {
   public InteractableItem(Properties properties) {
      super(properties);
   }

   protected static String formatUsageDuration(int time) {
      return String.format(Locale.ROOT, "%.2f", time / 20.0F);
   }

   protected abstract boolean tryInitiateExistingInteraction(ItemStack var1, InteractionTarget var2, LivingEntity var3, Player var4);

   protected abstract InteractionResult initiateInteraction(ItemStack var1, InteractionTarget.Mutable var2, LivingEntity var3, Player var4);

   protected abstract boolean updateInteraction(Level var1, ItemStack var2, InteractionTarget var3, LivingEntity var4, LivingEntity var5, int var6);

   protected abstract ItemStack finishInteraction(ItemStack var1, InteractionTarget var2, LivingEntity var3, LivingEntity var4);

   public final InteractionResult use(Level level, Player player, InteractionHand hand) {
      ItemStack itemStack = player.getItemInHand(hand);
      InteractionTarget activeInteraction = this.getActiveInteraction(itemStack);
      if (activeInteraction != null) {
         LivingEntity target = activeInteraction.getTargetLivingEntity(player);
         if (this.canUseItem(itemStack, target, player) && this.tryInitiateExistingInteraction(itemStack, activeInteraction, target, player)) {
            player.startUsingItem(hand);
            return InteractionResult.SUCCESS;
         }
      }

      LivingEntity target = this.findInteractiveTarget(itemStack, player);
      if (target == null) {
         this.resetActiveInteraction(itemStack);
         return InteractionResult.FAIL;
      }

      boolean selfInteraction = target == player;
      InteractionTarget.Mutable interaction = new InteractionTarget.Mutable(selfInteraction, selfInteraction ? 0 : target.getId(), "");
      InteractionResult result = this.initiateInteraction(itemStack, interaction, target, player);
      if (result == InteractionResult.SUCCESS) {
         this.setActiveInteraction(itemStack, interaction.toImmutable());
         player.startUsingItem(hand);
      }

      return result;
   }

   public final void onUseTick(Level level, LivingEntity livingEntity, ItemStack stack, int remainingUseDuration) {
      InteractionTarget interaction = this.getActiveInteraction(stack);
      if (interaction == null) {
         livingEntity.stopUsingItem();
      } else {
         LivingEntity target = interaction.getTargetLivingEntity(livingEntity);
         if (target == null) {
            livingEntity.stopUsingItem();
         } else if (!this.canUseItem(stack, target, livingEntity)) {
            this.cancelInteractionWithCooldown(stack, livingEntity);
         } else {
            boolean interactionTickResult = this.updateInteraction(level, stack, interaction, target, livingEntity, remainingUseDuration);
            if (!interactionTickResult) {
               this.cancelInteractionWithCooldown(stack, livingEntity);
            } else {
               if (!level.isClientSide()) {
                  boolean infinite = this.getUseDuration(stack, livingEntity) >= 72000;
                  Component label = this.getInteractionLabel(stack, interaction, target, livingEntity, remainingUseDuration, infinite);
                  if (label != null && livingEntity instanceof Player player) {
                     player.sendOverlayMessage(label);
                  }
               }
            }
         }
      }
   }

   public final void onStopUsing(ItemStack stack, LivingEntity entity, int count) {
      InteractionTarget interaction = this.getActiveInteraction(stack);
      this.onInteractionCancelled(stack, interaction, entity, count);
      if (interaction != null && this.shouldClearInteractionDataOnCancellation(stack, entity, count)) {
         this.resetActiveInteraction(stack);
      }
   }

   public final ItemStack finishUsingItem(ItemStack stack, Level level, LivingEntity livingEntity) {
      InteractionTarget interaction = this.getActiveInteraction(stack);
      LivingEntity target = interaction.getTargetLivingEntity(livingEntity);
      if (target == null) {
         this.resetActiveInteraction(stack);
         return stack;
      } else if (!this.canUseItem(stack, target, livingEntity)) {
         this.resetActiveInteraction(stack);
         return stack;
      } else {
         ItemStack result = this.finishInteraction(stack, interaction, target, livingEntity);
         this.resetActiveInteraction(result);
         InteractionHelper.addCooldown(livingEntity, result, 10);
         return result;
      }
   }

   protected boolean canUseItem(ItemStack itemStack, LivingEntity target, LivingEntity origin) {
      return target != origin && origin.distanceToSqr(target) > 10.0
         ? false
         : !(origin instanceof Player player && player.getCooldowns().isOnCooldown(itemStack));
   }

   protected boolean canInteractWithEntity(ItemStack stack, LivingEntity entity, LivingEntity origin) {
      return true;
   }

   protected boolean shouldClearInteractionDataOnCancellation(ItemStack itemStack, LivingEntity entity, int count) {
      return true;
   }

   protected void onInteractionCancelled(ItemStack itemStack, InteractionTarget activeInteraction, LivingEntity entity, int count) {
   }

   protected @Nullable Component getInteractionLabel(
      ItemStack itemStack, InteractionTarget interaction, LivingEntity target, LivingEntity origin, int time, boolean infinite
   ) {
      return null;
   }

   protected final InteractionTarget getActiveInteraction(ItemStack itemStack) {
      return (InteractionTarget)itemStack.get(MedSystemItemComponents.INTERACTION_TARGET);
   }

   protected final void setActiveInteraction(ItemStack itemStack, InteractionTarget target) {
      itemStack.set(MedSystemItemComponents.INTERACTION_TARGET, target);
   }

   protected final void resetActiveInteraction(ItemStack itemStack) {
      itemStack.remove(MedSystemItemComponents.INTERACTION_TARGET);
   }

   protected final void cancelInteractionWithCooldown(ItemStack itemStack, LivingEntity entity) {
      entity.stopUsingItem();
      this.resetActiveInteraction(itemStack);
      InteractionHelper.addCooldown(entity, itemStack, 10);
   }

   private LivingEntity findInteractiveTarget(ItemStack itemStack, LivingEntity origin) {
      double range = 3.0;
      Vec3 eye = origin.getEyePosition();
      Vec3 look = origin.getViewVector(1.0F);
      Vec3 end = eye.add(look.x * range, look.y * range, look.z * range);
      AABB aabb = origin.getBoundingBox().expandTowards(look.scale(range)).inflate(1.0, 1.0, 1.0);
      HitResult result = ProjectileUtil.getEntityHitResult(origin, eye, end, aabb, EntitySelector.LIVING_ENTITY_STILL_ALIVE, range * range);
      LivingEntity entity = null;
      if (result != null) {
         result = InteractionHelper.filterHitResult(result, eye, range);
      }

      if (result != null && result.getType() == Type.ENTITY) {
         entity = (LivingEntity)((EntityHitResult)result).getEntity();
      }

      if (entity != null && this.canUseItem(itemStack, entity, origin) && this.allowExternalInteraction(itemStack, entity, origin)) {
         return entity;
      } else {
         return this.canUseItem(itemStack, origin, origin) && this.isEventInteractionAllowed(itemStack, origin, origin) ? origin : null;
      }
   }

   private boolean isEventInteractionAllowed(ItemStack itemStack, LivingEntity entity, LivingEntity origin) {
      InteractableItemEvent.CanInteract event = (InteractableItemEvent.CanInteract)NeoForge.EVENT_BUS
         .post(new InteractableItemEvent.CanInteract(origin, entity, itemStack));
      return !event.isCanceled();
   }

   private boolean allowExternalInteraction(ItemStack itemStack, LivingEntity entity, LivingEntity origin) {
      MedSystemConfig config = MedicalSystem.getConfig();
      return config.allowThirdPartyEntityInteractions
         && this.isEventInteractionAllowed(itemStack, entity, origin)
         && this.canInteractWithEntity(itemStack, entity, origin);
   }
}
