package tnt.tarkovcraft.medsystem.common.effect.group;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.function.Consumer;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.ComponentSerialization;
import net.minecraft.tags.TagKey;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import tnt.tarkovcraft.medsystem.api.heal.SideEffect;
import tnt.tarkovcraft.medsystem.common.effect.StatusEffect;
import tnt.tarkovcraft.medsystem.common.effect.StatusEffectContext;
import tnt.tarkovcraft.medsystem.common.effect.StatusEffectType;
import tnt.tarkovcraft.medsystem.common.effect.util.EffectType;
import tnt.tarkovcraft.medsystem.common.health.HealthContainer;
import tnt.tarkovcraft.medsystem.common.health.LimbContainer;
import tnt.tarkovcraft.medsystem.common.init.MedSystemRegistries;

public record StatusEffectRemovingEffectGroupItem(TagKey<StatusEffectType<?>> tag, EffectType classification, Component label) implements EffectGroupItem {
   public static final MapCodec<StatusEffectRemovingEffectGroupItem> CODEC = RecordCodecBuilder.<StatusEffectRemovingEffectGroupItem>mapCodec(
      instance -> instance.group(
            TagKey.codec(MedSystemRegistries.Keys.STATUS_EFFECT).fieldOf("tag").forGetter(t -> t.tag),
            EffectType.CODEC.fieldOf("classification").forGetter(t -> t.classification),
            ComponentSerialization.CODEC.fieldOf("label").forGetter(t -> t.label)
         )
         .apply(instance, StatusEffectRemovingEffectGroupItem::new)
   );

   @Override
   public void init(EffectGroupHolder holder, StatusEffectContext context) {
   }

   @Override
   public void apply(EffectGroupHolder holder, StatusEffectContext context) {
      Level level = context.level();
      long time = level.getGameTime();
      if (time % 20L == 0L) {
         LivingEntity entity = context.entity();
         HealthContainer container = context.container();
         LimbContainer limbContainer = container.getLimbContainer();
         if (limbContainer.removeMatchingStatusEffects(this.tag, entity, container)) {
            container.setChanged();
         }
      }
   }

   @Override
   public void cleanup(EffectGroupHolder holder, StatusEffectContext context) {
   }

   @Override
   public void addInformation(EffectGroupHolder holder, Consumer<Component> tooltip, boolean isItemTooltip) {
      Component component;
      if (isItemTooltip) {
         component = SideEffect.createDescriptionComponent(this.classification, this.label, 1.0F, holder.getDuration(), holder.getDelay());
      } else {
         component = this.label.copy().append(" ").append(StatusEffect.getDurationLabel(holder.getDuration())).withStyle(ChatFormatting.DARK_GRAY);
      }

      tooltip.accept(component);
   }

   @Override
   public EffectGroupItem copy() {
      return new StatusEffectRemovingEffectGroupItem(this.tag, this.classification, this.label);
   }

   @Override
   public EffectGroupHolder tryToMergeWith(EffectGroupHolder current, EffectGroupHolder other) {
      return null;
   }

   @Override
   public MapCodec<? extends EffectGroupItem> codec() {
      return CODEC;
   }
}
