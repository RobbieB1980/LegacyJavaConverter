package tnt.tarkovcraft.medsystem.common.damage.condition;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.advancements.predicates.DamageSourcePredicate;
import net.minecraft.advancements.predicates.TagPredicate;
import net.minecraft.advancements.predicates.DamageSourcePredicate.Builder;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.TagKey;
import net.minecraft.util.StringRepresentable;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;
import tnt.tarkovcraft.medsystem.common.health.calc.HitCalculationContext;

public record DamageSourceCondition(DamageSourcePredicate predicate, DamageSourceCondition.EntityFilter filter) implements DamageCondition {
   public static final MapCodec<DamageSourceCondition> CODEC = RecordCodecBuilder.<DamageSourceCondition>mapCodec(
      instance -> instance.group(
            DamageSourcePredicate.CODEC.fieldOf("predicate").forGetter(DamageSourceCondition::predicate),
            DamageSourceCondition.EntityFilter.CODEC.optionalFieldOf("filter", DamageSourceCondition.EntityFilter.ANY).forGetter(DamageSourceCondition::filter)
         )
         .apply(instance, DamageSourceCondition::new)
   );

   public static DamageSourceCondition fromTag(TagKey<DamageType> tag, boolean include) {
      DamageSourcePredicate predicate = Builder.damageType().tag(include ? TagPredicate.is(tag) : TagPredicate.isNot(tag)).build();
      return new DamageSourceCondition(predicate, DamageSourceCondition.EntityFilter.ANY);
   }

   public boolean test(HitCalculationContext context) {
      if (!this.filter.validate(context)) {
         return false;
      } else {
         DamageSource damageSource = context.source();
         LivingEntity entity = context.entity();
         if (entity.level() instanceof ServerLevel serverLevel) {
            Vec3 position = damageSource.getSourcePosition();
            return this.predicate.matches(serverLevel, position, damageSource);
         } else {
            return false;
         }
      }
   }

   @Override
   public MapCodec<? extends DamageCondition> codec() {
      return CODEC;
   }

   public enum EntityFilter implements StringRepresentable {
      ANY("any"),
      DIRECT("direct"),
      PROJECTILE("projectile");

      public static final Codec<DamageSourceCondition.EntityFilter> CODEC = StringRepresentable.fromEnum(DamageSourceCondition.EntityFilter::values);
      private final String serializedName;

      EntityFilter(String serializedName) {
         this.serializedName = serializedName;
      }

      public boolean validate(HitCalculationContext context) {
         return switch (this) {
            case ANY -> true;
            case DIRECT -> context.getAttackingEntity() != null;
            case PROJECTILE -> context.getProjectile() != null;
         };
      }

      public String getSerializedName() {
         return this.serializedName;
      }
   }
}
