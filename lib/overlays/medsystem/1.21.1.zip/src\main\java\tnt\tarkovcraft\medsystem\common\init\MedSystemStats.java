package tnt.tarkovcraft.medsystem.common.init;

import net.minecraft.core.Holder;
import net.neoforged.neoforge.registries.DeferredRegister;
import tnt.tarkovcraft.core.common.init.CoreRegistries.Keys;
import tnt.tarkovcraft.core.common.statistic.Statistic;

public final class MedSystemStats {
   public static final DeferredRegister<Statistic> REGISTRY = DeferredRegister.create(Keys.STATISTICS, "medsystem");
   public static final Holder<Statistic> LIMBS_LOST = REGISTRY.register("limbs_lost", Statistic::new);
   public static final Holder<Statistic> BLOOD_LOST = REGISTRY.register("blood_lost", Statistic::new);
}
