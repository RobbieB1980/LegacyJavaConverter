package tnt.tarkovcraft.medsystem.common.effect.group;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.function.Consumer;
import net.minecraft.core.Holder;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.util.ExtraCodecs;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.LivingEntity;
import tnt.tarkovcraft.medsystem.api.heal.SideEffect;
import tnt.tarkovcraft.medsystem.common.effect.StatusEffectContext;
import tnt.tarkovcraft.medsystem.common.effect.util.EffectType;

public record MobEffectGroupItem(Holder<MobEffect> effect, int amplifier, boolean ambient, boolean visible, boolean showIcon) implements EffectGroupItem {
   public static final MapCodec<MobEffectGroupItem> CODEC = RecordCodecBuilder.<MobEffectGroupItem>mapCodec(
      instance -> instance.group(
            BuiltInRegistries.MOB_EFFECT.holderByNameCodec().fieldOf("effect").forGetter(t -> t.effect),
            ExtraCodecs.intRange(0, 255).optionalFieldOf("amplifier", 0).forGetter(t -> t.amplifier),
            Codec.BOOL.optionalFieldOf("ambient", false).forGetter(t -> t.ambient),
            Codec.BOOL.optionalFieldOf("visible", true).forGetter(t -> t.visible),
            Codec.BOOL.optionalFieldOf("showIcon", true).forGetter(t -> t.showIcon)
         )
         .apply(instance, MobEffectGroupItem::new)
   );

   public MobEffectGroupItem(Holder<MobEffect> effect, int amplifier, boolean ambient, boolean visible) {
      this(effect, amplifier, ambient, visible, true);
   }

   public MobEffectGroupItem(Holder<MobEffect> effect, int amplifier, boolean ambient) {
      this(effect, amplifier, ambient, true);
   }

   public MobEffectGroupItem(Holder<MobEffect> effect, int amplifier) {
      this(effect, amplifier, false);
   }

   public MobEffectGroupItem(Holder<MobEffect> effect) {
      this(effect, 0);
   }

   @Override
   public void init(EffectGroupHolder holder, StatusEffectContext context) {
      if (context.level().isClientSide()) {
         MobEffectInstance instance = new MobEffectInstance(this.effect, holder.getDuration(), this.amplifier, this.ambient, this.visible, this.showIcon);
         LivingEntity entity = context.entity();
         entity.addEffect(instance);
      }
   }

   @Override
   public void apply(EffectGroupHolder holder, StatusEffectContext context) {
   }

   @Override
   public void cleanup(EffectGroupHolder holder, StatusEffectContext context) {
   }

   @Override
   public void addInformation(EffectGroupHolder holder, Consumer<Component> tooltip, boolean isItemTooltip) {
      MobEffect mobEffect = (MobEffect)this.effect.value();
      MobEffectCategory category = mobEffect.getCategory();
      EffectType effectType = EffectType.byMobEffectCategory(category);
      Component component;
      if (this.amplifier < 10) {
         component = mobEffect.getDisplayName()
            .copy()
            .append(CommonComponents.SPACE)
            .append(Component.translatable("enchantment.level." + (this.amplifier + 1)));
      } else {
         component = mobEffect.getDisplayName();
      }

      tooltip.accept(SideEffect.createDescriptionComponent(effectType, component, 1.0F, holder.getDuration(), holder.getDelay()));
   }

   @Override
   public EffectGroupItem copy() {
      return new MobEffectGroupItem(this.effect, this.amplifier, this.ambient, this.visible, this.showIcon);
   }

   @Override
   public EffectGroupHolder tryToMergeWith(EffectGroupHolder current, EffectGroupHolder other) {
      return null;
   }

   @Override
   public boolean visible() {
      return false;
   }

   @Override
   public MapCodec<? extends EffectGroupItem> codec() {
      return CODEC;
   }
}
