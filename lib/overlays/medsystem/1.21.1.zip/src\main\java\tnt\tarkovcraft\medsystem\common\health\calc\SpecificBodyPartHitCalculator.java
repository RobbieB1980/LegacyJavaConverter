package tnt.tarkovcraft.medsystem.common.health.calc;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.world.entity.LivingEntity;
import tnt.tarkovcraft.medsystem.api.SpecificLimbDamage;
import tnt.tarkovcraft.medsystem.common.health.EntityHitboxContainer;
import tnt.tarkovcraft.medsystem.common.health.HealthContainer;
import tnt.tarkovcraft.medsystem.common.health.HealthContainerDefinition;
import tnt.tarkovcraft.medsystem.common.health.Limb;

public record SpecificBodyPartHitCalculator(SpecificLimbDamage damage) implements HitCalculator {
   @Override
   public HitCalculationResult calculateHits(HitCalculationContext context) {
      HealthContainer container = context.container();
      LivingEntity entity = context.entity();
      HealthContainerDefinition definition = container.getDefinition();
      EntityHitboxContainer hitboxContainer = definition.hitboxContainer();
      String entityState = definition.getCurrentEntityState(entity);
      List<HitInfo> hits = new ArrayList<>();

      for (String limbCode : this.damage.getLimbs()) {
         if (container.hasLimb(limbCode)) {
            Limb limb = container.getLimbByCode(limbCode);
            if (!limb.isDead() || this.damage.canDamageDeadLimbs()) {
               EntityHitboxContainer.LimbHitboxDefinition hitboxDefinition = hitboxContainer.getLimbHitbox(limbCode, entityState);
               HitInfo result = new HitInfo(hitboxDefinition, limb, hitboxDefinition.toWorldSpaceHitbox(entity));
               hits.add(result);
            }
         }
      }

      return hits.isEmpty()
         ? HitCalculationResult.simpleResult(context, hitbox -> this.damage.canDamageDeadLimbs() || !hitbox.limb().isDead())
         : HitCalculationResult.of(hits);
   }
}
