package tnt.tarkovcraft.medsystem.common.blood_system.effect;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.LivingEntity;
import tnt.tarkovcraft.core.common.data.number.NumberProvider;
import tnt.tarkovcraft.core.common.util.AttributeNumber;
import tnt.tarkovcraft.medsystem.common.blood_system.UnconsciousOptions;
import tnt.tarkovcraft.medsystem.common.blood_system.UnconsciousState;
import tnt.tarkovcraft.medsystem.common.blood_system.assignment.EntityBloodSystem;
import tnt.tarkovcraft.medsystem.common.blood_system.assignment.EntityBloodSystemDefinition;

public record UnconsciousBloodLevelEffect(int duration, AttributeNumber chance, UnconsciousOptions options) implements BloodLevelEffect {
   public static final MapCodec<UnconsciousBloodLevelEffect> CODEC = RecordCodecBuilder.<UnconsciousBloodLevelEffect>mapCodec(
      instance -> instance.group(
            NumberProvider.DURATION.fieldOf("duration").forGetter(UnconsciousBloodLevelEffect::duration),
            AttributeNumber.CODEC.optionalFieldOf("chance", AttributeNumber.constant(1.0)).forGetter(UnconsciousBloodLevelEffect::chance),
            UnconsciousOptions.CODEC.fieldOf("options").forGetter(UnconsciousBloodLevelEffect::options)
         )
         .apply(instance, UnconsciousBloodLevelEffect::new)
   );

   @Override
   public void applyEffects(LivingEntity entity, ServerLevel level, EntityBloodSystem bloodSystem) {
      double chance = this.chance.getValue(entity);
      RandomSource random = entity.getRandom();
      applyUnconsciousMode(bloodSystem, entity, random, (float)chance, this.duration, this.options);
   }

   public static void applyUnconsciousMode(
      EntityBloodSystem bloodSystem, LivingEntity entity, RandomSource random, float chance, int duration, UnconsciousOptions options
   ) {
      UnconsciousState unconsciousState = bloodSystem.getUnconsciousState();
      if (duration > 0 && !(chance <= 0.0F) && !unconsciousState.getUnconsciousOptions().is(UnconsciousOptions.TAG_DOWNED)) {
         EntityBloodSystemDefinition definition = bloodSystem.getDefinition();
         if (definition.isUnconsciousModeAllowed()) {
            if (chance >= 1.0F || random.nextFloat() < chance) {
               bloodSystem.setOrExtendedUnconscious(entity, duration, options);
            }
         }
      }
   }

   @Override
   public MapCodec<? extends BloodLevelEffect> codec() {
      return CODEC;
   }
}
