package tnt.tarkovcraft.medsystem.common.pose;

import com.mojang.serialization.MapCodec;
import java.util.Set;
import tnt.tarkovcraft.core.common.pose.EntityPoseFlag;
import tnt.tarkovcraft.core.common.pose.EntityStatusPose;
import tnt.tarkovcraft.core.common.pose.EntityPose.Type;
import tnt.tarkovcraft.medsystem.common.init.MedSystemEntityPoses;

public final class UnconsciousSittingEntityPose extends EntityStatusPose {
   public static final UnconsciousSittingEntityPose INSTANCE = new UnconsciousSittingEntityPose();
   public static final MapCodec<UnconsciousSittingEntityPose> CODEC = MapCodec.unit(INSTANCE);

   private UnconsciousSittingEntityPose() {
   }

   public Set<EntityPoseFlag> getFlags() {
      return UnconsciousEntityPose.UNCONSCIOUS_FLAGS;
   }

   public Type<?> getType() {
      return (Type<?>)MedSystemEntityPoses.UNCONSCIOUS_SITTING.value();
   }
}
