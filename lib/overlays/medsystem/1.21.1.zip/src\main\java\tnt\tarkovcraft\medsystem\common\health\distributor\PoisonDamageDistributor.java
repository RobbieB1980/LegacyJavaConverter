package tnt.tarkovcraft.medsystem.common.health.distributor;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import tnt.tarkovcraft.medsystem.common.health.DamageContext;
import tnt.tarkovcraft.medsystem.common.health.HealthContainer;
import tnt.tarkovcraft.medsystem.common.health.Limb;
import tnt.tarkovcraft.medsystem.common.health.LimbContainer;
import tnt.tarkovcraft.medsystem.common.health.calc.HitInfo;

public final class PoisonDamageDistributor implements DamageDistributor {
   public static final PoisonDamageDistributor INSTANCE = new PoisonDamageDistributor();

   private PoisonDamageDistributor() {
   }

   @Override
   public Map<Limb, Float> distribute(DamageContext context, float damage) {
      HealthContainer container = context.getCalculationContext().container();
      LimbContainer limbContainer = container.getLimbContainer();
      int vitalLimbsCount = limbContainer.getVitalLimbs().size();
      float vitalDmgCutoff = 1.0F / vitalLimbsCount - 0.01F;
      List<Limb> limbs = context.getHits()
         .stream()
         .map(HitInfo::limb)
         .filter(limbx -> limbx.isVital() ? limbx.getHealth() > vitalDmgCutoff : limbx.isAlive())
         .toList();
      float perLimb = damage / limbs.size();
      Map<Limb, Float> damageMap = new HashMap<>();

      for (HitInfo hit : context.getHits()) {
         Limb limb = hit.limb();
         float amount = Math.min(perLimb, limb.isVital() ? limb.getHealth() - vitalDmgCutoff : limb.getHealth());
         if (amount > 0.0F) {
            damageMap.put(limb, amount);
         }
      }

      return damageMap;
   }
}
