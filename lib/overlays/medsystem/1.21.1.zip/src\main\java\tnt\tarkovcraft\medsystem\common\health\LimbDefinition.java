package tnt.tarkovcraft.medsystem.common.health;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.Collections;
import java.util.Set;
import net.minecraft.resources.Identifier;
import net.minecraft.tags.TagKey;
import net.minecraft.util.ExtraCodecs;
import tnt.tarkovcraft.core.util.Codecs;
import tnt.tarkovcraft.medsystem.common.effect.StatusEffectType;
import tnt.tarkovcraft.medsystem.common.init.MedSystemRegistries;
import tnt.tarkovcraft.medsystem.common.init.MedSystemTags;

public record LimbDefinition(LimbType type, boolean vital, float baseHealth, Set<Identifier> tags, LimbDefinition.DamageConfiguration damageConfiguration) {
   public static final Codec<LimbDefinition> CODEC = RecordCodecBuilder.<LimbDefinition>create(
      instance -> instance.group(
            LimbType.CODEC.fieldOf("type").forGetter(LimbDefinition::type),
            Codec.BOOL.optionalFieldOf("vital", false).forGetter(LimbDefinition::vital),
            ExtraCodecs.POSITIVE_FLOAT.fieldOf("base_health").forGetter(LimbDefinition::baseHealth),
            Codecs.hashSet(Identifier.CODEC).optionalFieldOf("tags", Collections.emptySet()).forGetter(LimbDefinition::tags),
            LimbDefinition.DamageConfiguration.CODEC
               .optionalFieldOf("damage_configuration", LimbDefinition.DamageConfiguration.DEFAULT)
               .forGetter(LimbDefinition::damageConfiguration)
         )
         .apply(instance, LimbDefinition::new)
   );

   public Limb createLimbInstance(String code) {
      return new Limb(this, code);
   }

   public boolean isTagged(Identifier tag) {
      return this.tags.contains(tag);
   }

   public record DamageConfiguration(float scale, float transferScale, TagKey<StatusEffectType<?>> excludedStatusEffects) {
      public static final LimbDefinition.DamageConfiguration DEFAULT = new LimbDefinition.DamageConfiguration(1.0F, 1.0F, MedSystemTags.StatusEffects.DISABLED);
      public static final Codec<LimbDefinition.DamageConfiguration> CODEC = RecordCodecBuilder.<LimbDefinition.DamageConfiguration>create(
         instance -> instance.group(
               Codec.FLOAT.optionalFieldOf("scale", 1.0F).forGetter(LimbDefinition.DamageConfiguration::scale),
               Codec.FLOAT.optionalFieldOf("transfer_scale", 1.0F).forGetter(LimbDefinition.DamageConfiguration::transferScale),
               TagKey.codec(MedSystemRegistries.Keys.STATUS_EFFECT)
                  .optionalFieldOf("excluded_status_effects", MedSystemTags.StatusEffects.DISABLED)
                  .forGetter(LimbDefinition.DamageConfiguration::excludedStatusEffects)
            )
            .apply(instance, LimbDefinition.DamageConfiguration::new)
      );

      public boolean isStatusEffectAllowed(StatusEffectType<?> type) {
         return !type.is(this.excludedStatusEffects);
      }
   }
}
