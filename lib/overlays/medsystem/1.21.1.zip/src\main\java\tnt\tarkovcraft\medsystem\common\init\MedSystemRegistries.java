package tnt.tarkovcraft.medsystem.common.init;

import com.mojang.serialization.MapCodec;
import net.minecraft.core.Registry;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.neoforged.neoforge.registries.RegistryBuilder;
import net.neoforged.neoforge.registries.RegisterEvent.RegisterHelper;
import tnt.tarkovcraft.medsystem.MedicalSystem;
import tnt.tarkovcraft.medsystem.api.heal.EffectRecoveryApplicator;
import tnt.tarkovcraft.medsystem.common.blood_system.effect.AddAttributeModifierBloodLevelEffect;
import tnt.tarkovcraft.medsystem.common.blood_system.effect.AddVanillaAttributeModifierBloodLevelEffect;
import tnt.tarkovcraft.medsystem.common.blood_system.effect.ApplyUnconsciousConfigBloodLevelEffect;
import tnt.tarkovcraft.medsystem.common.blood_system.effect.BloodLevelEffect;
import tnt.tarkovcraft.medsystem.common.blood_system.effect.ConfigurableUnconsciousBloodLevelEffect;
import tnt.tarkovcraft.medsystem.common.blood_system.effect.DeathBloodLevelEffect;
import tnt.tarkovcraft.medsystem.common.blood_system.effect.RemoveAttributeModifierBloodLevelEffect;
import tnt.tarkovcraft.medsystem.common.blood_system.effect.RemoveVanillaAttributeModifierBloodLevelEffect;
import tnt.tarkovcraft.medsystem.common.blood_system.effect.UnconsciousBloodLevelEffect;
import tnt.tarkovcraft.medsystem.common.damage.condition.DamageCondition;
import tnt.tarkovcraft.medsystem.common.damage.condition.DamageSourceCondition;
import tnt.tarkovcraft.medsystem.common.damage.condition.DamageTypeCondition;
import tnt.tarkovcraft.medsystem.common.damage.condition.IsExplosionCondition;
import tnt.tarkovcraft.medsystem.common.damage.condition.IsSpecificLimbDamage;
import tnt.tarkovcraft.medsystem.common.damage.function.BrokenLimbDamageFunction;
import tnt.tarkovcraft.medsystem.common.damage.function.DamageFunction;
import tnt.tarkovcraft.medsystem.common.damage.function.ExplosionDamageFunction;
import tnt.tarkovcraft.medsystem.common.damage.function.FallDamageFunction;
import tnt.tarkovcraft.medsystem.common.damage.function.GenericDamageFunction;
import tnt.tarkovcraft.medsystem.common.damage.function.InLiquidDamageFunction;
import tnt.tarkovcraft.medsystem.common.damage.function.MeleeHitFunction;
import tnt.tarkovcraft.medsystem.common.damage.function.PoisonDamageFunction;
import tnt.tarkovcraft.medsystem.common.damage.function.ProjectileDamageFunction;
import tnt.tarkovcraft.medsystem.common.damage.function.SpecificLimbDamageFunction;
import tnt.tarkovcraft.medsystem.common.effect.StatusEffectType;
import tnt.tarkovcraft.medsystem.common.effect.group.AttributeModifierEffectGroupItem;
import tnt.tarkovcraft.medsystem.common.effect.group.BloodRecoveryEffectGroupItem;
import tnt.tarkovcraft.medsystem.common.effect.group.DeadLimbRecoveryEffectGroupItem;
import tnt.tarkovcraft.medsystem.common.effect.group.EffectGroupItem;
import tnt.tarkovcraft.medsystem.common.effect.group.HealthEffectGroupItem;
import tnt.tarkovcraft.medsystem.common.effect.group.MobEffectGroupItem;
import tnt.tarkovcraft.medsystem.common.effect.group.StatusEffectRemovingEffectGroupItem;
import tnt.tarkovcraft.medsystem.common.health.applicator.BleedEffectRecoveryApplicator;
import tnt.tarkovcraft.medsystem.common.health.applicator.FractureEffectRecoveryApplicator;
import tnt.tarkovcraft.medsystem.common.health.applicator.SimpleEffectRecoveryApplicator;
import tnt.tarkovcraft.medsystem.common.health.applicator.StagedEffectRecoveryApplicator;
import tnt.tarkovcraft.medsystem.common.health.state.CustomEntityPoseStateMatcher;
import tnt.tarkovcraft.medsystem.common.health.state.EntityStateMatcher;
import tnt.tarkovcraft.medsystem.common.health.state.IsBabyEntityStateMatcher;
import tnt.tarkovcraft.medsystem.common.health.state.LogicalEntityStateMatcher;
import tnt.tarkovcraft.medsystem.common.health.state.PoseEntityStateMatcher;
import tnt.tarkovcraft.medsystem.common.health.state.SittingPassengerEntityStateMatcher;
import tnt.tarkovcraft.medsystem.common.health_event.HealthEventTriggerSource;
import tnt.tarkovcraft.medsystem.common.health_event.action.AddBleedEventAction;
import tnt.tarkovcraft.medsystem.common.health_event.action.AddMobEffectEventAction;
import tnt.tarkovcraft.medsystem.common.health_event.action.AddShockEventAction;
import tnt.tarkovcraft.medsystem.common.health_event.action.AddStatusEffectEventAction;
import tnt.tarkovcraft.medsystem.common.health_event.action.CopyIncomingEffectsEventAction;
import tnt.tarkovcraft.medsystem.common.health_event.action.HealthEventAction;
import tnt.tarkovcraft.medsystem.common.health_event.action.NoEventAction;
import tnt.tarkovcraft.medsystem.common.health_event.action.WeightedEventAction;
import tnt.tarkovcraft.medsystem.common.health_event.condition.FallEventCondition;
import tnt.tarkovcraft.medsystem.common.health_event.condition.HasDeadLimbEventCondition;
import tnt.tarkovcraft.medsystem.common.health_event.condition.HasStatusEffectEventCondition;
import tnt.tarkovcraft.medsystem.common.health_event.condition.HealthEventCondition;
import tnt.tarkovcraft.medsystem.common.health_event.condition.IsDamageTypeEventCondition;
import tnt.tarkovcraft.medsystem.common.health_event.condition.IsDeadLimbEventCondition;
import tnt.tarkovcraft.medsystem.common.health_event.condition.IsLimbTypeEventCondition;
import tnt.tarkovcraft.medsystem.common.health_event.condition.IsRootLimbEventCondition;
import tnt.tarkovcraft.medsystem.common.health_event.condition.IsTaggedLimbEventCondition;
import tnt.tarkovcraft.medsystem.common.health_event.condition.ItemPredicateEventCondition;
import tnt.tarkovcraft.medsystem.common.health_event.condition.LogicalEventCondition;
import tnt.tarkovcraft.medsystem.common.health_event.condition.LostLimbEventCondition;
import tnt.tarkovcraft.medsystem.common.health_event.condition.RandomChanceEventCondition;
import tnt.tarkovcraft.medsystem.common.health_event.condition.StatusRangeEventCondition;
import tnt.tarkovcraft.medsystem.common.health_event.function.CalculateEventFunction;
import tnt.tarkovcraft.medsystem.common.health_event.function.DeadLimbScaleEventFunction;
import tnt.tarkovcraft.medsystem.common.health_event.function.HealthEventFunction;
import tnt.tarkovcraft.medsystem.common.health_event.function.LimbTypeScaleEventFunction;
import tnt.tarkovcraft.medsystem.common.health_event.function.LostLimbsCountScaleEventFunction;
import tnt.tarkovcraft.medsystem.common.health_event.function.SetValueEventFunction;
import tnt.tarkovcraft.medsystem.common.health_event.function.StatusScaleEventFunction;
import tnt.tarkovcraft.medsystem.common.health_event.function.ToolMultiplierEventFunction;

public final class MedSystemRegistries {
   public static final Registry<StatusEffectType<?>> STATUS_EFFECT = new RegistryBuilder(MedSystemRegistries.Keys.STATUS_EFFECT)
      .withIntrusiveHolders()
      .create();
   public static final Registry<MapCodec<? extends EffectGroupItem>> EFFECT_GROUP_ITEM = new RegistryBuilder(MedSystemRegistries.Keys.EFFECT_GROUP_ITEM)
      .create();
   public static final Registry<MapCodec<? extends EntityStateMatcher>> STATE_MATCHER = new RegistryBuilder(MedSystemRegistries.Keys.STATE_MATCHER).create();
   public static final Registry<MapCodec<? extends EffectRecoveryApplicator>> EFFECT_RECOVERY_APPLICATOR = new RegistryBuilder(
         MedSystemRegistries.Keys.EFFECT_RECOVERY_APPLICATOR
      )
      .create();
   public static final Registry<MapCodec<? extends DamageCondition>> DAMAGE_CONDITIONS = new RegistryBuilder(MedSystemRegistries.Keys.DAMAGE_CONDITIONS)
      .create();
   public static final Registry<MapCodec<? extends DamageFunction>> DAMAGE_FUNCTIONS = new RegistryBuilder(MedSystemRegistries.Keys.DAMAGE_FUNCTIONS).create();
   public static final Registry<HealthEventTriggerSource> HEALTH_EVENT_TRIGGER_SOURCE = new RegistryBuilder(
         MedSystemRegistries.Keys.HEALTH_EVENT_TRIGGER_SOURCE
      )
      .create();
   public static final Registry<MapCodec<? extends HealthEventCondition>> HEALTH_EVENT_CONDITION = new RegistryBuilder(
         MedSystemRegistries.Keys.HEALTH_EVENT_CONDITION
      )
      .create();
   public static final Registry<MapCodec<? extends HealthEventAction>> HEALTH_EVENT_ACTION = new RegistryBuilder(MedSystemRegistries.Keys.HEALTH_EVENT_ACTION)
      .create();
   public static final Registry<MapCodec<? extends HealthEventFunction>> HEALTH_EVENT_FUNCTION = new RegistryBuilder(
         MedSystemRegistries.Keys.HEALTH_EVENT_FUNCTION
      )
      .create();
   public static final Registry<MapCodec<? extends BloodLevelEffect>> BLOOD_LEVEL_EFFECT = new RegistryBuilder(MedSystemRegistries.Keys.BLOOD_LEVEL_EFFECT)
      .create();

   public static void registerEffectGroupItems(RegisterHelper<MapCodec<? extends EffectGroupItem>> helper) {
      registerObject(helper, "attribute", AttributeModifierEffectGroupItem.CODEC);
      registerObject(helper, "health", HealthEffectGroupItem.CODEC);
      registerObject(helper, "status_effect_removing", StatusEffectRemovingEffectGroupItem.CODEC);
      registerObject(helper, "dead_limb_recovery", DeadLimbRecoveryEffectGroupItem.CODEC);
      registerObject(helper, "blood_recovery", BloodRecoveryEffectGroupItem.CODEC);
      registerObject(helper, "mob_effect", MobEffectGroupItem.CODEC);
   }

   public static void registerStateMatchers(RegisterHelper<MapCodec<? extends EntityStateMatcher>> helper) {
      registerObject(helper, "pose", PoseEntityStateMatcher.CODEC);
      registerObject(helper, "custom_pose", CustomEntityPoseStateMatcher.CODEC);
      registerObject(helper, "sitting_passenger", SittingPassengerEntityStateMatcher.CODEC);
      registerObject(helper, "is_baby", IsBabyEntityStateMatcher.CODEC);
      registerObject(helper, "logical", LogicalEntityStateMatcher.CODEC);
   }

   public static void registerEffectRecoveryApplicators(RegisterHelper<MapCodec<? extends EffectRecoveryApplicator>> helper) {
      registerObject(helper, "simple", SimpleEffectRecoveryApplicator.CODEC);
      registerObject(helper, "bleed", BleedEffectRecoveryApplicator.CODEC);
      registerObject(helper, "fracture", FractureEffectRecoveryApplicator.CODEC);
      registerObject(helper, "staged", StagedEffectRecoveryApplicator.CODEC);
   }

   public static void registerDamageConditions(RegisterHelper<MapCodec<? extends DamageCondition>> helper) {
      registerObject(helper, "builtin/specific_limb", IsSpecificLimbDamage.CODEC);
      registerObject(helper, "damage_predicate", DamageSourceCondition.CODEC);
      registerObject(helper, "damage_type", DamageTypeCondition.CODEC);
      registerObject(helper, "is_explosion", IsExplosionCondition.CODEC);
   }

   public static void registerDamageFunctions(RegisterHelper<MapCodec<? extends DamageFunction>> helper) {
      registerObject(helper, "builtin/generic", GenericDamageFunction.CODEC);
      registerObject(helper, "builtin/specific_limb", SpecificLimbDamageFunction.CODEC);
      registerObject(helper, "builtin/broken_limb", BrokenLimbDamageFunction.CODEC);
      registerObject(helper, "builtin/poison", PoisonDamageFunction.CODEC);
      registerObject(helper, "melee_damage", MeleeHitFunction.CODEC);
      registerObject(helper, "projectile_damage", ProjectileDamageFunction.CODEC);
      registerObject(helper, "fall", FallDamageFunction.CODEC);
      registerObject(helper, "explosion", ExplosionDamageFunction.CODEC);
      registerObject(helper, "in_liquid", InLiquidDamageFunction.CODEC);
   }

   public static void registerHealthEventConditions(RegisterHelper<MapCodec<? extends HealthEventCondition>> helper) {
      registerObject(helper, "damage_range", StatusRangeEventCondition.CODEC);
      registerObject(helper, "is_limb", IsLimbTypeEventCondition.CODEC);
      registerObject(helper, "is_damage", IsDamageTypeEventCondition.CODEC);
      registerObject(helper, "is_dead_limb", IsDeadLimbEventCondition.CODEC);
      registerObject(helper, "is_root_limb", IsRootLimbEventCondition.CODEC);
      registerObject(helper, "has_dead_limb", HasDeadLimbEventCondition.CODEC);
      registerObject(helper, "has_effect", HasStatusEffectEventCondition.CODEC);
      registerObject(helper, "random_chance", RandomChanceEventCondition.CODEC);
      registerObject(helper, "fall_fracture", FallEventCondition.CODEC);
      registerObject(helper, "logical", LogicalEventCondition.CODEC);
      registerObject(helper, "lost_limb", LostLimbEventCondition.CODEC);
      registerObject(helper, "item_predicate", ItemPredicateEventCondition.CODEC);
      registerObject(helper, "has_limb_tag", IsTaggedLimbEventCondition.CODEC);
   }

   public static void registerHealthEventActions(RegisterHelper<MapCodec<? extends HealthEventAction>> helper) {
      registerObject(helper, "none", NoEventAction.CODEC);
      registerObject(helper, "add_status_effect", AddStatusEffectEventAction.CODEC);
      registerObject(helper, "add_mob_effect", AddMobEffectEventAction.CODEC);
      registerObject(helper, "add_shock", AddShockEventAction.CODEC);
      registerObject(helper, "add_bleed", AddBleedEventAction.CODEC);
      registerObject(helper, "copy_incoming_effects", CopyIncomingEffectsEventAction.CODEC);
      registerObject(helper, "weighted", WeightedEventAction.CODEC);
   }

   public static void registerHealthEventFunctions(RegisterHelper<MapCodec<? extends HealthEventFunction>> helper) {
      registerObject(helper, "damage_scale", StatusScaleEventFunction.CODEC);
      registerObject(helper, "dead_limb_scale", DeadLimbScaleEventFunction.CODEC);
      registerObject(helper, "calculation", CalculateEventFunction.CODEC);
      registerObject(helper, "lost_limb_count", LostLimbsCountScaleEventFunction.CODEC);
      registerObject(helper, "limb_type_scale", LimbTypeScaleEventFunction.CODEC);
      registerObject(helper, "tool_multiplier", ToolMultiplierEventFunction.CODEC);
      registerObject(helper, "set_value", SetValueEventFunction.CODEC);
   }

   public static void registerBloodLevelEffects(RegisterHelper<MapCodec<? extends BloodLevelEffect>> helper) {
      registerObject(helper, "death", DeathBloodLevelEffect.CODEC);
      registerObject(helper, "unconscious", UnconsciousBloodLevelEffect.CODEC);
      registerObject(helper, "configurable_unconscious", ConfigurableUnconsciousBloodLevelEffect.CODEC);
      registerObject(helper, "apply_unconscious_config", ApplyUnconsciousConfigBloodLevelEffect.CODEC);
      registerObject(helper, "add_vanilla_attribute_modifier", AddVanillaAttributeModifierBloodLevelEffect.CODEC);
      registerObject(helper, "add_attribute_modifier", AddAttributeModifierBloodLevelEffect.CODEC);
      registerObject(helper, "remove_vanilla_attribute_modifier", RemoveVanillaAttributeModifierBloodLevelEffect.CODEC);
      registerObject(helper, "remove_attribute_modifier", RemoveAttributeModifierBloodLevelEffect.CODEC);
   }

   private static <T> void registerObject(RegisterHelper<T> helper, String name, T object) {
      helper.register(Identifier.fromNamespaceAndPath("medsystem", name), object);
   }

   public static final class Keys {
      public static final ResourceKey<Registry<StatusEffectType<?>>> STATUS_EFFECT = ResourceKey.createRegistryKey(
         MedicalSystem.createIdentifier("status_effect")
      );
      public static final ResourceKey<Registry<MapCodec<? extends EffectGroupItem>>> EFFECT_GROUP_ITEM = ResourceKey.createRegistryKey(
         MedicalSystem.createIdentifier("status_effect/effect_group")
      );
      public static final ResourceKey<Registry<MapCodec<? extends EntityStateMatcher>>> STATE_MATCHER = ResourceKey.createRegistryKey(
         MedicalSystem.createIdentifier("health/state_matcher")
      );
      public static final ResourceKey<Registry<MapCodec<? extends EffectRecoveryApplicator>>> EFFECT_RECOVERY_APPLICATOR = ResourceKey.createRegistryKey(
         MedicalSystem.createIdentifier("effect_recovery_applicator")
      );
      public static final ResourceKey<Registry<MapCodec<? extends DamageCondition>>> DAMAGE_CONDITIONS = ResourceKey.createRegistryKey(
         MedicalSystem.createIdentifier("damage_resolver/condition")
      );
      public static final ResourceKey<Registry<MapCodec<? extends DamageFunction>>> DAMAGE_FUNCTIONS = ResourceKey.createRegistryKey(
         MedicalSystem.createIdentifier("damage_resolver/function")
      );
      public static final ResourceKey<Registry<HealthEventTriggerSource>> HEALTH_EVENT_TRIGGER_SOURCE = ResourceKey.createRegistryKey(
         MedicalSystem.createIdentifier("health_event/source")
      );
      public static final ResourceKey<Registry<MapCodec<? extends HealthEventCondition>>> HEALTH_EVENT_CONDITION = ResourceKey.createRegistryKey(
         MedicalSystem.createIdentifier("health_event/condition")
      );
      public static final ResourceKey<Registry<MapCodec<? extends HealthEventAction>>> HEALTH_EVENT_ACTION = ResourceKey.createRegistryKey(
         MedicalSystem.createIdentifier("health_event/action")
      );
      public static final ResourceKey<Registry<MapCodec<? extends HealthEventFunction>>> HEALTH_EVENT_FUNCTION = ResourceKey.createRegistryKey(
         MedicalSystem.createIdentifier("health_event/function")
      );
      public static final ResourceKey<Registry<MapCodec<? extends BloodLevelEffect>>> BLOOD_LEVEL_EFFECT = ResourceKey.createRegistryKey(
         MedicalSystem.createIdentifier("blood_system/effect")
      );
   }
}
