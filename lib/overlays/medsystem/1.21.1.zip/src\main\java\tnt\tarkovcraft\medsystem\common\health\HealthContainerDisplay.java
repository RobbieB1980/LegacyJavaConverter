package tnt.tarkovcraft.medsystem.common.health;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.Map;
import java.util.function.BiConsumer;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec2;
import org.joml.Vector2f;
import org.joml.Vector4f;
import org.joml.Vector4i;

public record HealthContainerDisplay(Map<String, HealthContainerDisplay.DisplayData> displayDataMap) {
   public static final Codec<HealthContainerDisplay> CODEC = Codec.unboundedMap(Codec.STRING, HealthContainerDisplay.DisplayData.CODEC)
      .xmap(HealthContainerDisplay::new, HealthContainerDisplay::displayDataMap);

   public void accept(BiConsumer<String, HealthContainerDisplay.DisplayData> consumer) {
      this.displayDataMap.forEach(consumer);
   }

   public record DisplayData(Vec2 pos, Vec2 size) {
      public static final Codec<HealthContainerDisplay.DisplayData> CODEC = RecordCodecBuilder.<HealthContainerDisplay.DisplayData>create(
         instance -> instance.group(
               Vec2.CODEC.fieldOf("pos").forGetter(HealthContainerDisplay.DisplayData::pos),
               Vec2.CODEC.fieldOf("size").forGetter(HealthContainerDisplay.DisplayData::size)
            )
            .apply(instance, HealthContainerDisplay.DisplayData::new)
      );

      public Vector4f getPos(float scale, Vector2f center) {
         float sizeX = this.size.x * scale;
         float sizeY = this.size.y * scale;
         return new Vector4f(center.x + this.pos.x * scale - sizeX / 2.0F, center.y + this.pos.y * scale, sizeX, sizeY);
      }

      public Vector4i getGuiPos(float scale, Vector2f center) {
         float sizeX = this.size.x * scale;
         float sizeY = this.size.y * scale;
         return new Vector4i(
            Mth.floor(center.x + this.pos.x * scale - sizeX / 2.0F), Mth.floor(center.y + this.pos.y * scale), Mth.ceil(sizeX), Mth.ceil(sizeY)
         );
      }
   }
}
