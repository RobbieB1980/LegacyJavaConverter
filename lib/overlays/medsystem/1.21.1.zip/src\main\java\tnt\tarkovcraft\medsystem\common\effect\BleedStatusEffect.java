package tnt.tarkovcraft.medsystem.common.effect;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.Optional;
import java.util.UUID;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;
import net.minecraft.ChatFormatting;
import net.minecraft.core.RegistryAccess;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.util.StringRepresentable;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import org.jspecify.annotations.Nullable;
import tnt.tarkovcraft.core.common.statistic.StatisticTracker;
import tnt.tarkovcraft.medsystem.MedicalSystem;
import tnt.tarkovcraft.medsystem.client.particle.BloodDripParticleOptions;
import tnt.tarkovcraft.medsystem.common.DamageHandler;
import tnt.tarkovcraft.medsystem.common.blood_system.BloodSystemManager;
import tnt.tarkovcraft.medsystem.common.blood_system.assignment.EntityBloodSystem;
import tnt.tarkovcraft.medsystem.common.config.BleedConfiguration;
import tnt.tarkovcraft.medsystem.common.config.MedSystemConfig;
import tnt.tarkovcraft.medsystem.common.config.StatusEffectConfig;
import tnt.tarkovcraft.medsystem.common.effect.util.StatusEffectHelper;
import tnt.tarkovcraft.medsystem.common.health.EntityHitboxContainer;
import tnt.tarkovcraft.medsystem.common.health.HealthContainer;
import tnt.tarkovcraft.medsystem.common.health.HealthContainerDefinition;
import tnt.tarkovcraft.medsystem.common.health.Limb;
import tnt.tarkovcraft.medsystem.common.init.MedSystemDamageTypes;
import tnt.tarkovcraft.medsystem.common.init.MedSystemStats;
import tnt.tarkovcraft.medsystem.common.init.MedSystemStatusEffects;
import tnt.tarkovcraft.medsystem.util.HealthHelper;

public final class BleedStatusEffect extends EntityCausedStatusEffect {
   public static final MapCodec<BleedStatusEffect> CODEC = RecordCodecBuilder.<BleedStatusEffect>mapCodec(
      instance -> commonEntity(instance)
         .and(
            instance.group(
               Codec.LONG.optionalFieldOf("added_at", 0L).forGetter(t -> t.addedAt),
               BleedStatusEffect.BleedType.CODEC.optionalFieldOf("bleed_type", BleedStatusEffect.BleedType.LIGHT).forGetter(t -> t.bleedType)
            )
         )
         .apply(instance, BleedStatusEffect::new)
   );
   public static final Component LIGHT_BLEED = Component.translatable("status_effect.medsystem.bleed.light");
   public static final Component MODERATE_BLEED = Component.translatable("status_effect.medsystem.bleed.moderate");
   public static final Component HEAVY_BLEED = Component.translatable("status_effect.medsystem.bleed.heavy");
   public static final Component CRITICAL_BLEED = Component.translatable("status_effect.medsystem.bleed.critical");
   public static final Identifier ICON_LIGHT_BLEED = StatusEffectHelper.getTextureResource("medsystem", "light_bleed");
   public static final Identifier ICON_HEAVY_BLEED = StatusEffectHelper.getTextureResource("medsystem", "heavy_bleed");
   private static final float RAW_DAMAGE_SCALE = 40.0F;
   private static final Component HINT_USE_BANDAGE = Component.translatable("status_effect.medsystem.bleed.bandage.heal_hint")
      .withStyle(ChatFormatting.DARK_GRAY);
   private static final Component HINT_USE_TOURNIQUET = Component.translatable("status_effect.medsystem.bleed.tourniquet.heal_hint")
      .withStyle(ChatFormatting.DARK_GRAY);
   private long addedAt;
   private final BleedStatusEffect.BleedType bleedType;

   public BleedStatusEffect(int duration, Optional<UUID> owner, BleedStatusEffect.BleedType bleedType) {
      this(duration, owner, 0L, bleedType);
   }

   private BleedStatusEffect(int duration, Optional<UUID> owner, long addedAt, BleedStatusEffect.BleedType bleedType) {
      super(duration, owner);
      this.addedAt = addedAt;
      this.bleedType = bleedType;
   }

   public static BleedStatusEffect lightBleed(int duration, Optional<UUID> causingEntity) {
      return new BleedStatusEffect(duration, causingEntity, BleedStatusEffect.BleedType.LIGHT);
   }

   public static BleedStatusEffect moderateBleed(int duration, Optional<UUID> causingEntity) {
      return new BleedStatusEffect(duration, causingEntity, BleedStatusEffect.BleedType.MODERATE);
   }

   public static BleedStatusEffect heavyBleed(int duration, Optional<UUID> causingEntity) {
      return new BleedStatusEffect(duration, causingEntity, BleedStatusEffect.BleedType.HEAVY);
   }

   public static BleedStatusEffect criticalBleed(int duration, Optional<UUID> causingEntity) {
      return new BleedStatusEffect(duration, causingEntity, BleedStatusEffect.BleedType.CRITICAL);
   }

   public static BleedStatusEffect createTemplate(int duration, BleedStatusEffect.BleedType bleedType) {
      return new BleedStatusEffect(duration, Optional.empty(), bleedType);
   }

   @Override
   public void apply(StatusEffectContext context) {
      Level level = context.level();
      long time = level.getGameTime();
      if (this.addedAt == 0L) {
         this.addedAt = time - 1L;
      }

      Limb limb = context.limb();
      LivingEntity entity = context.entity();
      BleedConfiguration.BleedStageConfig stageConfig = this.getStageConfiguration();
      if (limb != null && (time - this.addedAt) % stageConfig.bleedInterval == 0L && level instanceof ServerLevel serverLevel) {
         float bloodLost = BloodSystemManager.causeBloodLoss(entity, stageConfig.bleedAmount);
         if (bloodLost < 0.0F) {
            RegistryAccess access = serverLevel.registryAccess();
            DamageSource damageSource = MedSystemDamageTypes.causeBleedDamage(access, this.getCausingEntity(serverLevel));
            float damage = stageConfig.bleedAmount * 40.0F;
            entity.hurtServer(serverLevel, damageSource, damage);
         }

         if (bloodLost > 0.0F) {
            StatisticTracker.incrementOptional(entity, MedSystemStats.BLOOD_LOST, Mth.floor(bloodLost * 1000.0F));
            float decalMultiplier = bloodLost / stageConfig.bleedAmount;
            HealthContainer container = context.container();
            Integer particleColor = DamageHandler.getBloodColor(entity, container, EntityBloodSystem.getAttached(entity));
            if (particleColor != null) {
               RandomSource random = level.getRandom();
               BloodDripParticleOptions options = new BloodDripParticleOptions(particleColor);
               Vec3 position = this.getParticlePosition(entity, container, limb);
               Vec3 delta = entity.getDeltaMovement();
               double baseDelta = 0.03;
               double xd = random.nextFloat() * (baseDelta * 2.0) - baseDelta + delta.x;
               double yd = 0.02F;
               double zd = random.nextFloat() * (baseDelta * 2.0) - baseDelta + delta.z;
               HealthHelper.submitServerBleedParticles(
                  options, Mth.ceil(stageConfig.decalCount * decalMultiplier), position.x, position.y, position.z, xd, yd, zd, 3.5, entity
               );
            }
         }
      }
   }

   @Override
   public void onRemoved(StatusEffectContext context) {
   }

   @Override
   public void addAdditionalInfo(Consumer<Component> tooltip) {
      tooltip.accept(needsTourniquet(this) ? HINT_USE_TOURNIQUET : HINT_USE_BANDAGE);
   }

   @Override
   public @Nullable Component getCustomDisplayName() {
      return this.bleedType.label.get();
   }

   @Override
   public @Nullable Identifier getCustomIcon() {
      return this.bleedType.icon.get();
   }

   @Override
   public StatusEffect copy() {
      return new BleedStatusEffect(this.getDuration(), Optional.ofNullable(this.getCausingEntity()), this.bleedType);
   }

   @Override
   public StatusEffectType<?> getType() {
      return (StatusEffectType<?>)MedSystemStatusEffects.BLEED.value();
   }

   public BleedStatusEffect.BleedType getBleedType() {
      return this.bleedType;
   }

   @Override
   protected @Nullable Integer getCustomHealingPriority() {
      return needsTourniquet(this) ? 30 : 15;
   }

   private Vec3 getParticlePosition(LivingEntity entity, HealthContainer container, Limb limb) {
      HealthContainerDefinition definition = container.getDefinition();
      EntityHitboxContainer hitboxContainer = definition.hitboxContainer();
      String state = definition.getCurrentEntityState(entity);
      EntityHitboxContainer.LimbHitboxDefinition hitbox = hitboxContainer.getLimbHitbox(limb.getLimbCode(), state);
      return hitbox.toWorldSpaceHitbox(entity).getCenter();
   }

   public static boolean needsTourniquet(BleedStatusEffect effect) {
      return effect.bleedType.requiresTourniquet;
   }

   public static BleedStatusEffect higherStage(BleedStatusEffect ef1, BleedStatusEffect ef2) {
      StatusEffectConfig config = MedicalSystem.getConfig().statusEffects;
      int duration = StatusEffectConfig.getStackedDuration(sumEffectDurations(ef1, ef2), config.maxBleedDuration);
      BleedStatusEffect.BleedType bleedType = ef1.bleedType.ordinal() > ef2.bleedType.ordinal() ? ef1.bleedType : ef2.bleedType;
      UUID causingEntity = ef1.getCausingEntity() != null ? ef1.getCausingEntity() : ef2.getCausingEntity();
      return new BleedStatusEffect(duration, Optional.ofNullable(causingEntity), bleedType);
   }

   public BleedConfiguration.BleedStageConfig getStageConfiguration() {
      MedSystemConfig config = MedicalSystem.getConfig();
      BleedConfiguration bleedConfiguration = config.statusEffects.bleedConfiguration;
      return this.bleedType.configProvider.apply(bleedConfiguration);
   }

   public enum BleedType implements StringRepresentable {
      LIGHT("light", () -> BleedStatusEffect.LIGHT_BLEED, () -> BleedStatusEffect.ICON_LIGHT_BLEED, false, BleedConfiguration::getLightBleed),
      MODERATE("moderate", () -> BleedStatusEffect.MODERATE_BLEED, () -> BleedStatusEffect.ICON_LIGHT_BLEED, false, BleedConfiguration::getModerateBleed),
      HEAVY("heavy", () -> BleedStatusEffect.HEAVY_BLEED, () -> BleedStatusEffect.ICON_HEAVY_BLEED, true, BleedConfiguration::getHeavyBleed),
      CRITICAL("critical", () -> BleedStatusEffect.CRITICAL_BLEED, () -> BleedStatusEffect.ICON_HEAVY_BLEED, true, BleedConfiguration::getCriticalBleed);

      public static final Codec<BleedStatusEffect.BleedType> CODEC = StringRepresentable.fromEnum(BleedStatusEffect.BleedType::values);
      private final String name;
      private final Supplier<Component> label;
      private final Supplier<Identifier> icon;
      private final boolean requiresTourniquet;
      private final Function<BleedConfiguration, BleedConfiguration.BleedStageConfig> configProvider;

      BleedType(
         String name,
         Supplier<Component> label,
         Supplier<Identifier> icon,
         boolean requiresTourniquet,
         Function<BleedConfiguration, BleedConfiguration.BleedStageConfig> configProvider
      ) {
         this.name = name;
         this.label = label;
         this.icon = icon;
         this.requiresTourniquet = requiresTourniquet;
         this.configProvider = configProvider;
      }

      public String getSerializedName() {
         return this.name;
      }

      public Component getLabel() {
         return this.label.get();
      }

      public BleedConfiguration.BleedStageConfig getConfig() {
         return this.configProvider.apply(MedicalSystem.getConfig().statusEffects.bleedConfiguration);
      }
   }
}
