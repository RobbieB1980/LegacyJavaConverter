package tnt.tarkovcraft.medsystem.client.screen.widget;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.function.ToIntFunction;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.narration.NarrationElementOutput;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.input.MouseButtonInfo;
import net.minecraft.network.chat.Component;
import net.minecraft.util.ARGB;
import tnt.tarkovcraft.core.client.screen.listener.SimpleClickListener;
import tnt.tarkovcraft.medsystem.client.MedicalSystemClient;
import tnt.tarkovcraft.medsystem.client.config.HealthOverlayConfiguration;
import tnt.tarkovcraft.medsystem.client.overlay.HealthLayer;
import tnt.tarkovcraft.medsystem.common.health.Limb;

public class LimbWidget extends AbstractWidget {
   private final Limb limb;
   private final Font font;
   private int scale = 2;
   private ToIntFunction<Limb> colorProvider;
   private SimpleClickListener onClick;
   private List<Component> customTooltip = new ArrayList<>();

   public LimbWidget(int x, int y, int width, int height, Limb limb, Font font) {
      super(x, y, width, height, limb.getDisplayName());
      this.limb = limb;
      this.font = font;
      this.colorProvider = selectedLimb -> {
         HealthOverlayConfiguration overlay = MedicalSystemClient.getConfig().healthOverlay;
         return HealthLayer.getColor(overlay.deadLimbColor, overlay.colorSchema, selectedLimb) | 0xFF000000;
      };
   }

   public void extractWidgetRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float partialTick) {
      int color = this.getColor();
      graphics.fill(this.getX(), this.getY(), this.getRight(), this.getBottom(), ARGB.scaleRGB(color, 0.8F));
      graphics.fill(this.getX() + this.scale, this.getY() + this.scale, this.getRight() - this.scale, this.getBottom() - this.scale, color);
      if (!this.customTooltip.isEmpty() && this.isHovered()) {
         graphics.setTooltipForNextFrame(this.font, this.customTooltip, Optional.empty(), mouseX, mouseY);
      }
   }

   public int getColor() {
      return this.colorProvider.applyAsInt(this.limb);
   }

   protected void updateWidgetNarration(NarrationElementOutput narrationElementOutput) {
   }

   protected boolean isValidClickButton(MouseButtonInfo info) {
      return this.onClick != null;
   }

   public void onClick(MouseButtonEvent event, boolean doubleClick) {
      this.onClick.onClick();
   }

   public void setScale(int scale) {
      this.scale = scale;
   }

   public void setColorProvider(ToIntFunction<Limb> colorProvider) {
      this.colorProvider = colorProvider;
   }

   public void setOnClick(SimpleClickListener onClick) {
      this.onClick = onClick;
   }

   public void addTooltip(Component line) {
      this.customTooltip.add(line);
   }
}
