package tnt.tarkovcraft.medsystem.api.heal;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.Locale;
import java.util.function.Consumer;
import net.minecraft.ChatFormatting;
import net.minecraft.core.Holder;
import net.minecraft.core.component.DataComponentGetter;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.Item.TooltipContext;
import net.minecraft.world.item.component.TooltipProvider;
import org.jspecify.annotations.Nullable;
import tnt.tarkovcraft.core.common.attribute.Attribute;
import tnt.tarkovcraft.core.common.attribute.AttributeSystem;
import tnt.tarkovcraft.core.common.data.duration.Duration;
import tnt.tarkovcraft.core.common.data.duration.DurationFormats;
import tnt.tarkovcraft.medsystem.MedicalSystem;
import tnt.tarkovcraft.medsystem.common.effect.StatusEffect;
import tnt.tarkovcraft.medsystem.common.effect.StatusEffectType;
import tnt.tarkovcraft.medsystem.common.effect.util.EffectType;
import tnt.tarkovcraft.medsystem.common.effect.util.StatusEffectHelper;
import tnt.tarkovcraft.medsystem.common.effect.util.StatusEffectMap;
import tnt.tarkovcraft.medsystem.common.health.HealthContainer;
import tnt.tarkovcraft.medsystem.common.health.Limb;
import tnt.tarkovcraft.medsystem.common.init.MedSystemAttributes;

public record SideEffect(float chance, int delay, StatusEffect template) implements TooltipProvider {
   public static final Codec<SideEffect> CODEC = RecordCodecBuilder.<SideEffect>create(
      instance -> instance.group(
            Codec.floatRange(0.0F, 1.0F).optionalFieldOf("chance", 1.0F).forGetter(SideEffect::chance),
            Codec.INT.optionalFieldOf("delay", 0).forGetter(SideEffect::delay),
            StatusEffectType.CODEC.fieldOf("template").forGetter(SideEffect::template)
         )
         .apply(instance, SideEffect::new)
   );

   public void apply(LivingEntity entity, @Nullable DamageSource damageSource, HealthContainer container, @Nullable Limb limb) {
      StatusEffectType<?> type = this.template.getType();
      if (limb == null || type.isGlobalEffect() || limb.canApplyStatusEffect(type)) {
         RandomSource source = entity.getRandom();
         Holder<Attribute> chanceAttribute = this.chance < 1.0F
            ? type.getEffectType().byValue(MedSystemAttributes.POSITIVE_EFFECT_CHANCE, MedSystemAttributes.NEGATIVE_EFFECT_CHANCE, null)
            : null;
         float effectChance = chanceAttribute != null ? this.chance * AttributeSystem.getFloatValue(entity, chanceAttribute, 1.0F) : this.chance;
         if (effectChance >= 1.0F || source.nextFloat() < effectChance) {
            if (!type.isGlobalEffect() && limb == null) {
               MedicalSystem.LOGGER.error("Failed to apply side effect {} as effect is not set as global, but target limb was not provided", type);
               return;
            }

            StatusEffectMap effects = type.isGlobalEffect() ? container.getGlobalStatusEffects() : limb.getStatusEffects();
            StatusEffect statusEffect = this.template.copy();
            if (!this.template.isInfinite()) {
               Holder<Attribute> durationAttribute = type.getEffectType()
                  .byValue(MedSystemAttributes.POSITIVE_EFFECT_DURATION, MedSystemAttributes.NEGATIVE_EFFECT_DURATION, null);
               int duration = durationAttribute != null
                  ? Mth.ceil(AttributeSystem.getFloatValue(entity, durationAttribute, 1.0F) * this.template.getDuration())
                  : this.template.getDuration();
               statusEffect.setDuration(duration);
            }

            if (damageSource != null) {
               StatusEffectHelper.setCausingEntityFromSource(statusEffect, damageSource);
            }

            StatusEffectHelper.addEffect(effects, entity, limb, this.delay, statusEffect);
         }
      }
   }

   public void addToTooltip(TooltipContext context, Consumer<Component> tooltipAdder, TooltipFlag flag, DataComponentGetter componentGetter) {
      if (this.template.hasCustomTooltip()) {
         this.template.addCustomTooltip(tooltipAdder);
      } else {
         StatusEffectType<?> type = this.template.getType();
         EffectType effectType = type.getEffectType();
         Component title = type.getDisplayName(this.template);
         tooltipAdder.accept(createDescriptionComponent(effectType, title, this.chance, this.template.getDuration(), this.delay));
      }
   }

   public static Component createDescriptionComponent(EffectType type, Component name, float chance, int duration, int delay) {
      MutableComponent component = Component.literal("> ");
      if (chance < 1.0F) {
         Component chanceComponent = Component.literal(String.format(Locale.ROOT, "%.1f%%", chance * 100.0F) + " ").withStyle(ChatFormatting.GRAY);
         component.append(chanceComponent);
      }

      component.append(name.copy().withStyle(type));
      if (duration > 0) {
         Component durationValue = Duration.format(duration, DurationFormats.SHORT_NAME).plainCopy().withStyle(ChatFormatting.GRAY);
         component.append(" / ").append(Component.translatable("tooltip.medsystem.heal_attributes.side_effects.duration", new Object[]{durationValue}));
      }

      if (delay > 0) {
         Component delayValue = Duration.format(delay, DurationFormats.SHORT_NAME).plainCopy().withStyle(ChatFormatting.GRAY);
         component.append(" / ").append(Component.translatable("tooltip.medsystem.heal_attributes.side_effects.delay", new Object[]{delayValue}));
      }

      return component.withStyle(ChatFormatting.DARK_GRAY);
   }
}
