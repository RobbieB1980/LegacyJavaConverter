package tnt.tarkovcraft.medsystem.common.effect.util;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import tnt.tarkovcraft.core.util.Lazy;
import tnt.tarkovcraft.medsystem.common.effect.StatusEffect;

public class ListStatusEffectSubmitter implements StatusEffectSubmitter {
   private final Lazy<List<StatusEffectWithDelay>> effects;

   ListStatusEffectSubmitter(List<StatusEffectWithDelay> effects) {
      this.effects = Lazy.of(effects);
   }

   ListStatusEffectSubmitter() {
      this.effects = Lazy.of(ArrayList::new);
   }

   @Override
   public void submit(int delay, StatusEffect template) {
      ((List)this.effects.get()).add(new StatusEffectWithDelay(delay, template));
   }

   @Override
   public void clear() {
      this.effects.ifPresent(List::clear);
   }

   @Override
   public void accept(Consumer<StatusEffectWithDelay> consumer) {
      this.effects.ifPresent(effects -> effects.forEach(consumer));
   }
}
