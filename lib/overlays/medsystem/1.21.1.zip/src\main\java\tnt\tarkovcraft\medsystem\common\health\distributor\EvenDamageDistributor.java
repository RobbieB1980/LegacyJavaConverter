package tnt.tarkovcraft.medsystem.common.health.distributor;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import tnt.tarkovcraft.medsystem.common.health.DamageContext;
import tnt.tarkovcraft.medsystem.common.health.Limb;
import tnt.tarkovcraft.medsystem.common.health.calc.HitInfo;

public final class EvenDamageDistributor implements DamageDistributor {
   public static final EvenDamageDistributor INSTANCE = new EvenDamageDistributor();

   private EvenDamageDistributor() {
   }

   @Override
   public Map<Limb, Float> distribute(DamageContext context, float damage) {
      List<HitInfo> hits = context.getHits();
      float partDamage = damage / Math.max(1, hits.size());
      Map<Limb, Float> result = new HashMap<>();

      for (HitInfo hit : hits) {
         result.put(hit.limb(), partDamage);
      }

      return result;
   }
}
