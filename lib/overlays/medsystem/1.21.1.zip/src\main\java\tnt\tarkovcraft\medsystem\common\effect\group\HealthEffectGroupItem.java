package tnt.tarkovcraft.medsystem.common.effect.group;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.Locale;
import java.util.UUID;
import java.util.function.Consumer;
import net.minecraft.ChatFormatting;
import net.minecraft.core.UUIDUtil;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import tnt.tarkovcraft.medsystem.api.heal.SideEffect;
import tnt.tarkovcraft.medsystem.common.effect.StatusEffect;
import tnt.tarkovcraft.medsystem.common.effect.StatusEffectContext;
import tnt.tarkovcraft.medsystem.common.effect.util.EffectType;
import tnt.tarkovcraft.medsystem.common.init.MedSystemDamageTypes;

public record HealthEffectGroupItem(UUID effectId, float amount, int interval) implements EffectGroupItem {
   public static final MapCodec<HealthEffectGroupItem> CODEC = RecordCodecBuilder.<HealthEffectGroupItem>mapCodec(
      instance -> instance.group(
            UUIDUtil.CODEC.fieldOf("effect_id").forGetter(t -> t.effectId),
            Codec.FLOAT.fieldOf("amount").forGetter(t -> t.amount),
            Codec.INT.fieldOf("interval").forGetter(t -> t.interval)
         )
         .apply(instance, HealthEffectGroupItem::new)
   );

   public HealthEffectGroupItem(String uuid, float amount) {
      this(UUID.fromString(uuid), amount);
   }

   public HealthEffectGroupItem(UUID effectId, float amount) {
      this(effectId, amount, 20);
   }

   public HealthEffectGroupItem(String uuid, float amount, int interval) {
      this(UUID.fromString(uuid), amount, interval);
   }

   @Override
   public void init(EffectGroupHolder holder, StatusEffectContext context) {
   }

   @Override
   public void apply(EffectGroupHolder holder, StatusEffectContext context) {
      Level level = context.level();
      if (!level.isClientSide()) {
         long time = level.getGameTime();
         if (time % this.interval == 0L) {
            LivingEntity entity = context.entity();
            if (entity.isAlive()) {
               if (this.amount >= 0.0F) {
                  entity.heal(this.amount);
               } else {
                  DamageSource damageSource = MedSystemDamageTypes.causeToxinDamage(level.registryAccess());
                  entity.hurtServer((ServerLevel)level, damageSource, Mth.abs(this.amount));
               }
            }
         }
      }
   }

   @Override
   public void cleanup(EffectGroupHolder holder, StatusEffectContext context) {
   }

   @Override
   public void addInformation(EffectGroupHolder holder, Consumer<Component> tooltip, boolean isItemTooltip) {
      float perSecond = 20.0F / this.interval;
      MutableComponent value = Component.translatable(
         this.amount >= 0.0F ? "label.medsystem.health_recovery" : "label.medsystem.health_loss",
         new Object[]{Component.literal(String.format(Locale.ROOT, "%.1f", this.amount * perSecond))}
      );
      if (isItemTooltip) {
         tooltip.accept(
            SideEffect.createDescriptionComponent(
               this.amount > 0.0F ? EffectType.POSITIVE : (this.amount < 0.0F ? EffectType.NEGATIVE : EffectType.NEUTRAL),
               value,
               1.0F,
               holder.getDuration(),
               holder.getDelay()
            )
         );
      } else {
         tooltip.accept(value.append(" ").append(StatusEffect.getDurationLabel(holder.getDuration())).withStyle(ChatFormatting.DARK_GRAY));
      }
   }

   @Override
   public EffectGroupHolder tryToMergeWith(EffectGroupHolder current, EffectGroupHolder other) {
      EffectGroupItem item = other.getItem();
      return item instanceof HealthEffectGroupItem healthItem && this.effectId.equals(healthItem.effectId)
         ? new EffectGroupHolder(item, Math.max(current.getDelay(), other.getDelay()), Math.min(current.getDelay(), other.getDelay()))
         : null;
   }

   @Override
   public EffectGroupItem copy() {
      return new HealthEffectGroupItem(this.effectId, this.amount, this.interval);
   }

   @Override
   public MapCodec<? extends EffectGroupItem> codec() {
      return CODEC;
   }
}
