package tnt.tarkovcraft.medsystem.common.init;

import java.util.Collections;
import java.util.Optional;
import net.minecraft.core.Holder;
import net.neoforged.neoforge.registries.DeferredRegister;
import tnt.tarkovcraft.medsystem.common.effect.BleedStatusEffect;
import tnt.tarkovcraft.medsystem.common.effect.BloodImmuneReactionStatusEffect;
import tnt.tarkovcraft.medsystem.common.effect.BloodLossStatusEffect;
import tnt.tarkovcraft.medsystem.common.effect.ConcussionStatusEffect;
import tnt.tarkovcraft.medsystem.common.effect.FractureStatusEffect;
import tnt.tarkovcraft.medsystem.common.effect.FreshWoundStatusEffect;
import tnt.tarkovcraft.medsystem.common.effect.GroupStatusEffect;
import tnt.tarkovcraft.medsystem.common.effect.InjuryRecoveryStatusEffect;
import tnt.tarkovcraft.medsystem.common.effect.NegativeEffectProtectionStatusEffect;
import tnt.tarkovcraft.medsystem.common.effect.NegativeEffectsGroup;
import tnt.tarkovcraft.medsystem.common.effect.NeutralEffectsGroup;
import tnt.tarkovcraft.medsystem.common.effect.OverweightStatusEffect;
import tnt.tarkovcraft.medsystem.common.effect.PainReliefEffect;
import tnt.tarkovcraft.medsystem.common.effect.PainStatusEffect;
import tnt.tarkovcraft.medsystem.common.effect.PositiveEffectsGroup;
import tnt.tarkovcraft.medsystem.common.effect.StatusEffect;
import tnt.tarkovcraft.medsystem.common.effect.StatusEffectType;
import tnt.tarkovcraft.medsystem.common.effect.WoundStatusEffect;
import tnt.tarkovcraft.medsystem.common.effect.util.EffectType;
import tnt.tarkovcraft.medsystem.common.effect.util.EffectVisibility;

public final class MedSystemStatusEffects {
   public static final DeferredRegister<StatusEffectType<?>> REGISTRY = DeferredRegister.create(MedSystemRegistries.Keys.STATUS_EFFECT, "medsystem");
   public static final Holder<StatusEffectType<?>> PAIN_RELIEF = REGISTRY.register(
      "pain_relief",
      key -> StatusEffectType.builder(key, PainReliefEffect::new)
         .persist(PainReliefEffect.CODEC)
         .type(EffectType.POSITIVE)
         .setGlobal()
         .combineEffects(StatusEffect::maxDuration)
         .build()
   );
   public static final Holder<StatusEffectType<?>> PAIN = REGISTRY.register(
      "pain",
      key -> StatusEffectType.builder(key, PainStatusEffect::new)
         .persist(PainStatusEffect.CODEC)
         .type(EffectType.NEGATIVE)
         .setGlobal()
         .combineEffects(StatusEffect::replace)
         .setSpecial()
         .build()
   );
   public static final Holder<StatusEffectType<?>> FRACTURE = REGISTRY.register(
      "fracture",
      key -> StatusEffectType.<FractureStatusEffect>builder(key, FractureStatusEffect::new)
         .persist(FractureStatusEffect.CODEC)
         .type(EffectType.NEGATIVE)
         .combineEffects(FractureStatusEffect::mergeWithDurationLimits)
         .healPriority(30)
         .build()
   );
   public static final Holder<StatusEffectType<?>> INJURY_RECOVERY = REGISTRY.register(
      "injury_recovery",
      key -> StatusEffectType.<InjuryRecoveryStatusEffect>builder(key, InjuryRecoveryStatusEffect::new)
         .persist(InjuryRecoveryStatusEffect.CODEC)
         .type(EffectType.NEGATIVE)
         .visibility(EffectVisibility.UI)
         .combineEffects(InjuryRecoveryStatusEffect::merge)
         .healPriority(15)
         .build()
   );
   public static final Holder<StatusEffectType<?>> BLEED = REGISTRY.register(
      "bleed",
      key -> StatusEffectType.<BleedStatusEffect>builder(key, duration -> BleedStatusEffect.lightBleed(duration, Optional.empty()))
         .persist(BleedStatusEffect.CODEC)
         .type(EffectType.NEGATIVE)
         .healPriority(50)
         .combineEffects(BleedStatusEffect::higherStage)
         .build()
   );
   public static final Holder<StatusEffectType<?>> FRESH_WOUND = REGISTRY.register(
      "fresh_wound",
      key -> StatusEffectType.<FreshWoundStatusEffect>builder(key, FreshWoundStatusEffect::createTemplate)
         .persist(FreshWoundStatusEffect.CODEC)
         .type(EffectType.NEGATIVE)
         .healPriority(15)
         .combineEffects(FreshWoundStatusEffect::merge)
         .build()
   );
   public static final Holder<StatusEffectType<?>> OVERWEIGHT = REGISTRY.register(
      "overweight",
      key -> StatusEffectType.<OverweightStatusEffect>builder(key, duration -> new OverweightStatusEffect(false))
         .persist(OverweightStatusEffect.CODEC)
         .type(EffectType.NEGATIVE)
         .setGlobal()
         .combineEffects(StatusEffect::keep)
         .setSpecial()
         .build()
   );
   public static final Holder<StatusEffectType<?>> POSITIVE_EFFECTS_GROUP = REGISTRY.register(
      "positive_effects_group",
      key -> StatusEffectType.<PositiveEffectsGroup>builder(key, duration -> new PositiveEffectsGroup(Collections.emptyList()))
         .persist(PositiveEffectsGroup.CODEC)
         .type(EffectType.POSITIVE)
         .setGlobal()
         .combineEffects(GroupStatusEffect::merge)
         .setSpecial()
         .build()
   );
   public static final Holder<StatusEffectType<?>> NEUTRAL_EFFECTS_GROUP = REGISTRY.register(
      "neutral_effects_group",
      key -> StatusEffectType.<NeutralEffectsGroup>builder(key, duration -> new NeutralEffectsGroup(Collections.emptyList()))
         .persist(NeutralEffectsGroup.CODEC)
         .type(EffectType.NEUTRAL)
         .setGlobal()
         .combineEffects(GroupStatusEffect::merge)
         .setSpecial()
         .build()
   );
   public static final Holder<StatusEffectType<?>> NEGATIVE_EFFECTS_GROUP = REGISTRY.register(
      "negative_effects_group",
      key -> StatusEffectType.<NegativeEffectsGroup>builder(key, duration -> new NegativeEffectsGroup(Collections.emptyList()))
         .persist(NegativeEffectsGroup.CODEC)
         .type(EffectType.NEGATIVE)
         .setGlobal()
         .combineEffects(GroupStatusEffect::merge)
         .setSpecial()
         .build()
   );
   public static final Holder<StatusEffectType<?>> WOUND = REGISTRY.register(
      "wound",
      key -> StatusEffectType.builder(key, WoundStatusEffect::new)
         .persist(WoundStatusEffect.CODEC)
         .type(EffectType.NEGATIVE)
         .combineEffects(WoundStatusEffect::mergeWithScaling)
         .visibility(EffectVisibility.NEVER)
         .healPriority(15)
         .setGlobal()
         .build()
   );
   public static final Holder<StatusEffectType<?>> CONCUSSION = REGISTRY.register(
      "concussion",
      key -> StatusEffectType.builder(key, ConcussionStatusEffect::new)
         .persist(ConcussionStatusEffect.CODEC)
         .type(EffectType.NEGATIVE)
         .setGlobal()
         .healPriority(15)
         .combineEffects(StatusEffect::maxDuration)
         .build()
   );
   public static final Holder<StatusEffectType<?>> BLOODLOSS = REGISTRY.register(
      "bloodloss",
      key -> StatusEffectType.<BloodLossStatusEffect>builder(key, BloodLossStatusEffect::new)
         .persist(BloodLossStatusEffect.CODEC)
         .type(EffectType.NEGATIVE)
         .setGlobal()
         .setSpecial()
         .combineEffects(StatusEffect::replace)
         .build()
   );
   public static final Holder<StatusEffectType<?>> BLOOD_IMMUNE_REACTION = REGISTRY.register(
      "blood_immune_reaction",
      key -> StatusEffectType.<BloodImmuneReactionStatusEffect>builder(key, BloodImmuneReactionStatusEffect::new)
         .persist(BloodImmuneReactionStatusEffect.CODEC)
         .type(EffectType.NEGATIVE)
         .visibility(EffectVisibility.NEVER)
         .setGlobal()
         .setSpecial()
         .combineEffects(BloodImmuneReactionStatusEffect::mergeImmuneEffect)
         .build()
   );
   public static final Holder<StatusEffectType<?>> NEGATIVE_EFFECT_PROTECTION = REGISTRY.register(
      "negative_effect_protection",
      key -> StatusEffectType.builder(key, NegativeEffectProtectionStatusEffect::new)
         .persist(NegativeEffectProtectionStatusEffect.CODEC)
         .type(EffectType.POSITIVE)
         .visibility(EffectVisibility.NEVER)
         .setGlobal()
         .setSpecial()
         .combineEffects(StatusEffect::maxDuration)
         .build()
   );
}
