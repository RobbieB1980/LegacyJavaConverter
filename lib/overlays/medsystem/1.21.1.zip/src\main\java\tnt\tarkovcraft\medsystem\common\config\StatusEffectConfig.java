package tnt.tarkovcraft.medsystem.common.config;

import dev.toma.configuration.config.Configurable;
import dev.toma.configuration.config.UpdateRestrictions;
import dev.toma.configuration.config.Configurable.Comment;
import dev.toma.configuration.config.Configurable.DecimalRange;
import dev.toma.configuration.config.Configurable.Range;
import dev.toma.configuration.config.Configurable.Synchronized;
import dev.toma.configuration.config.Configurable.UpdateRestriction;
import dev.toma.configuration.config.Configurable.Gui.NumberFormat;
import dev.toma.configuration.config.Configurable.Gui.Slider;
import tnt.tarkovcraft.core.common.data.duration.Duration;

public final class StatusEffectConfig {
   @Configurable
   @Comment("Enables entryPoint effects such as bleeds, fractures and other effects")
   @Synchronized
   public boolean enableStatusEffects = true;
   @Configurable
   @Comment("Base chance for getting any type of bleed from '#medsystem:bleed_causing' damage type")
   @DecimalRange(min = 0.0, max = 1.0)
   @NumberFormat("0.0##")
   @Slider
   public float bleedChance = 0.025F;
   @Configurable
   @Comment({"Configure max bleed duration for effect stacking", "Set to 0 to disable all limits"})
   @Range(min = 0L)
   public int maxBleedDuration = 0;
   @Configurable
   @Comment("Bleed chance multiplier for items from '#medsystem:sharp_tools' tag - swords, spears, axes")
   @DecimalRange(min = 1.0, max = 10.0)
   @NumberFormat("0.0##")
   @Slider
   public float sharpToolBleedMultiplier = 5.0F;
   @Configurable
   @Comment("Base chance for getting fracture from '#medsystem:fracture_causing' damage type")
   @DecimalRange(min = 0.0, max = 1.0)
   @NumberFormat("0.0##")
   @Slider
   public float fractureChance = 0.03F;
   @Configurable
   @Comment({"Default duration of fracture status effect", "-1 means infinite duration"})
   @Range(min = -1L)
   public int fractureDuration = -1;
   @Configurable
   @Comment({"Configure max fracture duration for effect stacking", "Set to 0 to disable all limits"})
   @Range(min = 0L)
   public int maxFractureDuration = 0;
   @Configurable
   @Comment("How long it will take for fractures to heal after applying splints")
   @Range(min = 1L)
   @UpdateRestriction(UpdateRestrictions.GAME_RESTART)
   public int fractureRecoveryTime = Duration.minutes(5).tickValue();
   @Configurable
   @Comment("How long it will take for fractures to heal after applying bandages")
   @Range(min = 1L)
   @UpdateRestriction(UpdateRestrictions.GAME_RESTART)
   public int fractureRecoveryTimeBandage = Duration.minutes(15).tickValue();
   @Configurable
   @Comment("Fracture chance multiplier for items from '#medsystem:blunt_tools' tag - shovels, pickaxes, hoes and mace")
   @DecimalRange(min = 1.0, max = 10.0)
   @NumberFormat("0.0##")
   @Slider
   public float bluntToolFractureMultiplier = 5.0F;
   @Configurable
   @Comment("Allows scaling of injury recovery status effects when getting the effect repeatedly")
   public boolean allowInjuryRecoveryScaling = true;
   @Configurable
   @Comment({"Configure max injury recovery duration for effect stacking", "Set to 0 to disable all limits"})
   @Range(min = 0L)
   public int maxInjuryRecoveryDuration = 0;
   @Configurable
   public BleedConfiguration bleedConfiguration = new BleedConfiguration();

   public static int getStackedDuration(int effectDuration, int limit) {
      return limit > 0 ? Math.min(effectDuration, limit) : effectDuration;
   }
}
