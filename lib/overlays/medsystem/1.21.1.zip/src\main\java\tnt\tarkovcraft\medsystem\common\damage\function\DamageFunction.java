package tnt.tarkovcraft.medsystem.common.damage.function;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import java.util.function.Function;
import tnt.tarkovcraft.medsystem.common.health.calc.HitCalculationContext;
import tnt.tarkovcraft.medsystem.common.health.calc.HitCalculator;
import tnt.tarkovcraft.medsystem.common.init.MedSystemRegistries;

public interface DamageFunction {
   Codec<DamageFunction> CODEC = MedSystemRegistries.DAMAGE_FUNCTIONS.byNameCodec().dispatch("function", DamageFunction::codec, Function.identity());

   HitCalculator resolve(HitCalculationContext var1);

   MapCodec<? extends DamageFunction> codec();
}
