package tnt.tarkovcraft.medsystem;

import java.util.function.Supplier;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.damagesource.DamageEffects;
import net.neoforged.fml.common.asm.enumextension.EnumProxy;

public final class MedicalSystemEnumExtensions {
   public static final EnumProxy<DamageEffects> MEDSYSTEM_NONE = new EnumProxy(
      DamageEffects.class, new Object[]{"medsystem:none", (Supplier<SoundEvent>)() -> null}
   );
}
