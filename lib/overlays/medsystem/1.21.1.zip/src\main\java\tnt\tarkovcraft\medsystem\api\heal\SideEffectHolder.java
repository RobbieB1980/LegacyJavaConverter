package tnt.tarkovcraft.medsystem.api.heal;

import com.google.common.base.Preconditions;
import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.function.Consumer;
import java.util.function.Function;
import net.minecraft.ChatFormatting;
import net.minecraft.core.component.DataComponentGetter;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.ComponentSerialization;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.Item.TooltipContext;
import net.minecraft.world.item.component.TooltipProvider;
import net.minecraft.world.item.consume_effects.ConsumeEffect;
import net.minecraft.world.level.Level;
import org.jspecify.annotations.Nullable;
import tnt.tarkovcraft.core.common.data.duration.TickValue;
import tnt.tarkovcraft.medsystem.common.effect.NegativeEffectsGroup;
import tnt.tarkovcraft.medsystem.common.effect.NeutralEffectsGroup;
import tnt.tarkovcraft.medsystem.common.effect.PositiveEffectsGroup;
import tnt.tarkovcraft.medsystem.common.effect.StatusEffect;
import tnt.tarkovcraft.medsystem.common.effect.group.EffectGroupHolder;
import tnt.tarkovcraft.medsystem.common.health.HealthContainer;
import tnt.tarkovcraft.medsystem.common.health.Limb;
import tnt.tarkovcraft.medsystem.common.init.MedSystemDataAttachments;
import tnt.tarkovcraft.medsystem.common.init.MedSystemItemComponents;

public record SideEffectHolder(
   Optional<Component> title, List<SideEffect> sideEffects, List<ConsumeEffect> consumeEffects, List<Component> additionalLabels, boolean hideTooltip
) implements TooltipProvider {
   public static final Component DEFAULT_TITLE = Component.translatable("tooltip.medsystem.heal_attributes.side_effects.title").withStyle(ChatFormatting.GRAY);
   public static final Component ITEM_TITLE = Component.translatable("tooltip.medsystem.heal_attributes.side_effects.title_item")
      .withStyle(ChatFormatting.GRAY);
   public static final Component USAGE_TITLE = Component.translatable("tooltip.medsystem.heal_attributes.side_effects.title_usage")
      .withStyle(ChatFormatting.GRAY);
   public static final SideEffectHolder EMPTY = new SideEffectHolder(
      Optional.empty(), Collections.emptyList(), Collections.emptyList(), Collections.emptyList(), true
   );
   public static final MapCodec<SideEffectHolder> MAP_CODEC = RecordCodecBuilder.<SideEffectHolder>mapCodec(
      instance -> instance.group(
            ComponentSerialization.CODEC.optionalFieldOf("title").forGetter(t -> t.title),
            SideEffect.CODEC.listOf().fieldOf("effects").forGetter(t -> t.sideEffects),
            ConsumeEffect.CODEC.listOf().optionalFieldOf("consume_effects", Collections.emptyList()).forGetter(t -> t.consumeEffects),
            ComponentSerialization.CODEC.listOf().optionalFieldOf("additional_labels", Collections.emptyList()).forGetter(t -> t.additionalLabels),
            Codec.BOOL.optionalFieldOf("hide_tooltip", false).forGetter(t -> t.hideTooltip)
         )
         .apply(instance, SideEffectHolder::new)
   );
   public static final Codec<SideEffectHolder> CODEC = MAP_CODEC.codec();

   public static SideEffectHolder.Builder builder() {
      return new SideEffectHolder.Builder();
   }

   public static SideEffectHolder.Builder withItemUsage() {
      return builder().title(USAGE_TITLE);
   }

   public static SideEffectHolder empty() {
      return EMPTY;
   }

   public void onConsume(ItemStack itemStack, LivingEntity target, HealthContainer container, @Nullable Limb part) {
      this.apply(target, null, container, part);
      Level level = target.level();
      this.consumeEffects.forEach(effect -> effect.apply(level, itemStack, target));
   }

   public void apply(LivingEntity target, @Nullable DamageSource source, HealthContainer container, @Nullable Limb part) {
      for (SideEffect effect : this.sideEffects) {
         effect.apply(target, source, container, part);
      }
   }

   public static SideEffectHolder fromDamage(DamageSource source) {
      if (source.isDirect()) {
         ItemStack stack = source.getWeaponItem();
         return stack != null && !stack.isEmpty() ? (SideEffectHolder)stack.get(MedSystemItemComponents.SIDE_EFFECTS) : null;
      } else {
         Entity projectile = source.getDirectEntity();
         return projectile != null && projectile.hasData(MedSystemDataAttachments.SIDE_EFFECTS)
            ? (SideEffectHolder)projectile.getData(MedSystemDataAttachments.SIDE_EFFECTS)
            : null;
      }
   }

   public void addToTooltip(TooltipContext context, Consumer<Component> tooltipAdder, TooltipFlag flag, DataComponentGetter componentGetter) {
      if (!this.hideTooltip) {
         Component title = this.title.orElse(DEFAULT_TITLE);
         this.additionalLabels.forEach(tooltipAdder);
         tooltipAdder.accept(title);
         this.sideEffects.forEach(effect -> effect.addToTooltip(context, tooltipAdder, flag, componentGetter));
      }
   }

   public static final class Builder {
      private Component title;
      private final List<SideEffect> sideEffects = new ArrayList<>();
      private final List<ConsumeEffect> consumeEffects = new ArrayList<>();
      private final List<Component> additionalLabels = new ArrayList<>();
      private boolean hideTooltip = false;

      private Builder() {
      }

      public SideEffectHolder.Builder title(Component title) {
         this.title = title;
         return this;
      }

      public SideEffectHolder.Builder noTooltip() {
         this.hideTooltip = true;
         return this;
      }

      public SideEffectHolder.Builder delayed(float chance, int duration, int delay, StatusEffect effect) {
         StatusEffect statusEffect = effect.copy();
         statusEffect.setDuration(duration);
         this.sideEffects.add(new SideEffect(chance, delay, statusEffect));
         return this;
      }

      public SideEffectHolder.Builder delayed(float chance, TickValue duration, int delay, StatusEffect effect) {
         return this.delayed(chance, duration.tickValue(), delay, effect);
      }

      public SideEffectHolder.Builder delayed(float chance, int duration, TickValue delay, StatusEffect effect) {
         return this.delayed(chance, duration, delay.tickValue(), effect);
      }

      public SideEffectHolder.Builder delayed(float chance, TickValue duration, TickValue delay, StatusEffect effect) {
         return this.delayed(chance, duration.tickValue(), delay.tickValue(), effect);
      }

      public SideEffectHolder.Builder immediate(float chance, int duration, StatusEffect effect) {
         return this.delayed(chance, duration, 0, effect);
      }

      public SideEffectHolder.Builder immediate(float chance, TickValue duration, StatusEffect effect) {
         return this.immediate(chance, duration.tickValue(), effect);
      }

      public SideEffectHolder.Builder delayed(TickValue duration, TickValue delay, StatusEffect effect) {
         return this.delayed(1.0F, duration.tickValue(), delay.tickValue(), effect);
      }

      public SideEffectHolder.Builder delayed(int duration, TickValue delay, StatusEffect effect) {
         return this.delayed(1.0F, duration, delay.tickValue(), effect);
      }

      public SideEffectHolder.Builder delayed(TickValue duration, int delay, StatusEffect effect) {
         return this.delayed(1.0F, duration.tickValue(), delay, effect);
      }

      public SideEffectHolder.Builder delayed(int duration, int delay, StatusEffect effect) {
         return this.delayed(1.0F, duration, delay, effect);
      }

      public SideEffectHolder.Builder immediate(TickValue duration, StatusEffect effect) {
         return this.immediate(1.0F, duration.tickValue(), effect);
      }

      public SideEffectHolder.Builder infinite(float chance, StatusEffect effect) {
         return this.immediate(chance, -1, effect);
      }

      public SideEffectHolder.Builder infinite(StatusEffect effect) {
         return this.immediate(1.0F, -1, effect);
      }

      public SideEffectHolder.Builder infiniteDelayed(float chance, int delay, StatusEffect effect) {
         return this.delayed(chance, -1, delay, effect);
      }

      public SideEffectHolder.Builder infiniteDelayed(float chance, TickValue delay, StatusEffect effect) {
         return this.infiniteDelayed(chance, delay.tickValue(), effect);
      }

      public SideEffectHolder.Builder infiniteDelayed(TickValue delay, StatusEffect effect) {
         return this.infiniteDelayed(delay.tickValue(), effect);
      }

      public SideEffectHolder.Builder infiniteDelayed(int delay, StatusEffect effect) {
         return this.delayed(1.0F, -1, delay, effect);
      }

      public SideEffectHolder.Builder buffs(Consumer<EffectGroupHolder.Factory> builder) {
         return this.infinite(PositiveEffectsGroup.createTemplate(builder));
      }

      public SideEffectHolder.Builder neutral(Consumer<EffectGroupHolder.Factory> builder) {
         return this.infinite(NeutralEffectsGroup.createTemplate(builder));
      }

      public SideEffectHolder.Builder debuffs(Consumer<EffectGroupHolder.Factory> builder) {
         return this.infinite(NegativeEffectsGroup.createTemplate(builder));
      }

      public SideEffectHolder.Builder consumeEffect(ConsumeEffect effect) {
         this.consumeEffects.add(effect);
         return this;
      }

      public SideEffectHolder.Builder label(Component label) {
         this.additionalLabels.add(label);
         return this;
      }

      public <E extends ConsumeEffect> SideEffectHolder.Builder consumeEffectWithLabel(E effect, Function<E, Component> label) {
         return this.consumeEffect(effect).label(label.apply(effect));
      }

      public SideEffectHolder build() {
         Preconditions.checkState(!this.sideEffects.isEmpty(), "sideEffects cannot be empty");
         return new SideEffectHolder(Optional.ofNullable(this.title), this.sideEffects, this.consumeEffects, this.additionalLabels, this.hideTooltip);
      }
   }
}
