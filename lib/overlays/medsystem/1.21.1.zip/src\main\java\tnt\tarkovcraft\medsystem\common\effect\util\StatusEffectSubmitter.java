package tnt.tarkovcraft.medsystem.common.effect.util;

import java.util.List;
import java.util.function.Consumer;
import tnt.tarkovcraft.core.common.data.duration.TickValue;
import tnt.tarkovcraft.medsystem.common.effect.StatusEffect;

public interface StatusEffectSubmitter {
   StatusEffectSubmitter NOOP = StatusEffectSubmitter.Noop.INSTANCE;

   void submit(int var1, StatusEffect var2);

   void clear();

   void accept(Consumer<StatusEffectWithDelay> var1);

   default void submit(TickValue delay, StatusEffect template) {
      this.submit(delay.tickValue(), template);
   }

   default void submitImmediate(StatusEffect template) {
      this.submit(0, template);
   }

   static StatusEffectSubmitter list(List<StatusEffectWithDelay> list) {
      return new ListStatusEffectSubmitter(list);
   }

   static StatusEffectSubmitter list() {
      return new ListStatusEffectSubmitter();
   }

   enum Noop implements StatusEffectSubmitter {
      INSTANCE;

      @Override
      public void submit(int delay, StatusEffect template) {
      }

      @Override
      public void clear() {
      }

      @Override
      public void accept(Consumer<StatusEffectWithDelay> consumer) {
      }
   }
}
