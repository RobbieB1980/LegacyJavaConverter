package tnt.tarkovcraft.medsystem.client.screen;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.client.network.ClientPacketDistributor;
import org.joml.Vector2f;
import org.joml.Vector4i;
import tnt.tarkovcraft.core.api.client.SynchronizableScreen;
import tnt.tarkovcraft.core.api.client.SynchronizableScreen.DataSource;
import tnt.tarkovcraft.core.client.screen.renderable.LabelRenderable;
import tnt.tarkovcraft.core.client.screen.renderable.ShapeRenderable;
import tnt.tarkovcraft.core.util.HorizontalAlignment;
import tnt.tarkovcraft.core.util.helper.TextHelper;
import tnt.tarkovcraft.medsystem.api.heal.HealItemAttributes;
import tnt.tarkovcraft.medsystem.client.MedicalSystemClient;
import tnt.tarkovcraft.medsystem.client.config.HealthOverlayConfiguration;
import tnt.tarkovcraft.medsystem.client.overlay.HealthLayer;
import tnt.tarkovcraft.medsystem.client.screen.widget.LimbHealthWidget;
import tnt.tarkovcraft.medsystem.client.screen.widget.LimbWidget;
import tnt.tarkovcraft.medsystem.common.effect.StatusEffect;
import tnt.tarkovcraft.medsystem.common.effect.StatusEffectType;
import tnt.tarkovcraft.medsystem.common.effect.util.EffectVisibility;
import tnt.tarkovcraft.medsystem.common.health.HealthContainer;
import tnt.tarkovcraft.medsystem.common.health.HealthContainerDefinition;
import tnt.tarkovcraft.medsystem.common.health.HealthContainerDisplay;
import tnt.tarkovcraft.medsystem.common.health.Limb;
import tnt.tarkovcraft.medsystem.common.init.MedSystemDataAttachments;
import tnt.tarkovcraft.medsystem.common.init.MedSystemItemComponents;
import tnt.tarkovcraft.medsystem.common.item.InteractionTarget;
import tnt.tarkovcraft.medsystem.network.message.C2S_SelectLimb;

public class SelectLimbScreen extends Screen implements SynchronizableScreen {
   public static final Component TITLE = TextHelper.createScreenTitle("medsystem", "select_body_part").withStyle(ChatFormatting.BOLD).withColor(-2039584);
   public static final Component LABEL_ERROR = TextHelper.createScreenComponent("medsystem", "select_body_part", "error.invalid_item");
   public static final Component LABEL_NOT_HEALABLE = TextHelper.createScreenComponent("medsystem", "select_body_part", "error.not_healable")
      .withStyle(ChatFormatting.RED);
   public static final Component LABEL_CLICK_TO_SELECT = TextHelper.createScreenComponent("medsystem", "select_body_part", "text.click_to_select")
      .withStyle(ChatFormatting.GREEN);
   private final boolean selfHealing;
   private final int entityId;

   public SelectLimbScreen(boolean selfHealing, int entityID) {
      super(TITLE);
      this.selfHealing = selfHealing;
      this.entityId = entityID;
   }

   public void sync(DataSource source) {
      if (source.equals(HealthContainer.HEALTH)) {
         this.init(this.width, this.height);
      }
   }

   protected void init() {
      ItemStack itemStack = this.minecraft.player.getMainHandItem();
      Component subtitle;
      LivingEntity target;
      if (this.selfHealing) {
         subtitle = Component.translatable("label.medsystem.healing.self.target");
         target = this.minecraft.player;
      } else {
         Entity entity = this.minecraft.level.getEntity(this.entityId);
         if (!(entity instanceof LivingEntity livingEntity)) {
            this.minecraft.gui.setScreen(null);
            return;
         }

         subtitle = Component.translatable("label.medsystem.healing.other.target", new Object[]{entity.getDisplayName()}).withStyle(ChatFormatting.YELLOW);
         target = livingEntity;
      }

      this.addRenderableOnly(new ShapeRenderable(0, 0, this.width, this.height, -1157627904));
      LabelRenderable titleLabel = (LabelRenderable)this.addRenderableOnly(LabelRenderable.fromComponent(0, 0, this.width, 20, this.font, TITLE));
      titleLabel.setShadow(true);
      titleLabel.setTextColor(-1);
      titleLabel.setHorizontalAlignment(HorizontalAlignment.CENTER);
      LabelRenderable subtitleLabel = (LabelRenderable)this.addRenderableOnly(LabelRenderable.fromComponent(0, 20, this.width, 10, this.font, subtitle));
      subtitleLabel.setShadow(true);
      subtitleLabel.setTextColor(-1);
      subtitleLabel.setHorizontalAlignment(HorizontalAlignment.CENTER);
      if (itemStack.isEmpty()) {
         this.addError();
      } else {
         HealItemAttributes attributes = (HealItemAttributes)itemStack.get(MedSystemItemComponents.HEAL_ATTRIBUTES);
         if (attributes == null) {
            this.addError();
         } else {
            HealthContainer container = (HealthContainer)target.getData(MedSystemDataAttachments.HEALTH_CONTAINER);
            HealthContainerDefinition definition = container.getDefinition();
            HealthContainerDisplay display = definition.display();
            Vector2f center = new Vector2f(this.width / 2.0F, this.height / 2.0F);
            float scale = this.width / 256.0F;
            List<LimbHealthWidget> healthWidgets = new ArrayList<>();
            display.accept(
               (limbCode, data) -> {
                  Limb limb = container.getLimbByCode(limbCode);
                  Vector4i rect = data.getGuiPos(scale, center);
                  boolean isLimbHealable = attributes.canUseOnLimb(limb, itemStack, container, target);
                  LimbWidget widget = (LimbWidget)this.addRenderableWidget(new LimbWidget(rect.x, rect.y, rect.z, rect.w, limb, this.font));
                  widget.setScale(3);
                  widget.setColorProvider(
                     value -> {
                        HealthOverlayConfiguration overlay = MedicalSystemClient.getConfig().healthOverlay;
                        return isLimbHealable
                           ? HealthLayer.getColor(overlay.deadLimbColor, overlay.colorSchema, value) | 0xFF000000
                           : Integer.decode(overlay.deadLimbColor) | 0xFF000000;
                     }
                  );
                  widget.addTooltip(
                     limb.getDisplayName()
                        .copy()
                        .withStyle(new ChatFormatting[]{ChatFormatting.BOLD, isLimbHealable ? ChatFormatting.GREEN : ChatFormatting.RED})
                  );
                  List<StatusEffect> effects = limb.getStatusEffects()
                     .getEffectsStream()
                     .filter(ef -> StatusEffectType.isVisible(ef, EffectVisibility.UI))
                     .toList();
                  int healthWidth = 80;
                  int healthHeight = effects.isEmpty() ? 20 : 33;
                  int xOffset = (int)(rect.x + rect.z / 2.0F - center.x);
                  int healthX = HealthScreen.getHealthLabelWidgetX(xOffset, rect.x, healthWidth, rect.z);
                  int healthY = rect.y + (rect.w - healthHeight) / 2;
                  LimbHealthWidget healthWidget = new LimbHealthWidget(healthX, healthY, healthWidth, healthHeight, this.font, limb);
                  healthWidget.setEffects(effects);
                  healthWidget.setFrameColor(isLimbHealable ? widget.getColor() : -16777216);
                  healthWidget.setFrameHoverColor(isLimbHealable ? -256 : -16777216);
                  healthWidget.setTextColor(isLimbHealable ? widget.getColor() : -12303292);
                  healthWidget.setEffectDetail(false);
                  healthWidget.setTextHoverColor(isLimbHealable ? -256 : -6710887);
                  healthWidget.setClickListener(() -> this.limbClicked(limb));
                  healthWidgets.add(healthWidget);
                  if (isLimbHealable) {
                     widget.setOnClick(() -> this.limbClicked(limb));
                     widget.addTooltip(LABEL_CLICK_TO_SELECT);
                  } else {
                     widget.addTooltip(LABEL_NOT_HEALABLE);
                  }
               }
            );
            healthWidgets.forEach(x$0 -> this.addRenderableWidget(x$0));
         }
      }
   }

   public boolean isPauseScreen() {
      return false;
   }

   private void limbClicked(Limb part) {
      InteractionTarget target = new InteractionTarget(this.selfHealing, this.entityId, part.getLimbCode());
      ClientPacketDistributor.sendToServer(new C2S_SelectLimb(target), new CustomPacketPayload[0]);
      this.minecraft.gui.setScreen(null);
   }

   private void addError() {
      LabelRenderable error = (LabelRenderable)this.addRenderableOnly(LabelRenderable.fromComponent(0, 0, this.width, this.height, this.font, LABEL_ERROR));
      error.setHorizontalAlignment(HorizontalAlignment.CENTER);
      error.setTextColor(-65536);
      error.setShadow(true);
   }
}
