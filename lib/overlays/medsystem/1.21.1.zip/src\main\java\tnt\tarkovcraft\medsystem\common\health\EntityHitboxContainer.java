package tnt.tarkovcraft.medsystem.common.health;

import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.List;
import java.util.Map;
import java.util.stream.Stream;
import net.minecraft.util.Mth;
import net.minecraft.util.StringRepresentable;
import net.minecraft.util.StringRepresentable.EnumCodec;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import tnt.tarkovcraft.medsystem.common.health.calc.PositionedAABB;

public record EntityHitboxContainer(Map<String, EntityHitboxContainer.LimbHitboxContainer> definitions) {
   public static final Codec<EntityHitboxContainer> CODEC = Codec.unboundedMap(Codec.STRING, EntityHitboxContainer.LimbHitboxContainer.CODEC)
      .xmap(EntityHitboxContainer::new, EntityHitboxContainer::definitions);

   public EntityHitboxContainer.LimbHitboxDefinition getLimbHitbox(String limbCode, String state) {
      EntityHitboxContainer.LimbHitboxContainer container = this.definitions.get(limbCode);
      return container.getByStateOrDefault(state);
   }

   public Stream<EntityHitboxContainer.LimbHitboxDefinition> getLimbHitboxesStream(String state) {
      return this.definitions.values().stream().map(container -> container.getByStateOrDefault(state));
   }

   public List<EntityHitboxContainer.LimbHitboxDefinition> getBaseHitboxes(String state) {
      return this.getLimbHitboxesStream(state).toList();
   }

   public List<AABB> getWorldSpaceHitboxes(String state, LivingEntity context) {
      return this.getLimbHitboxesStream(state).map(hitbox -> hitbox.toWorldSpaceHitbox(context)).toList();
   }

   public record LimbHitboxContainer(Map<String, EntityHitboxContainer.LimbHitboxDefinition> hitboxMap) {
      public static final Codec<EntityHitboxContainer.LimbHitboxContainer> CODEC = Codec.unboundedMap(
            Codec.STRING, EntityHitboxContainer.LimbHitboxDefinition.CODEC
         )
         .xmap(EntityHitboxContainer.LimbHitboxContainer::new, EntityHitboxContainer.LimbHitboxContainer::hitboxMap)
         .validate(
            container -> !container.hitboxMap().containsKey("default") ? DataResult.error(() -> "No default hitbox defined") : DataResult.success(container)
         );

      public EntityHitboxContainer.LimbHitboxDefinition getByStateOrDefault(String state) {
         return this.hitboxMap.getOrDefault(state, this.hitboxMap.get("default"));
      }
   }

   public record LimbHitboxDefinition(EntityHitboxContainer.RotationMode pitch, EntityHitboxContainer.RotationMode yaw, PositionedAABB aabb) {
      public static final Codec<EntityHitboxContainer.LimbHitboxDefinition> CODEC = RecordCodecBuilder.<EntityHitboxContainer.LimbHitboxDefinition>create(
         instance -> instance.group(
               EntityHitboxContainer.RotationMode.CODEC
                  .optionalFieldOf("pitch", EntityHitboxContainer.RotationMode.NONE)
                  .forGetter(EntityHitboxContainer.LimbHitboxDefinition::pitch),
               EntityHitboxContainer.RotationMode.CODEC
                  .optionalFieldOf("yaw", EntityHitboxContainer.RotationMode.NONE)
                  .forGetter(EntityHitboxContainer.LimbHitboxDefinition::yaw),
               PositionedAABB.VEC_COMPONENT_CODEC.fieldOf("aabb").forGetter(EntityHitboxContainer.LimbHitboxDefinition::aabb)
            )
            .apply(instance, EntityHitboxContainer.LimbHitboxDefinition::new)
      );

      public AABB toWorldSpaceHitbox(LivingEntity entity) {
         PositionedAABB aabb = this.getWithTransforms(entity);
         return aabb.move(entity.position()).aabb();
      }

      public PositionedAABB getWithTransforms(LivingEntity source) {
         return this.yaw.apply(source, this.pitch.apply(source, this.aabb));
      }

      public PositionedAABB getStatic() {
         return this.aabb;
      }
   }

   public enum RotationMode implements StringRepresentable {
      NONE("none", EntityHitboxContainer.TransformFunction.IDENTITY),
      PITCH_VIEW("pitch_view", EntityHitboxContainer.RotationMode::pivotRotatePitch),
      YAW_VIEW("yaw_view", (e, aabb) -> rotateY(e.getYHeadRot(), aabb)),
      YAW_BODY("yaw_body", (e, aabb) -> rotateY(Mth.wrapDegrees(e.yBodyRot), aabb));

      public static final EnumCodec<EntityHitboxContainer.RotationMode> CODEC = StringRepresentable.fromEnum(EntityHitboxContainer.RotationMode::values);
      private final String serializedName;
      private final EntityHitboxContainer.TransformFunction transform;

      RotationMode(String serializedName, EntityHitboxContainer.TransformFunction transform) {
         this.serializedName = serializedName;
         this.transform = transform;
      }

      public PositionedAABB apply(LivingEntity entity, PositionedAABB aabb) {
         return this.transform.apply(entity, aabb);
      }

      public String getSerializedName() {
         return this.serializedName;
      }

      private static PositionedAABB pivotRotatePitch(LivingEntity src, PositionedAABB aabb) {
         float xRot = src.getXRot();
         Vec3 pivot = aabb.center().subtract(0.0, aabb.height() / 2.0, 0.0);
         return aabb.pivotRotateX(-xRot * (float) Math.PI / 180.0F, pivot);
      }

      private static PositionedAABB rotateY(float rotation, PositionedAABB aabb) {
         return aabb.rotateY(-rotation * (float) Math.PI / 180.0F);
      }
   }

   @FunctionalInterface
   public interface TransformFunction {
      EntityHitboxContainer.TransformFunction IDENTITY = (src, aabb) -> aabb;

      PositionedAABB apply(LivingEntity var1, PositionedAABB var2);
   }
}
