package tnt.tarkovcraft.medsystem.common.health_event.condition;

import com.mojang.serialization.DataResult;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.Optional;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.tags.TagKey;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageType;
import tnt.tarkovcraft.medsystem.common.health.DamageContext;
import tnt.tarkovcraft.medsystem.common.health_event.HealthEventContext;
import tnt.tarkovcraft.medsystem.common.health_event.HealthEventParams;
import tnt.tarkovcraft.medsystem.common.health_event.HealthEventResult;

public record IsDamageTypeEventCondition(Optional<TagKey<DamageType>> tag, Optional<Identifier> identifier) implements HealthEventCondition {
   public static final MapCodec<IsDamageTypeEventCondition> CODEC = RecordCodecBuilder.<IsDamageTypeEventCondition>mapCodec(
         instance -> instance.group(
               TagKey.codec(Registries.DAMAGE_TYPE).optionalFieldOf("tag").forGetter(IsDamageTypeEventCondition::tag),
               Identifier.CODEC.optionalFieldOf("id").forGetter(IsDamageTypeEventCondition::identifier)
            )
            .apply(instance, IsDamageTypeEventCondition::new)
      )
      .validate(
         condition -> condition.tag().isEmpty() && condition.identifier().isEmpty()
            ? DataResult.error(() -> "Either 'tag' or 'id' attribute must be defined for damage type condition")
            : DataResult.success(condition)
      );

   @Override
   public HealthEventResult test(HealthEventContext ctx) {
      DamageContext context = ctx.getParameter(HealthEventParams.DAMAGE_CONTEXT);
      if (context == null) {
         return HealthEventResult.INVALID;
      }

      DamageSource source = context.getSource();
      return this.tag.isPresent()
         ? HealthEventResult.condition(this.tag.<Boolean>map(source::is).orElse(false))
         : HealthEventResult.condition(this.identifier.<Boolean>map(value -> source.is(ResourceKey.create(Registries.DAMAGE_TYPE, value))).orElse(false));
   }

   @Override
   public MapCodec<? extends HealthEventCondition> codec() {
      return CODEC;
   }
}
