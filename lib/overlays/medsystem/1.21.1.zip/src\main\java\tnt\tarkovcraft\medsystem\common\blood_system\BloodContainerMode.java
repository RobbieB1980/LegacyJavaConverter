package tnt.tarkovcraft.medsystem.common.blood_system;

import com.mojang.serialization.Codec;
import io.netty.buffer.ByteBuf;
import java.util.function.IntFunction;
import net.minecraft.network.chat.Component;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.util.ByIdMap;
import net.minecraft.util.StringRepresentable;
import net.minecraft.util.ByIdMap.OutOfBoundsStrategy;
import tnt.tarkovcraft.core.util.helper.Helper;

public enum BloodContainerMode implements StringRepresentable {
   TRANSFUSION("transfusion"),
   EXTRACTION("extraction"),
   DRAIN("drain");

   public static final Codec<BloodContainerMode> CODEC = StringRepresentable.fromEnum(BloodContainerMode::values);
   public static final IntFunction<BloodContainerMode> BY_ID = ByIdMap.continuous(Enum::ordinal, values(), OutOfBoundsStrategy.WRAP);
   public static final StreamCodec<ByteBuf, BloodContainerMode> STREAM_CODEC = ByteBufCodecs.idMapper(BY_ID, Enum::ordinal);
   private final String name;
   private final Component label;
   private final String actionLabelKey;

   BloodContainerMode(String name) {
      this.name = name;
      this.label = Component.translatable("label.medsystem.blood_container.mode." + this.name);
      this.actionLabelKey = "label.medsystem.blood_container.mode." + this.name + ".action";
   }

   public Component getLabel() {
      return this.label;
   }

   public Component getActionLabel(Object... arguments) {
      return Component.translatable(this.actionLabelKey, arguments);
   }

   public boolean isDraining() {
      return this == DRAIN;
   }

   public BloodContainerMode next(BloodContainer container) {
      BloodContainerMode next = (BloodContainerMode)Helper.nextEnum(this);
      return !container.refillable() && next == EXTRACTION ? (BloodContainerMode)Helper.nextEnum(next) : next;
   }

   public String getSerializedName() {
      return this.name;
   }
}
