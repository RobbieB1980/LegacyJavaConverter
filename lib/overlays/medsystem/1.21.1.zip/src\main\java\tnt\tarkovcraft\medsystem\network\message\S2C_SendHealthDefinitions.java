package tnt.tarkovcraft.medsystem.network.message;

import com.mojang.serialization.DataResult;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NbtOps;
import net.minecraft.nbt.Tag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload.Type;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.EntityType;
import net.neoforged.neoforge.network.handling.IPayloadContext;
import tnt.tarkovcraft.medsystem.MedicalSystem;
import tnt.tarkovcraft.medsystem.common.health.HealthContainerDefinition;
import tnt.tarkovcraft.medsystem.network.MedicalSystemNetwork;

public record S2C_SendHealthDefinitions(Map<EntityType<?>, HealthContainerDefinition> definitionMap) implements CustomPacketPayload {
   public static final Identifier PACKET_ID = MedicalSystemNetwork.createId(S2C_SendHealthDefinitions.class);
   public static final Type<S2C_SendHealthDefinitions> TYPE = new Type(PACKET_ID);
   public static final StreamCodec<FriendlyByteBuf, S2C_SendHealthDefinitions> CODEC = StreamCodec.of(
      (buffer, value) -> value.encode(buffer), S2C_SendHealthDefinitions::decode
   );

   public Type<? extends CustomPacketPayload> type() {
      return TYPE;
   }

   private void encode(FriendlyByteBuf buf) {
      int pairs = this.definitionMap.size();
      buf.writeInt(pairs);

      for (Entry<EntityType<?>, HealthContainerDefinition> entry : this.definitionMap.entrySet()) {
         buf.writeIdentifier(BuiltInRegistries.ENTITY_TYPE.getKey(entry.getKey()));
         DataResult<Tag> result = HealthContainerDefinition.CODEC.encodeStart(NbtOps.INSTANCE, entry.getValue());
         CompoundTag tag = new CompoundTag();
         tag.put("data", (Tag)result.getOrThrow());
         buf.writeNbt(tag);
      }
   }

   private static S2C_SendHealthDefinitions decode(FriendlyByteBuf buf) {
      int pairs = buf.readInt();
      Map<EntityType<?>, HealthContainerDefinition> map = new HashMap<>(pairs);

      for (int i = 0; i < pairs; i++) {
         Identifier id = buf.readIdentifier();
         EntityType<?> type = (EntityType<?>)BuiltInRegistries.ENTITY_TYPE.getValue(id);
         CompoundTag tag = buf.readNbt();
         DataResult<HealthContainerDefinition> result = HealthContainerDefinition.CODEC.parse(NbtOps.INSTANCE, tag.get("data"));
         HealthContainerDefinition definition = (HealthContainerDefinition)result.getOrThrow();
         map.put(type, definition);
      }

      return new S2C_SendHealthDefinitions(map);
   }

   public void handleMessage(IPayloadContext context) {
      MedicalSystem.HEALTH_SYSTEM.importServerData(this.definitionMap);
   }
}
