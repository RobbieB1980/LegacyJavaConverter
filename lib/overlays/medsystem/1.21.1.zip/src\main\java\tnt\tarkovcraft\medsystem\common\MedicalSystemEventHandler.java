package tnt.tarkovcraft.medsystem.common;

import java.util.List;
import java.util.function.Consumer;
import net.minecraft.core.RegistryAccess;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.tags.TagKey;
import net.minecraft.util.RandomSource;
import net.minecraft.util.TriState;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.Item.TooltipContext;
import net.minecraft.world.item.component.TooltipDisplay;
import net.minecraft.world.level.Level;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.entity.EntityJoinLevelEvent;
import net.neoforged.neoforge.event.entity.EntityMountEvent;
import net.neoforged.neoforge.event.entity.EntityEvent.Size;
import net.neoforged.neoforge.event.entity.living.LivingChangeTargetEvent;
import net.neoforged.neoforge.event.entity.living.LivingDeathEvent;
import net.neoforged.neoforge.event.entity.living.LivingHealEvent;
import net.neoforged.neoforge.event.entity.living.LivingEntityUseItemEvent.Finish;
import net.neoforged.neoforge.event.entity.player.ItemTooltipEvent;
import net.neoforged.neoforge.event.entity.player.ItemEntityPickupEvent.Pre;
import tnt.tarkovcraft.core.api.event.EntityWeightUpdateEvent;
import tnt.tarkovcraft.core.api.event.StaminaEvent.AfterJump;
import tnt.tarkovcraft.core.api.event.StaminaEvent.AfterSprint;
import tnt.tarkovcraft.core.api.event.StaminaEvent.CanSprint;
import tnt.tarkovcraft.medsystem.MedicalSystem;
import tnt.tarkovcraft.medsystem.api.heal.SideEffectHolder;
import tnt.tarkovcraft.medsystem.common.blood_system.BloodSystemManager;
import tnt.tarkovcraft.medsystem.common.blood_system.UnconsciousOptions;
import tnt.tarkovcraft.medsystem.common.blood_system.UnconsciousState;
import tnt.tarkovcraft.medsystem.common.blood_system.assignment.EntityBloodSystem;
import tnt.tarkovcraft.medsystem.common.blood_system.assignment.EntityBloodSystemDefinition;
import tnt.tarkovcraft.medsystem.common.config.MedSystemConfig;
import tnt.tarkovcraft.medsystem.common.config.UnconsciousEntityTargeting;
import tnt.tarkovcraft.medsystem.common.effect.OverweightStatusEffect;
import tnt.tarkovcraft.medsystem.common.effect.StatusEffectContext;
import tnt.tarkovcraft.medsystem.common.effect.util.StatusEffectMap;
import tnt.tarkovcraft.medsystem.common.effect.util.StatusEffectSubmitter;
import tnt.tarkovcraft.medsystem.common.health.DamageContext;
import tnt.tarkovcraft.medsystem.common.health.HealthContainer;
import tnt.tarkovcraft.medsystem.common.health.HealthSystem;
import tnt.tarkovcraft.medsystem.common.health.Limb;
import tnt.tarkovcraft.medsystem.common.health.LimbContainer;
import tnt.tarkovcraft.medsystem.common.health.LimbType;
import tnt.tarkovcraft.medsystem.common.health_event.HealthEventContext;
import tnt.tarkovcraft.medsystem.common.health_event.HealthEventParams;
import tnt.tarkovcraft.medsystem.common.init.MedSystemDamageTypes;
import tnt.tarkovcraft.medsystem.common.init.MedSystemDataAttachments;
import tnt.tarkovcraft.medsystem.common.init.MedSystemHealthEventSources;
import tnt.tarkovcraft.medsystem.common.init.MedSystemItemComponents;
import tnt.tarkovcraft.medsystem.common.init.MedSystemStatusEffects;
import tnt.tarkovcraft.medsystem.common.init.MedSystemTags;
import tnt.tarkovcraft.medsystem.common.item.InteractionTarget;
import tnt.tarkovcraft.medsystem.util.HealthHelper;

public final class MedicalSystemEventHandler {
   @SubscribeEvent
   private void onEntitySpawn(EntityJoinLevelEvent event) {
      Entity entity = event.getEntity();
      if (!event.isCanceled()) {
         if (entity instanceof LivingEntity livingEntity) {
            HealthSystem.handleNewEntity(livingEntity);
            BloodSystemManager.handleNewEntity(livingEntity);
            livingEntity.setData(MedSystemDataAttachments.DAMAGE_CONTEXT, DamageContext.createEmptyInstance());
         }
      }
   }

   @SubscribeEvent(priority = EventPriority.LOW)
   private void onLivingHeal(LivingHealEvent event) {
      LivingEntity entity = event.getEntity();
      float amount = event.getAmount();
      if (!event.isCanceled()) {
         if (amount > 0.0F && HealthSystem.hasCustomHealth(entity)) {
            HealthContainer container = HealthContainer.getAttachedValid(entity);
            if (container == null) {
               return;
            }

            LimbContainer limbContainer = container.getLimbContainer();
            float leftover = limbContainer.heal(amount, null);
            if (leftover > 0.0F) {
               event.setAmount(amount - leftover);
            }

            HealthSystem.synchronizeEntity(entity);
         }
      }
   }

   @SubscribeEvent
   private void onWeightUpdate(EntityWeightUpdateEvent event) {
      LivingEntity entity = event.getEntity();
      float factor = event.getOverweightFactor();
      HealthContainer container = HealthContainer.getAttachedValid(entity);
      if (container != null) {
         StatusEffectMap effects = container.getGlobalStatusEffects();
         if (factor > 0.0F) {
            effects.replace(new OverweightStatusEffect(factor >= 1.0F));
         } else {
            StatusEffectContext context = StatusEffectContext.of(container, entity, StatusEffectSubmitter.NOOP, null);
            effects.remove(MedSystemStatusEffects.OVERWEIGHT, context);
         }

         HealthSystem.synchronizeEntity(entity);
      }
   }

   @SubscribeEvent
   private void canSprint(CanSprint event) {
      LivingEntity entity = event.getEntity();
      MedSystemConfig config = MedicalSystem.getConfig();
      if (config.statusEffects.enableStatusEffects && HealthSystem.isMovementRestricted(entity) && !HealthSystem.hasPainRelief(entity)) {
         event.setCanSprint(false);
      }
   }

   @SubscribeEvent
   private void onSprinted(AfterSprint event) {
      LivingEntity entity = event.getEntity();
      Level level = entity.level();
      MedSystemConfig config = MedicalSystem.getConfig();
      long gameTime = level.getGameTime();
      if (!level.isClientSide()) {
         if (config.statusEffects.enableStatusEffects && gameTime % 20L == 0L && HealthSystem.isMovementRestricted(entity)) {
            RegistryAccess access = entity.registryAccess();
            entity.hurtServer((ServerLevel)level, MedSystemDamageTypes.causeFractureDamage(access), 0.25F);
         }
      }
   }

   @SubscribeEvent
   private void afterJump(AfterJump event) {
      LivingEntity entity = event.getEntity();
      MedSystemConfig config = MedicalSystem.getConfig();
      Level level = entity.level();
      if (!level.isClientSide()) {
         if (config.statusEffects.enableStatusEffects && HealthSystem.isMovementRestricted(entity)) {
            RegistryAccess access = entity.registryAccess();
            entity.hurtServer((ServerLevel)level, MedSystemDamageTypes.causeFractureDamage(access), 0.5F);
         }
      }
   }

   @SubscribeEvent(priority = EventPriority.LOW)
   private void onLivingDeath(LivingDeathEvent event) {
      if (!event.isCanceled()) {
         LivingEntity entity = event.getEntity();
         MedSystemConfig config = MedicalSystem.getConfig();
         DamageSource source = event.getSource();
         int playerCount = entity.level().players().size();
         if ((playerCount > 1 || config.bloodSystem.allowDownedSingleplayer)
            && BloodSystemManager.isEnabled(entity)
            && !source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
            EntityBloodSystem bloodSystem = EntityBloodSystem.getAttached(entity);
            UnconsciousState unconsciousState = bloodSystem.getUnconsciousState();
            UnconsciousOptions options = unconsciousState.getUnconsciousOptions();
            if (!options.downedStateAllowed() || bloodSystem.hasBledOut()) {
               return;
            }

            RandomSource random = entity.getRandom();
            EntityBloodSystemDefinition definition = bloodSystem.getDefinition();
            if (definition.isDownedStateEnabled() && random.nextFloat() < config.bloodSystem.unconsciousOnDeathChance) {
               HealthContainer container = HealthContainer.getAttached(entity);
               if (container != null
                  && config.bloodSystem.unconsciousOnHeadDeathChance > 0.0F
                  && random.nextFloat() >= config.bloodSystem.unconsciousOnHeadDeathChance
                  && HealthHelper.allLimbsDead(container, LimbType.HEAD)) {
                  return;
               }

               event.setCanceled(true);
               if (container != null) {
                  HealthHelper.recoverVitalLimbs(container, 1.0F);
                  HealthHelper.synchronizeHealth(entity, container);
                  HealthSystem.synchronizeEntity(entity);
               } else {
                  entity.setHealth(1.0F);
               }

               bloodSystem.setUnconscious(entity, config.bloodSystem.rescueWaitDuration, UnconsciousOptions.DOWNED);
               bloodSystem.synchronizeImmediately(entity);
               entity.invulnerableTime = 30;
            }
         }

         if (!event.isCanceled() && HealthSystem.hasCustomHealth(entity)) {
            HealthContainer container = HealthContainer.getAttached(entity);
            container.invalidate();
         }
      }
   }

   @SubscribeEvent(priority = EventPriority.LOW)
   private void addItemStackTooltips(ItemTooltipEvent event) {
      ItemStack stack = event.getItemStack();
      TooltipContext context = event.getContext();
      List<Component> tooltip = event.getToolTip();
      TooltipFlag flag = event.getFlags();
      Consumer<Component> adder = tooltip::add;
      stack.addToTooltip(MedSystemItemComponents.HEAL_ATTRIBUTES, context, TooltipDisplay.DEFAULT, adder, flag);
      stack.addToTooltip(MedSystemItemComponents.SIDE_EFFECTS, context, TooltipDisplay.DEFAULT, adder, flag);
   }

   @SubscribeEvent
   private void onItemUseFinished(Finish event) {
      ItemStack stack = event.getItem();
      LivingEntity entity = event.getEntity();
      if (stack.has(MedSystemItemComponents.SIDE_EFFECTS)) {
         SideEffectHolder holder = (SideEffectHolder)stack.get(MedSystemItemComponents.SIDE_EFFECTS);
         InteractionTarget target = (InteractionTarget)stack.get(MedSystemItemComponents.INTERACTION_TARGET);
         String targetLimb = target != null ? target.limbCode() : null;
         LivingEntity targetEntity = entity;
         if (target != null) {
            targetEntity = target.getTargetLivingEntity(entity);
         }

         if (!HealthSystem.hasCustomHealth(targetEntity)) {
            return;
         }

         HealthContainer container = HealthContainer.getAttached(targetEntity);
         Limb part = container.getLimbByCode(targetLimb);
         holder.onConsume(stack, targetEntity, container, part);
      }

      if (HealthSystem.hasCustomHealth(entity)) {
         HealthContainer container = HealthContainer.getAttached(entity);
         Limb limb = container.getRootLimb();
         HealthEventContext context = HealthEventContext.withParams(entity, container, limb, builder -> builder.add(HealthEventParams.ITEM, stack));
         MedicalSystem.HEALTH_EVENT.triggerEvent(MedSystemHealthEventSources.CONSUME, context);
      }
   }

   @SubscribeEvent
   private void canMountEntity(EntityMountEvent event) {
      Entity entity = event.getEntity();
      if (entity instanceof LivingEntity livingEntity && BloodSystemManager.isUnconscious(livingEntity)) {
         TagKey<EntityType<?>> allowedEntities = event.isMounting()
            ? MedSystemTags.Entities.UNCONSCIOUS_MOUNTABLE
            : MedSystemTags.Entities.UNCONSCIOUS_DISMOUNTABLE;
         if (livingEntity.isDeadOrDying()) {
            return;
         }

         Entity entityToMount = event.getEntityBeingMounted();
         boolean externallyControlled = entity.getExistingData(MedSystemDataAttachments.EXTERNALLY_CONTROLLED).orElse(false);
         if (entityToMount != null && (externallyControlled || entityToMount.is(allowedEntities) || !entityToMount.isAlive())) {
            return;
         }

         event.setCanceled(true);
      }
   }

   @SubscribeEvent
   private void adjustHitboxSize(Size event) {
      if (event.getEntity() instanceof LivingEntity livingEntity) {
         if (BloodSystemManager.isUnconscious(livingEntity) && !livingEntity.isPassenger()) {
            EntityBloodSystem bloodSystem = EntityBloodSystem.getAttached(livingEntity);
            EntityDimensions scalableDim = bloodSystem.getDefinition().getDimensionsForUnconsciousMode();
            event.setNewSize(scalableDim);
         }
      }
   }

   @SubscribeEvent
   private void onSetAttackTarget(LivingChangeTargetEvent event) {
      LivingEntity newTarget = event.getNewAboutToBeSetTarget();
      if (!event.isCanceled() && newTarget != null && BloodSystemManager.isEnabled(newTarget)) {
         EntityBloodSystem bloodSystem = EntityBloodSystem.getAttached(newTarget);
         UnconsciousEntityTargeting entityTargeting = MedicalSystem.getConfig().bloodSystem.unconsciousEntityTargeting;
         if (bloodSystem.isUnconscious() && !entityTargeting.canTargetEntity(newTarget, bloodSystem)) {
            event.setNewAboutToBeSetTarget(null);
         }
      }
   }

   @SubscribeEvent
   private void onItemEntityPickUp(Pre event) {
      if (!event.canPickup().isFalse()) {
         Player player = event.getPlayer();
         if (BloodSystemManager.isUnconscious(player)) {
            event.setCanPickup(TriState.FALSE);
         }
      }
   }
}
