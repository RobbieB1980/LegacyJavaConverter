package tnt.tarkovcraft.medsystem.common.health_event;

import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.Multimap;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.function.Supplier;
import net.minecraft.core.Holder;
import net.minecraft.resources.FileToIdConverter;
import net.minecraft.resources.Identifier;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.server.packs.resources.SimpleJsonResourceReloadListener;
import net.minecraft.util.profiling.ProfilerFiller;
import org.apache.logging.log4j.Marker;
import org.apache.logging.log4j.MarkerManager;
import tnt.tarkovcraft.medsystem.MedicalSystem;

public final class HealthEventManager extends SimpleJsonResourceReloadListener<HealthEvent> {
   public static final Marker MARKER = MarkerManager.getMarker("StatusEffectEventManager");
   public static final Identifier IDENTIFIER = MedicalSystem.createIdentifier("health_event");
   private final Multimap<HealthEventTriggerSource, HealthEventManager.NamedStatusEffectEvent> eventMappings = ArrayListMultimap.create();

   public HealthEventManager() {
      super(HealthEvent.CODEC, FileToIdConverter.json("tarkovcraft/health_event"));
   }

   protected void apply(Map<Identifier, HealthEvent> object, ResourceManager resourceManager, ProfilerFiller profiler) {
      MedicalSystem.LOGGER.debug(MARKER, "Registering status effect events");
      this.eventMappings.clear();

      for (Entry<Identifier, HealthEvent> entry : object.entrySet()) {
         Identifier identifier = entry.getKey();
         HealthEvent event = entry.getValue();
         MedicalSystem.LOGGER.debug(MARKER, "Registering '{}' status effect event for event source '{}'", identifier, event.eventSource().identifier());
         this.eventMappings.put(event.eventSource(), new HealthEventManager.NamedStatusEffectEvent(identifier, event));
      }

      MedicalSystem.LOGGER.info(MARKER, "Registered {} status effect events", this.eventMappings.size());
   }

   public void triggerEvent(Supplier<HealthEventTriggerSource> sourceSupplier, HealthEventContext context) {
      this.triggerEvent(sourceSupplier.get(), context);
   }

   public void triggerEvent(Holder<HealthEventTriggerSource> sourceHolder, HealthEventContext context) {
      this.triggerEvent((HealthEventTriggerSource)sourceHolder.value(), context);
   }

   public void triggerEvent(HealthEventTriggerSource source, HealthEventContext context) {
      Collection<HealthEventManager.NamedStatusEffectEvent> events = this.eventMappings.get(source);
      Iterator<HealthEventManager.NamedStatusEffectEvent> iterator = events.iterator();

      while (iterator.hasNext()) {
         HealthEventManager.NamedStatusEffectEvent event = iterator.next();
         HealthEventResult result = event.trigger(context);
         if (result == HealthEventResult.INVALID) {
            MedicalSystem.LOGGER
               .error(MARKER, "Removing invalid status effect event '{}' as it is not triggerable for event source {}", event.id, source.identifier());
            iterator.remove();
         }
      }
   }

   private record NamedStatusEffectEvent(Identifier id, HealthEvent event) {
      HealthEventResult trigger(HealthEventContext context) {
         return this.event.trigger(context);
      }
   }
}
