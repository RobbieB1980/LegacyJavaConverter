package tnt.tarkovcraft.medsystem.network.config;

import java.util.function.Consumer;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.network.protocol.configuration.ServerConfigurationPacketListener;
import net.minecraft.server.network.ConfigurationTask.Type;
import net.neoforged.neoforge.network.configuration.ICustomConfigurationTask;
import tnt.tarkovcraft.medsystem.MedicalSystem;
import tnt.tarkovcraft.medsystem.network.message.S2C_SendBloodSystemData;

public record BloodSystemSynchronizationTask(ServerConfigurationPacketListener listener) implements ICustomConfigurationTask {
   public static final Type TYPE = new Type(MedicalSystem.createIdentifier("blood_system_sync"));

   public void run(Consumer<CustomPacketPayload> sender) {
      sender.accept(new S2C_SendBloodSystemData(MedicalSystem.BLOOD_SYSTEM.prepareSynchronizationData()));
      this.listener.finishCurrentTask(TYPE);
   }

   public Type type() {
      return TYPE;
   }
}
