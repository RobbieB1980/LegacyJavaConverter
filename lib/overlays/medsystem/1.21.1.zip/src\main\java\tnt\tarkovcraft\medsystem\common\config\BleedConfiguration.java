package tnt.tarkovcraft.medsystem.common.config;

import dev.toma.configuration.config.Configurable;
import dev.toma.configuration.config.Configurable.Comment;
import dev.toma.configuration.config.Configurable.DecimalRange;
import dev.toma.configuration.config.Configurable.Range;
import dev.toma.configuration.config.Configurable.Gui.NumberFormat;
import dev.toma.configuration.config.Configurable.Gui.Slider;

public final class BleedConfiguration {
   @Configurable
   public BleedConfiguration.BleedStageConfig lightBleed = new BleedConfiguration.BleedStageConfig(50, 1.5F, -1, 60, 0.005F, 0, 1);
   @Configurable
   public BleedConfiguration.BleedStageConfig moderateBleed = new BleedConfiguration.BleedStageConfig(30, 2.5F, -1, 45, 0.01F, 0, 2);
   @Configurable
   public BleedConfiguration.BleedStageConfig heavyBleed = new BleedConfiguration.BleedStageConfig(15, 3.0F, -1, 30, 0.025F, 6000, 5);
   @Configurable
   public BleedConfiguration.BleedStageConfig criticalBleed = new BleedConfiguration.BleedStageConfig(5, 5.0F, -1, 10, 0.06F, 12000, 8);

   public BleedConfiguration.BleedStageConfig getLightBleed() {
      return this.lightBleed;
   }

   public BleedConfiguration.BleedStageConfig getModerateBleed() {
      return this.moderateBleed;
   }

   public BleedConfiguration.BleedStageConfig getHeavyBleed() {
      return this.heavyBleed;
   }

   public BleedConfiguration.BleedStageConfig getCriticalBleed() {
      return this.criticalBleed;
   }

   public static final class BleedStageConfig {
      @Configurable
      @Range(min = 0L)
      public int weight;
      @Configurable
      @DecimalRange(min = 0.0)
      public float minDamageThreshold;
      @Configurable
      @Range(min = -1L)
      @Comment({"Default duration of bleeding status effect", "-1 means infinite duration"})
      public int bleedDuration;
      @Configurable
      @Range(min = 5L)
      public int bleedInterval;
      @Configurable
      @DecimalRange(min = 1.0E-4F)
      @NumberFormat("0.000#")
      public float bleedAmount;
      @Configurable
      @Range(min = 0L)
      public int woundDuration;
      @Configurable
      @Range(min = 0L, max = 16L)
      @Slider
      public int decalCount;

      public BleedStageConfig(int weight, float minDamageThreshold, int bleedDuration, int bleedInterval, float bleedAmount, int woundDuration, int decalCount) {
         this.weight = weight;
         this.minDamageThreshold = minDamageThreshold;
         this.bleedDuration = bleedDuration;
         this.bleedInterval = bleedInterval;
         this.bleedAmount = bleedAmount;
         this.woundDuration = woundDuration;
         this.decalCount = decalCount;
      }
   }
}
