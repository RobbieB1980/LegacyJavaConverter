package tnt.tarkovcraft.medsystem.common.interaction;

import com.mojang.serialization.MapCodec;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.LivingEntity;
import tnt.tarkovcraft.core.api.EntityInteraction;
import tnt.tarkovcraft.core.api.EntityInteraction.Context;
import tnt.tarkovcraft.core.api.EntityInteraction.InteractionResult;
import tnt.tarkovcraft.core.api.EntityInteraction.Type;
import tnt.tarkovcraft.core.util.UserActionResult;
import tnt.tarkovcraft.medsystem.MedicalSystem;
import tnt.tarkovcraft.medsystem.common.blood_system.BloodSystemManager;
import tnt.tarkovcraft.medsystem.common.blood_system.UnconsciousOptions;
import tnt.tarkovcraft.medsystem.common.blood_system.assignment.EntityBloodSystem;
import tnt.tarkovcraft.medsystem.common.init.MedSystemEntityInteractions;

public final class RescueDownedEntityInteraction implements EntityInteraction {
   public static final RescueDownedEntityInteraction INSTANCE = new RescueDownedEntityInteraction();
   public static final MapCodec<RescueDownedEntityInteraction> CODEC = MapCodec.unit(INSTANCE);
   public static final StreamCodec<RegistryFriendlyByteBuf, RescueDownedEntityInteraction> STREAM_CODEC = StreamCodec.unit(INSTANCE);
   private static final Identifier IDENTIFIER = MedicalSystem.createIdentifier("rescue_downed_entity");
   private static final String ERR_UNABLE_TO_RESCUE = "unable_to_rescue";

   private RescueDownedEntityInteraction() {
   }

   public static UserActionResult<Void> test(Context context) {
      LivingEntity target = context.target();
      EntityBloodSystem bloodSystem = EntityBloodSystem.getAttached(target);
      if (bloodSystem == null) {
         return UserActionResult.failure(Type.getErrorMessage(IDENTIFIER, "unable_to_rescue", new Object[0]));
      }

      UnconsciousOptions options = bloodSystem.getUnconsciousState().getUnconsciousOptions();
      return bloodSystem.isUnconscious() && options.allowRescue()
         ? UserActionResult.successEmpty()
         : UserActionResult.failure(Type.getErrorMessage(IDENTIFIER, "unable_to_rescue", new Object[0]));
   }

   public void onCompleted(Context context) {
      LivingEntity target = context.target();
      if (BloodSystemManager.isUnconscious(target)) {
         EntityBloodSystem bloodSystem = EntityBloodSystem.getAttached(target);
         bloodSystem.rescueDownedEntity(target);
         bloodSystem.synchronizeImmediately(target);
      }
   }

   public void onFailed(Context context, InteractionResult reason) {
   }

   public Type<?> type() {
      return (Type<?>)MedSystemEntityInteractions.RESCUE_DOWNED_ENTITY.value();
   }
}
