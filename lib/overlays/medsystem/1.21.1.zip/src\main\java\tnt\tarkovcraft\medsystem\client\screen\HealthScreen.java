package tnt.tarkovcraft.medsystem.client.screen;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.UUID;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.util.ARGB;
import net.minecraft.util.Mth;
import net.neoforged.neoforge.common.NeoForge;
import org.joml.Vector2f;
import org.joml.Vector4i;
import tnt.tarkovcraft.core.api.client.SynchronizableScreen.DataSource;
import tnt.tarkovcraft.core.client.screen.CharacterSubScreen;
import tnt.tarkovcraft.core.client.screen.renderable.IconWithLabelRenderable;
import tnt.tarkovcraft.core.client.screen.renderable.ShapeRenderable;
import tnt.tarkovcraft.core.client.util.IconWithLabel;
import tnt.tarkovcraft.core.util.HorizontalAlignment;
import tnt.tarkovcraft.medsystem.MedicalSystem;
import tnt.tarkovcraft.medsystem.api.event.client.RegisterHealthScreenLabelsEvent;
import tnt.tarkovcraft.medsystem.client.MedicalSystemClient;
import tnt.tarkovcraft.medsystem.client.config.HealthDisplayType;
import tnt.tarkovcraft.medsystem.client.config.MedSystemClientConfig;
import tnt.tarkovcraft.medsystem.client.screen.widget.LimbHealthWidget;
import tnt.tarkovcraft.medsystem.client.screen.widget.LimbWidget;
import tnt.tarkovcraft.medsystem.common.blood_system.BloodConfiguration;
import tnt.tarkovcraft.medsystem.common.blood_system.assignment.EntityBloodSystem;
import tnt.tarkovcraft.medsystem.common.config.BloodSystemConfig;
import tnt.tarkovcraft.medsystem.common.effect.StatusEffect;
import tnt.tarkovcraft.medsystem.common.effect.StatusEffectType;
import tnt.tarkovcraft.medsystem.common.effect.util.EffectVisibility;
import tnt.tarkovcraft.medsystem.common.health.HealthContainer;
import tnt.tarkovcraft.medsystem.common.health.HealthContainerDefinition;
import tnt.tarkovcraft.medsystem.common.health.HealthContainerDisplay;
import tnt.tarkovcraft.medsystem.common.health.Limb;
import tnt.tarkovcraft.medsystem.common.health.LimbContainer;
import tnt.tarkovcraft.medsystem.common.init.MedSystemDataAttachments;

public class HealthScreen extends CharacterSubScreen {
   public static final Identifier HEALTH_ICON = MedicalSystem.createIdentifier("textures/icons/health.png");
   public static final Identifier DROPLET_ICON = MedicalSystem.createIdentifier("textures/icons/droplet.png");
   private HealthContainer healthContainer;

   public HealthScreen(Screen parent, UUID userId) {
      super(userId, MedicalSystemClient.HEALTH);
   }

   public void sync(DataSource source) {
      if (source.equals(HealthContainer.HEALTH) || source.equals(EntityBloodSystem.BLOOD_SYSTEM)) {
         this.init(this.width, this.height);
      }
   }

   protected void init() {
      super.init();
      this.addRenderableOnly(new ShapeRenderable(0, 25, this.width, this.height - 25, 1140850688));
      this.healthContainer = (HealthContainer)this.minecraft.player.getData(MedSystemDataAttachments.HEALTH_CONTAINER);
      LimbContainer limbContainer = this.healthContainer.getLimbContainer();
      HealthContainerDefinition definition = this.healthContainer.getDefinition();
      List<IconWithLabel> list = new ArrayList<>();
      MedSystemClientConfig config = MedicalSystemClient.getConfig();
      float healthScale = config.healthDisplayType == HealthDisplayType.HEARTS ? 0.5F : (float)Math.pow(10.0, config.numericHealthScale);
      list.add(
         new IconWithLabel(
            HEALTH_ICON,
            () -> Component.literal(Mth.floor(limbContainer.getHealth() * healthScale) + "/" + Mth.floor(limbContainer.getMaxHealth() * healthScale)),
            -11141291,
            -11141291
         )
      );
      EntityBloodSystem bloodSystem = EntityBloodSystem.getAttached(this.minecraft.player);
      if (bloodSystem != null) {
         Identifier bloodTypeId = bloodSystem.getBloodType();
         BloodConfiguration configuration = MedicalSystem.BLOOD_SYSTEM.getConfig();
         configuration.getOptions(bloodTypeId).ifPresent(options -> {
            BloodSystemConfig bloodConfig = MedicalSystem.getConfig().bloodSystem;
            if (bloodConfig.showBloodType) {
               Component styledLabel = options.getStylizedLabel();
               list.add(new IconWithLabel(DROPLET_ICON, () -> styledLabel, ARGB.opaque(options.color()), -1));
            }

            if (bloodConfig.showBloodLevel) {
               float volume = bloodSystem.getBloodVolume();
               float max = bloodSystem.getDefinition().getMaxBloodVolume();
               Component valueLabel = Component.literal(String.format(Locale.ROOT, "%.2f/%.2f", volume, max)).withColor(options.color());
               Component label = Component.translatable("label.medsystem.unit.liter", new Object[]{valueLabel}).withColor(options.color());
               list.add(new IconWithLabel(DROPLET_ICON, () -> label, ARGB.opaque(options.color()), -1));
            }
         });
      }

      NeoForge.EVENT_BUS.post(new RegisterHealthScreenLabelsEvent(list));

      for (int i = 0; i < list.size(); i++) {
         IconWithLabel icon = list.get(i);
         IconWithLabelRenderable renderable = (IconWithLabelRenderable)this.addRenderableOnly(
            new IconWithLabelRenderable(this.font, 5, this.height - 5 - 9 - i * 12, this.width / 3, 10, HorizontalAlignment.LEFT, icon)
         );
         renderable.setIconSize(10);
         renderable.setHorizontalTextOffset(3);
      }

      Vector2f center = new Vector2f(this.width / 2.0F, this.height / 2.0F);
      List<LimbHealthWidget> healthWidgets = new ArrayList<>();
      float scale = this.height / 256.0F * 2.0F;
      HealthContainerDisplay display = definition.display();
      display.accept((limbCode, data) -> {
         Limb limb = this.healthContainer.getLimbByCode(limbCode);
         Vector4i pos = data.getGuiPos(scale, center);
         int x = pos.x;
         int y = pos.y;
         int width = pos.z;
         int height = pos.w;
         int xOffset = (int)(pos.x + width / 2.0F - center.x);
         LimbWidget limbWidget = (LimbWidget)this.addRenderableOnly(new LimbWidget(x, y, width, height, limb, this.font));
         limbWidget.setScale(3);
         List<StatusEffect> effects = limb.getStatusEffects().getEffectsStream().filter(ef -> StatusEffectType.isVisible(ef, EffectVisibility.UI)).toList();
         int healthWidth = 80;
         int healthHeight = effects.isEmpty() ? 20 : 33;
         int healthX = getHealthLabelWidgetX(xOffset, x, healthWidth, width);
         int healthY = y + (height - healthHeight) / 2;
         LimbHealthWidget healthWidget = new LimbHealthWidget(healthX, healthY, healthWidth, healthHeight, this.font, limb);
         healthWidget.setEffects(effects);
         healthWidget.setTextHoverColor(-1);
         healthWidgets.add(healthWidget);
      });
      HealthScreen var11 = this;
      healthWidgets.forEach(x$0 -> var11.addRenderableOnly(x$0));
   }

   static int getHealthLabelWidgetX(int xOffset, int posX, int labelWidth, int limbWidth) {
      if (xOffset == 0) {
         return posX + (limbWidth - labelWidth) / 2;
      } else {
         return xOffset > 0 ? posX + limbWidth + 2 : posX - labelWidth - 2;
      }
   }
}
