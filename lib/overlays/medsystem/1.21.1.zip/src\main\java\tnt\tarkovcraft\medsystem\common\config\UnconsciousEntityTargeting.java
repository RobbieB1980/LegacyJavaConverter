package tnt.tarkovcraft.medsystem.common.config;

import net.minecraft.world.entity.LivingEntity;
import tnt.tarkovcraft.medsystem.common.blood_system.UnconsciousOptions;
import tnt.tarkovcraft.medsystem.common.blood_system.assignment.EntityBloodSystem;

public enum UnconsciousEntityTargeting {
   ALWAYS(UnconsciousEntityTargeting.TargetingPredicate.ALWAYS),
   IGNORE_RESCUE(UnconsciousEntityTargeting.TargetingPredicate.IGNORE_RESCUE),
   NEVER(UnconsciousEntityTargeting.TargetingPredicate.NEVER);

   private final UnconsciousEntityTargeting.TargetingPredicate predicate;

   UnconsciousEntityTargeting(UnconsciousEntityTargeting.TargetingPredicate predicate) {
      this.predicate = predicate;
   }

   public boolean canTargetEntity(LivingEntity target, EntityBloodSystem bloodSystem) {
      return this.predicate.canAttack(target, bloodSystem);
   }

   private static boolean skipRescueModeTargeting(LivingEntity entity, EntityBloodSystem bloodSystem) {
      UnconsciousOptions options = bloodSystem.getUnconsciousState().getUnconsciousOptions();
      return !options.allowRescue();
   }

   @FunctionalInterface
   public interface TargetingPredicate {
      UnconsciousEntityTargeting.TargetingPredicate ALWAYS = (entity, bloodSystem) -> true;
      UnconsciousEntityTargeting.TargetingPredicate IGNORE_RESCUE = UnconsciousEntityTargeting::skipRescueModeTargeting;
      UnconsciousEntityTargeting.TargetingPredicate NEVER = (entity, bloodSystem) -> false;

      boolean canAttack(LivingEntity var1, EntityBloodSystem var2);
   }
}
