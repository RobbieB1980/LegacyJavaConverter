package tnt.tarkovcraft.medsystem.common.armor;

public class SimulatedArmorComponent extends ModularArmorComponent {
   public static final SimulatedArmorComponent INSTANCE = new SimulatedArmorComponent();
   public static final float DEFLECT_SCALE = 50.0F;
   public static final float MAX_DEFLECT_CHANCE = 0.75F;
   public static final float UNCONSCIOUS_ENERGY_THRESHOLD = 40.0F;
   public static final float CONCUSSION_ENERGY_THRESHOLD = 10.0F;
}
