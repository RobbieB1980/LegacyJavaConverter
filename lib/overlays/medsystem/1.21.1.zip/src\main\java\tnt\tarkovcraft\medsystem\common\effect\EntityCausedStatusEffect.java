package tnt.tarkovcraft.medsystem.common.effect;

import com.mojang.datafixers.Products.P2;
import com.mojang.serialization.codecs.RecordCodecBuilder.Instance;
import com.mojang.serialization.codecs.RecordCodecBuilder.Mu;
import java.util.Optional;
import java.util.UUID;
import net.minecraft.core.UUIDUtil;
import org.jspecify.annotations.Nullable;

public abstract class EntityCausedStatusEffect extends StatusEffect {
   private UUID owner;

   public EntityCausedStatusEffect(int duration, Optional<UUID> owner) {
      super(duration);
      this.owner = owner.orElse(null);
   }

   public EntityCausedStatusEffect(int duration) {
      super(duration);
   }

   @Override
   public void setCausingEntity(@Nullable UUID owner) {
      this.owner = owner;
   }

   @Override
   public @Nullable UUID getCausingEntity() {
      return this.owner;
   }

   public static <T extends StatusEffect> P2<Mu<T>, Integer, Optional<UUID>> commonEntity(Instance<T> instance) {
      return common(instance).and(UUIDUtil.CODEC.optionalFieldOf("cause").forGetter(t -> Optional.ofNullable(t.getCausingEntity())));
   }
}
