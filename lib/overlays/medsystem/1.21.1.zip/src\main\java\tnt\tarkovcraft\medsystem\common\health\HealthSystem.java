package tnt.tarkovcraft.medsystem.common.health;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.FileToIdConverter;
import net.minecraft.resources.Identifier;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.server.packs.resources.SimpleJsonResourceReloadListener;
import net.minecraft.util.profiling.ProfilerFiller;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.arrow.AbstractArrow;
import net.neoforged.neoforge.common.NeoForge;
import org.apache.logging.log4j.Marker;
import org.apache.logging.log4j.MarkerManager;
import org.jspecify.annotations.Nullable;
import tnt.tarkovcraft.medsystem.MedicalSystem;
import tnt.tarkovcraft.medsystem.api.event.HitboxPiercingEvent;
import tnt.tarkovcraft.medsystem.api.event.PainCheckEvent;
import tnt.tarkovcraft.medsystem.common.blood_system.assignment.EntityBloodSystem;
import tnt.tarkovcraft.medsystem.common.effect.util.StatusEffectHelper;
import tnt.tarkovcraft.medsystem.common.effect.util.StatusEffectMap;
import tnt.tarkovcraft.medsystem.common.health.calc.HitCalculationContext;
import tnt.tarkovcraft.medsystem.common.init.MedSystemDataAttachments;
import tnt.tarkovcraft.medsystem.common.init.MedSystemTags;
import tnt.tarkovcraft.medsystem.network.message.S2C_SendHealthDefinitions;
import tnt.tarkovcraft.medsystem.util.HealthHelper;

public final class HealthSystem extends SimpleJsonResourceReloadListener<HealthContainerDefinition> {
   public static final Marker MARKER = MarkerManager.getMarker("HealthSystemManager");
   public static final Identifier IDENTIFIER = MedicalSystem.createIdentifier("health_system");
   private final Map<EntityType<?>, HealthContainerDefinition> healthContainers = new HashMap<>();

   public HealthSystem() {
      super(HealthContainerDefinition.CODEC, FileToIdConverter.json("tarkovcraft/health"));
   }

   public static boolean hasCustomHealth(Entity entity) {
      return entity.hasData(MedSystemDataAttachments.HEALTH_CONTAINER);
   }

   public static boolean hasPainRelief(LivingEntity entity) {
      if (!hasCustomHealth(entity)) {
         return false;
      }

      HealthContainer container = HealthContainer.getAttached(entity);
      return container.getGlobalStatusEffects().hasEffect(MedSystemTags.StatusEffects.IS_PAIN_RELIEF);
   }

   public static boolean isInPain(LivingEntity entity) {
      if (hasCustomHealth(entity) && !hasPainRelief(entity)) {
         HealthContainer container = HealthContainer.getAttached(entity);
         boolean inPain = HealthHelper.anyLimbDead(container) || StatusEffectHelper.hasTaggedEffect(container, MedSystemTags.StatusEffects.IS_PAIN_CAUSING);
         EntityBloodSystem bloodSystem = EntityBloodSystem.getAttached(entity);
         if (!inPain && bloodSystem != null && bloodSystem.isInPain()) {
            inPain = true;
         }

         PainCheckEvent event = (PainCheckEvent)NeoForge.EVENT_BUS.post(new PainCheckEvent(entity, container, inPain));
         return event.isInPain();
      } else {
         return false;
      }
   }

   public static boolean isBleeding(LivingEntity entity) {
      if (!hasCustomHealth(entity)) {
         return false;
      }

      HealthContainer container = HealthContainer.getAttached(entity);
      return StatusEffectHelper.hasTaggedEffect(container, MedSystemTags.StatusEffects.IS_BLEED);
   }

   public static boolean isMovementRestricted(LivingEntity entity) {
      if (!hasCustomHealth(entity)) {
         return false;
      }

      if (!(entity instanceof Player player && (player.isCreative() || player.isSpectator()))) {
         HealthContainer healthContainer = HealthContainer.getAttached(entity);
         StatusEffectMap map = healthContainer.getGlobalStatusEffects();
         if (map.hasEffect(MedSystemTags.StatusEffects.MOVEMENT_RESTRICTING)) {
            return true;
         }

         EntityBloodSystem bloodSystem = EntityBloodSystem.getAttached(entity);
         if (bloodSystem != null && bloodSystem.isInPain()) {
            return true;
         }

         LimbContainer limbContainer = healthContainer.getLimbContainer();
         return limbContainer.hasLimb(HealthSystem::isMovementRestrictedOnLimb);
      } else {
         return false;
      }
   }

   public static boolean isMovementRestrictedOnLimb(Limb limb) {
      return limb.getType() == LimbType.LEG && (limb.isDead() || limb.getStatusEffects().hasEffect(MedSystemTags.StatusEffects.MOVEMENT_RESTRICTING));
   }

   public static void synchronizeEntity(LivingEntity entity) {
      if (!entity.level().isClientSide() && hasCustomHealth(entity)) {
         entity.syncData(MedSystemDataAttachments.HEALTH_CONTAINER);
      }
   }

   @Deprecated
   public static int getProjectilePiercing(HitCalculationContext context) {
      int pierceLevel = 1;
      if (context.getProjectile() instanceof AbstractArrow arrow) {
         pierceLevel += arrow.getPierceLevel();
      }

      return ((HitboxPiercingEvent)NeoForge.EVENT_BUS.post(new HitboxPiercingEvent(context, pierceLevel))).getPiercing();
   }

   public static @Nullable HealthContainerDefinition getHealthContainerDefinition(EntityType<?> type) {
      return MedicalSystem.HEALTH_SYSTEM.healthContainers.get(type);
   }

   public void importServerData(Map<EntityType<?>, HealthContainerDefinition> data) {
      MedicalSystem.LOGGER.debug(MARKER, "Importing server data, total of {} entries", data.size());
      this.healthContainers.clear();
      this.healthContainers.putAll(data);
   }

   public CustomPacketPayload getConfigurationPayload() {
      return new S2C_SendHealthDefinitions(this.healthContainers);
   }

   public static void handleNewEntity(LivingEntity entity) {
      HealthContainer container = HealthContainer.getAttached(entity);
      if (container == null || container.isInvalid()) {
         HealthContainer.detach(entity);
         HealthContainerDefinition definition = getHealthContainerDefinition(entity.getType());
         if (definition != null) {
            definition.bind(entity);
         }
      }
   }

   protected void apply(Map<Identifier, HealthContainerDefinition> map, ResourceManager resourceManager, ProfilerFiller profiler) {
      MedicalSystem.LOGGER.debug(MARKER, "Loading custom entity health containers");
      this.healthContainers.clear();

      for (HealthContainerDefinition definition : map.values()) {
         List<EntityType<?>> targets = definition.targets();
         targets.forEach(type -> {
            if (this.healthContainers.put((EntityType<?>)type, definition) != null) {
               MedicalSystem.LOGGER.warn(MARKER, "Detected health container override for entity {}", EntityType.getKey(type));
            }
         });
      }

      MedicalSystem.LOGGER.debug(MARKER, "Loaded {} custom entity health containers", this.healthContainers.size());
   }
}
