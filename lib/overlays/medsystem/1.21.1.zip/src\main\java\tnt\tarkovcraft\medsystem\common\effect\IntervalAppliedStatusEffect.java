package tnt.tarkovcraft.medsystem.common.effect;

import net.minecraft.world.level.Level;

public abstract class IntervalAppliedStatusEffect extends StatusEffect {
   private final int updateInterval = this.getUpdateInterval();

   public IntervalAppliedStatusEffect(int duration) {
      super(duration);
   }

   public abstract int getUpdateInterval();

   public abstract void applyEffect(StatusEffectContext var1);

   @Override
   public final void apply(StatusEffectContext context) {
      Level level = context.level();
      long gameTime = level.getGameTime();
      if (this.updateInterval <= 0 || gameTime % this.updateInterval == 0L) {
         this.applyEffect(context);
      }
   }
}
