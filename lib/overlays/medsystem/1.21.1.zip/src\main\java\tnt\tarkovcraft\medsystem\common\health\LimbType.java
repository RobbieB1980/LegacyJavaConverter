package tnt.tarkovcraft.medsystem.common.health;

import io.netty.buffer.ByteBuf;
import java.util.Set;
import java.util.function.IntFunction;
import net.minecraft.network.chat.Component;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.util.ByIdMap;
import net.minecraft.util.StringRepresentable;
import net.minecraft.util.ByIdMap.OutOfBoundsStrategy;
import net.minecraft.util.StringRepresentable.EnumCodec;
import net.minecraft.world.entity.EquipmentSlot;
import tnt.tarkovcraft.medsystem.MedicalSystem;
import tnt.tarkovcraft.medsystem.common.config.MedSystemConfig;

public enum LimbType implements StringRepresentable {
   HEAD("head", 0, 16711680),
   TORSO("torso", 0, 16776960),
   STOMACH("stomach", 20, 65280),
   ARM("arm", 10, 65535),
   LEG("leg", 30, 255),
   ANIMAL("animal", 0, 65280),
   OTHER("other", 0, 4473924);

   public static final EnumCodec<LimbType> CODEC = StringRepresentable.fromEnum(LimbType::values);
   public static final IntFunction<LimbType> BY_ID = ByIdMap.continuous(Enum::ordinal, values(), OutOfBoundsStrategy.WRAP);
   public static final StreamCodec<ByteBuf, LimbType> STREAM_CODEC = ByteBufCodecs.idMapper(BY_ID, Enum::ordinal);
   private final String serializedName;
   private final int surgeryPriority;
   private final int hitboxColor;
   private final Component label;

   LimbType(String serializedName, int surgeryPriority, int hitboxColor) {
      this.serializedName = serializedName;
      this.surgeryPriority = surgeryPriority;
      this.hitboxColor = hitboxColor;
      this.label = Component.translatable("medsystem.limb_type." + serializedName);
   }

   public String getSerializedName() {
      return this.serializedName;
   }

   public Set<EquipmentSlot> getArmorSlots() {
      MedSystemConfig config = MedicalSystem.getConfig();
      return config.armor.getProtectedAreasForLimb(this);
   }

   public int getHitboxColor() {
      return this.hitboxColor;
   }

   public int getSurgeryHealingPriority() {
      return this.surgeryPriority;
   }

   public Component getLabel() {
      return this.label;
   }
}
