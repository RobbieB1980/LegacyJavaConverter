package tnt.tarkovcraft.medsystem.client.overlay;

import com.mojang.blaze3d.platform.Window;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.resources.Identifier;
import net.minecraft.util.ARGB;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.neoforged.neoforge.client.gui.GuiLayer;
import org.joml.Vector2f;
import org.joml.Vector4f;
import tnt.tarkovcraft.core.util.HorizontalAlignment;
import tnt.tarkovcraft.core.util.helper.RenderUtils;
import tnt.tarkovcraft.medsystem.MedicalSystem;
import tnt.tarkovcraft.medsystem.client.MedicalSystemClient;
import tnt.tarkovcraft.medsystem.client.config.HealthOverlayConfiguration;
import tnt.tarkovcraft.medsystem.common.effect.StatusEffect;
import tnt.tarkovcraft.medsystem.common.effect.StatusEffectType;
import tnt.tarkovcraft.medsystem.common.effect.util.EffectVisibility;
import tnt.tarkovcraft.medsystem.common.health.HealthContainer;
import tnt.tarkovcraft.medsystem.common.health.HealthContainerDefinition;
import tnt.tarkovcraft.medsystem.common.health.HealthContainerDisplay;
import tnt.tarkovcraft.medsystem.common.health.HealthSystem;
import tnt.tarkovcraft.medsystem.common.health.Limb;
import tnt.tarkovcraft.medsystem.common.init.MedSystemDataAttachments;

public class HealthLayer implements GuiLayer {
   public static final Identifier LAYER_ID = MedicalSystem.createIdentifier("layer/health");

   public void render(GuiGraphicsExtractor graphics, DeltaTracker deltaTracker) {
      HealthOverlayConfiguration overlay = MedicalSystemClient.getConfig().healthOverlay;
      if (overlay.enabled) {
         Minecraft client = Minecraft.getInstance();
         Player player = client.player;
         Entity camera = client.getCameraEntity();
         if (camera != null && !client.gui.hud.isHidden()) {
            if (!player.isSpectator() || player != camera) {
               if (!player.isCreative()) {
                  Window window = client.getWindow();
                  if (HealthSystem.hasCustomHealth(camera)) {
                     float scale = overlay.scale;
                     float overlayWidth = 60.0F * scale;
                     float overlayHeight = 110.0F * scale;
                     Vector2f overlayPos = overlay.getPosition(0.0F, 0.0F, window.getGuiScaledWidth(), window.getGuiScaledHeight(), overlayWidth, overlayHeight);
                     Vector2f center = new Vector2f(overlayPos.x + overlayWidth / 2.0F, overlayPos.y + overlayHeight / 2.0F);
                     HealthContainer container = (HealthContainer)camera.getData(MedSystemDataAttachments.HEALTH_CONTAINER);
                     HealthContainerDefinition definition = container.getDefinition();
                     HealthContainerDisplay display = definition.display();
                     display.accept((limbCode, data) -> {
                        Limb limb = container.getLimbByCode(limbCode);
                        Vector4f position = data.getPos(scale, center);
                        int color = overlay.transparency << 24 | getColor(overlay.deadLimbColor, overlay.colorSchema, limb);
                        RenderUtils.fill(graphics, position.x, position.y, position.x + position.z, position.y + position.w, ARGB.scaleRGB(color, 0.8F));
                        RenderUtils.fill(graphics, position.x + 2.0F, position.y + 2.0F, position.x + position.z - 2.0F, position.y + position.w - 2.0F, color);
                     });
                     HorizontalAlignment overlayAlignment = overlay.horizontalAlignment;
                     Map<Identifier, List<StatusEffect>> effects = container.getLimbContainer()
                        .getStatusEffects()
                        .filter(effect -> StatusEffectType.isVisible(effect, EffectVisibility.ALWAYS))
                        .collect(Collectors.groupingBy(effect -> effect.getType().getIcon(effect), LinkedHashMap::new, Collectors.toList()));
                     int index = 0;

                     for (Entry<Identifier, List<StatusEffect>> entry : effects.entrySet()) {
                        List<StatusEffect> effectList = entry.getValue();
                        int x = overlayAlignment != HorizontalAlignment.RIGHT ? (int)(overlayPos.x() + overlayWidth) : (int)(overlayPos.x() - 12.0F);
                        int y = (int)(overlayPos.y() + index++ * 12);
                        RenderUtils.blitFull(graphics, entry.getKey(), x, y, x + 12, y + 12, -1);
                        int count = effectList.size();
                        if (count > 1) {
                           String text = String.valueOf(count);
                           graphics.text(client.font, text, x + 12 - client.font.width(text), y + 4, -1);
                        }
                     }
                  }
               }
            }
         }
      }
   }

   public static int getColor(String deadLimbColor, String[] colorSchema, Limb limb) {
      if (limb.isDead()) {
         return Integer.decode(deadLimbColor);
      }

      if (colorSchema.length == 0) {
         return 12303291;
      }

      if (colorSchema.length == 1) {
         return Integer.decode(colorSchema[0]);
      }

      float percent = 1.0F - limb.getHealthPercent();
      if (percent <= 0.0F) {
         return Integer.decode(colorSchema[0]);
      }

      if (percent >= 1.0F) {
         return Integer.decode(colorSchema[colorSchema.length - 1]);
      }

      float step = 1.0F / (colorSchema.length - 1);
      int stepIndex = Mth.floor(percent / step);
      int baseColor = Integer.decode(colorSchema[stepIndex]);
      int transitionColor = Integer.decode(colorSchema[stepIndex + 1]);
      float transitionPercent = (percent - stepIndex * step) / step;
      return ARGB.srgbLerp(transitionPercent, baseColor, transitionColor) & 16777215;
   }
}
