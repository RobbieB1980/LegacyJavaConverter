package tnt.tarkovcraft.medsystem.common.interaction;

import com.mojang.serialization.MapCodec;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.LivingEntity;
import tnt.tarkovcraft.core.api.EntityInteraction;
import tnt.tarkovcraft.core.api.EntityInteraction.Context;
import tnt.tarkovcraft.core.api.EntityInteraction.InteractionResult;
import tnt.tarkovcraft.core.api.EntityInteraction.Type;
import tnt.tarkovcraft.core.common.pose.EntityPoseManager;
import tnt.tarkovcraft.core.util.UserActionResult;
import tnt.tarkovcraft.medsystem.MedicalSystem;
import tnt.tarkovcraft.medsystem.common.blood_system.UnconsciousModeHelper;
import tnt.tarkovcraft.medsystem.common.init.MedSystemEntityInteractions;
import tnt.tarkovcraft.medsystem.common.pose.UnconsciousEntityPose;
import tnt.tarkovcraft.medsystem.util.HealthHelper;

public final class DismountEntityInteraction implements EntityInteraction {
   public static final DismountEntityInteraction INSTANCE = new DismountEntityInteraction();
   public static final MapCodec<DismountEntityInteraction> CODEC = MapCodec.unit(INSTANCE);
   public static final StreamCodec<RegistryFriendlyByteBuf, DismountEntityInteraction> STREAM_CODEC = StreamCodec.unit(INSTANCE);
   private static final Identifier IDENTIFIER = MedicalSystem.createIdentifier("dismount_entity");
   private static final String ERR_NOT_IN_VEHICLE = "not_in_vehicle";

   private DismountEntityInteraction() {
   }

   public static UserActionResult<Void> test(Context context) {
      LivingEntity target = context.target();
      return !target.isPassenger()
         ? UserActionResult.failure(Type.getErrorMessage(IDENTIFIER, "not_in_vehicle", new Object[0]))
         : UserActionResult.successEmpty();
   }

   public void onCompleted(Context context) {
      LivingEntity target = context.target();
      HealthHelper.doWithEntityControlOverride(target, () -> {
         target.stopRiding();
         EntityPoseManager.setEntityPose(target, UnconsciousEntityPose.INSTANCE);
         UnconsciousModeHelper.updateEntityDimensions(target);
      });
   }

   public void onFailed(Context context, InteractionResult reason) {
   }

   public Type<?> type() {
      return (Type<?>)MedSystemEntityInteractions.DISMOUNT_ENTITY.value();
   }
}
