package tnt.tarkovcraft.medsystem.common.blood_system;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.ComponentSerialization;
import net.minecraft.util.ExtraCodecs;

public record BloodTypeOptions(int color, Component label) {
   public static final Codec<BloodTypeOptions> CODEC = RecordCodecBuilder.<BloodTypeOptions>create(
      instance -> instance.group(
            ExtraCodecs.STRING_RGB_COLOR.optionalFieldOf("color", 11665408).forGetter(BloodTypeOptions::color),
            ComponentSerialization.CODEC.fieldOf("label").forGetter(BloodTypeOptions::label)
         )
         .apply(instance, BloodTypeOptions::new)
   );

   public Component getStylizedLabel() {
      return this.label.plainCopy().withColor(this.color);
   }
}
