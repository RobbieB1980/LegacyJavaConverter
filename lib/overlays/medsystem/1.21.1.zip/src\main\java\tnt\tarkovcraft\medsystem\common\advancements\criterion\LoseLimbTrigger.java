package tnt.tarkovcraft.medsystem.common.advancements.criterion;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.Collections;
import java.util.Optional;
import java.util.Set;
import net.minecraft.advancements.predicates.ContextAwarePredicate;
import net.minecraft.advancements.predicates.entity.EntityPredicate;
import net.minecraft.advancements.triggers.SimpleCriterionTrigger;
import net.minecraft.advancements.triggers.SimpleCriterionTrigger.SimpleInstance;
import net.minecraft.server.level.ServerPlayer;
import tnt.tarkovcraft.core.util.Codecs;
import tnt.tarkovcraft.medsystem.common.health.Limb;
import tnt.tarkovcraft.medsystem.common.health.LimbType;
import tnt.tarkovcraft.medsystem.common.init.MedSystemCriterionTriggers;

public final class LoseLimbTrigger extends SimpleCriterionTrigger<LoseLimbTrigger.TriggerInstance> {
   public static void triggerCriterion(ServerPlayer player, Limb limb) {
      LoseLimbTrigger trigger = (LoseLimbTrigger)MedSystemCriterionTriggers.LOSE_LIMB.value();
      trigger.trigger(player, limb);
   }

   public void trigger(ServerPlayer player, Limb limb) {
      this.trigger(player, trigger -> trigger.matches(limb));
   }

   public Codec<LoseLimbTrigger.TriggerInstance> codec() {
      return LoseLimbTrigger.TriggerInstance.CODEC;
   }

   public record TriggerInstance(Optional<ContextAwarePredicate> player, Set<LimbType> limbs) implements SimpleInstance {
      public static final Codec<LoseLimbTrigger.TriggerInstance> CODEC = RecordCodecBuilder.<LoseLimbTrigger.TriggerInstance>create(
         instance -> instance.group(
               EntityPredicate.ADVANCEMENT_CODEC.optionalFieldOf("player").forGetter(LoseLimbTrigger.TriggerInstance::player),
               Codecs.enumSet(LimbType.CODEC).optionalFieldOf("limbs", Collections.emptySet()).forGetter(LoseLimbTrigger.TriggerInstance::limbs)
            )
            .apply(instance, LoseLimbTrigger.TriggerInstance::new)
      );

      public boolean matches(Limb limb) {
         return this.limbs.isEmpty() || this.limbs.contains(limb.getType());
      }
   }
}
