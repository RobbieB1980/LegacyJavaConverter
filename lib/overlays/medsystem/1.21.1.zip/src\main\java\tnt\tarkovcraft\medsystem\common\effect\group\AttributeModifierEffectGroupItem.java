package tnt.tarkovcraft.medsystem.common.effect.group;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.function.Consumer;
import net.minecraft.ChatFormatting;
import net.minecraft.core.Holder;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.ComponentSerialization;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;
import tnt.tarkovcraft.core.common.attribute.Attribute;
import tnt.tarkovcraft.core.common.attribute.AttributeInstance;
import tnt.tarkovcraft.core.common.attribute.AttributeSystem;
import tnt.tarkovcraft.core.common.attribute.EntityAttributeData;
import tnt.tarkovcraft.core.common.attribute.modifier.AttributeModifier;
import tnt.tarkovcraft.core.common.init.CoreRegistries;
import tnt.tarkovcraft.medsystem.api.heal.SideEffect;
import tnt.tarkovcraft.medsystem.common.effect.StatusEffect;
import tnt.tarkovcraft.medsystem.common.effect.StatusEffectContext;
import tnt.tarkovcraft.medsystem.common.effect.util.EffectType;

public record AttributeModifierEffectGroupItem(Holder<Attribute> attribute, AttributeModifier modifier, EffectType classification, Component valueLabel)
   implements EffectGroupItem {
   public static final MapCodec<AttributeModifierEffectGroupItem> CODEC = RecordCodecBuilder.<AttributeModifierEffectGroupItem>mapCodec(
      instance -> instance.group(
            CoreRegistries.ATTRIBUTE.holderByNameCodec().fieldOf("attribute").forGetter(t -> t.attribute),
            AttributeModifier.CODEC.fieldOf("modifier").forGetter(t -> t.modifier),
            EffectType.CODEC.fieldOf("classification").forGetter(t -> t.classification),
            ComponentSerialization.CODEC.fieldOf("label").forGetter(t -> t.valueLabel)
         )
         .apply(instance, AttributeModifierEffectGroupItem::new)
   );

   @Override
   public void apply(EffectGroupHolder holder, StatusEffectContext context) {
   }

   @Override
   public void init(EffectGroupHolder holder, StatusEffectContext context) {
      LivingEntity entity = context.entity();
      if (AttributeSystem.isEnabledForEntity(entity)) {
         EntityAttributeData attributeData = AttributeSystem.getAttributes(entity);
         AttributeInstance instance = attributeData.getAttribute(this.attribute);
         instance.addModifier(this.modifier);
         AttributeSystem.sync(entity);
      }
   }

   @Override
   public void cleanup(EffectGroupHolder holder, StatusEffectContext context) {
      LivingEntity entity = context.entity();
      if (AttributeSystem.isEnabledForEntity(entity)) {
         EntityAttributeData attributeData = AttributeSystem.getAttributes(entity);
         AttributeInstance instance = attributeData.getAttribute(this.attribute);
         instance.removeModifier(this.modifier);
         AttributeSystem.sync(entity);
      }
   }

   @Override
   public void addInformation(EffectGroupHolder holder, Consumer<Component> tooltip, boolean isItemTooltip) {
      if (isItemTooltip) {
         MutableComponent component = ((Attribute)this.attribute.value()).getDisplayName().copy().append(" (").append(this.valueLabel).append(")");
         tooltip.accept(SideEffect.createDescriptionComponent(this.classification, component, 1.0F, holder.getDuration(), holder.getDelay()));
      } else {
         MutableComponent component = ((Attribute)this.attribute.value())
            .getDisplayName()
            .copy()
            .append(" (")
            .append(this.valueLabel)
            .append(") ")
            .append(StatusEffect.getDurationLabel(holder.getDuration()));
         tooltip.accept(component.withStyle(ChatFormatting.DARK_GRAY));
      }
   }

   @Override
   public EffectGroupItem copy() {
      return new AttributeModifierEffectGroupItem(this.attribute, this.modifier, this.classification, this.valueLabel);
   }

   @Override
   public EffectGroupHolder tryToMergeWith(EffectGroupHolder current, EffectGroupHolder other) {
      if (other.getItem() instanceof AttributeModifierEffectGroupItem attributeGroupItem
         && attributeGroupItem.attribute.value() == this.attribute.value()
         && attributeGroupItem.modifier.identifier().equals(this.modifier.identifier())) {
         int delay = Math.min(current.getDelay(), other.getDelay());
         int durationDiff = Mth.abs(current.getDuration() - other.getDuration());
         int newDuration = current.getDuration() + durationDiff / 2;
         return new EffectGroupHolder(current.getItem().copy(), newDuration, delay);
      } else {
         return null;
      }
   }

   @Override
   public MapCodec<? extends EffectGroupItem> codec() {
      return CODEC;
   }
}
