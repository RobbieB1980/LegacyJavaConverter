package tnt.tarkovcraft.medsystem.common.advancements.criterion;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.Optional;
import net.minecraft.advancements.predicates.ContextAwarePredicate;
import net.minecraft.advancements.predicates.entity.EntityPredicate;
import net.minecraft.advancements.triggers.SimpleCriterionTrigger;
import net.minecraft.advancements.triggers.SimpleCriterionTrigger.SimpleInstance;
import net.minecraft.core.HolderSet;
import net.minecraft.core.RegistryCodecs;
import net.minecraft.server.level.ServerPlayer;
import tnt.tarkovcraft.medsystem.common.effect.StatusEffect;
import tnt.tarkovcraft.medsystem.common.effect.StatusEffectType;
import tnt.tarkovcraft.medsystem.common.init.MedSystemCriterionTriggers;
import tnt.tarkovcraft.medsystem.common.init.MedSystemRegistries;

public class ReceiveStatusEffectTrigger extends SimpleCriterionTrigger<ReceiveStatusEffectTrigger.TriggerInstance> {
   public static void triggerCriterion(ServerPlayer player, StatusEffect effect) {
      ReceiveStatusEffectTrigger trigger = (ReceiveStatusEffectTrigger)MedSystemCriterionTriggers.RECEIVE_STATUS_EFFECT.value();
      trigger.trigger(player, effect);
   }

   public void trigger(ServerPlayer player, StatusEffect effect) {
      this.trigger(player, trigger -> trigger.matches(effect));
   }

   public Codec<ReceiveStatusEffectTrigger.TriggerInstance> codec() {
      return ReceiveStatusEffectTrigger.TriggerInstance.CODEC;
   }

   public record TriggerInstance(Optional<ContextAwarePredicate> player, Optional<HolderSet<StatusEffectType<?>>> effects) implements SimpleInstance {
      public static final Codec<ReceiveStatusEffectTrigger.TriggerInstance> CODEC = RecordCodecBuilder.<ReceiveStatusEffectTrigger.TriggerInstance>create(
         i -> i.group(
               EntityPredicate.ADVANCEMENT_CODEC.optionalFieldOf("player").forGetter(ReceiveStatusEffectTrigger.TriggerInstance::player),
               RegistryCodecs.homogeneousList(MedSystemRegistries.Keys.STATUS_EFFECT)
                  .optionalFieldOf("effects")
                  .forGetter(ReceiveStatusEffectTrigger.TriggerInstance::effects)
            )
            .apply(i, ReceiveStatusEffectTrigger.TriggerInstance::new)
      );

      public boolean matches(StatusEffect effect) {
         return this.effects.isEmpty() || effect.getType().is(this.effects.get());
      }
   }
}
