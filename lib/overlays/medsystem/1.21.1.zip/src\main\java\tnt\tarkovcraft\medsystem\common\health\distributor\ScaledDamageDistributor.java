package tnt.tarkovcraft.medsystem.common.health.distributor;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import tnt.tarkovcraft.medsystem.common.health.DamageContext;
import tnt.tarkovcraft.medsystem.common.health.Limb;

public record ScaledDamageDistributor(float scale, DamageDistributor source) implements DamageDistributor {
   public ScaledDamageDistributor(float scale) {
      this(scale, EvenDamageDistributor.INSTANCE);
   }

   @Override
   public Map<Limb, Float> distribute(DamageContext context, float damage) {
      Map<Limb, Float> damageMap = this.source.distribute(context, damage);
      Map<Limb, Float> result = new HashMap<>();

      for (Entry<Limb, Float> entry : damageMap.entrySet()) {
         result.put(entry.getKey(), entry.getValue() * this.scale);
      }

      return result;
   }
}
