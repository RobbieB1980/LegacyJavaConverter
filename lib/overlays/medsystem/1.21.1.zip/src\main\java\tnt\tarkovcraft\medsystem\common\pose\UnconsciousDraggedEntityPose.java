package tnt.tarkovcraft.medsystem.common.pose;

import com.mojang.serialization.MapCodec;
import java.util.Set;
import net.minecraft.world.entity.LivingEntity;
import tnt.tarkovcraft.core.common.pose.EntityPose;
import tnt.tarkovcraft.core.common.pose.EntityPoseFlag;
import tnt.tarkovcraft.core.common.pose.EntityPose.Type;
import tnt.tarkovcraft.medsystem.common.blood_system.BloodSystemManager;
import tnt.tarkovcraft.medsystem.common.init.MedSystemEntityPoses;

public final class UnconsciousDraggedEntityPose implements EntityPose {
   public static final UnconsciousDraggedEntityPose INSTANCE = new UnconsciousDraggedEntityPose();
   public static final MapCodec<UnconsciousDraggedEntityPose> CODEC = MapCodec.unit(INSTANCE);

   private UnconsciousDraggedEntityPose() {
   }

   public void onEnabled(LivingEntity livingEntity) {
   }

   public EntityPose onDisabled(LivingEntity livingEntity) {
      return BloodSystemManager.isUnconscious(livingEntity) ? UnconsciousEntityPose.INSTANCE : null;
   }

   public Set<EntityPoseFlag> getFlags() {
      return UnconsciousEntityPose.UNCONSCIOUS_FLAGS;
   }

   public Type<?> getType() {
      return (Type<?>)MedSystemEntityPoses.UNCONSCIOUS_DRAGGED.value();
   }
}
