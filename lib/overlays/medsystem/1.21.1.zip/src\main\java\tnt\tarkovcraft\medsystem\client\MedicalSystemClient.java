package tnt.tarkovcraft.medsystem.client;

import com.mojang.blaze3d.platform.InputConstants;
import com.mojang.blaze3d.platform.InputConstants.Type;
import dev.toma.configuration.Configuration;
import java.util.UUID;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.debug.DebugEntryNoop;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.core.particles.ParticleLimit;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Player;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.bus.api.ICancellableEvent;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.client.event.RegisterConditionalItemModelPropertyEvent;
import net.neoforged.neoforge.client.event.RegisterDebugEntriesEvent;
import net.neoforged.neoforge.client.event.RegisterDebugRenderersEvent;
import net.neoforged.neoforge.client.event.RegisterGuiLayersEvent;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import net.neoforged.neoforge.client.event.RegisterParticleProvidersEvent;
import net.neoforged.neoforge.client.event.RegisterRangeSelectItemModelPropertyEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent.Post;
import net.neoforged.neoforge.client.event.InputEvent.Key;
import net.neoforged.neoforge.client.event.InputEvent.MouseScrollingEvent;
import net.neoforged.neoforge.client.event.RegisterColorHandlersEvent.ItemTintSources;
import net.neoforged.neoforge.client.event.RenderGuiLayerEvent.Pre;
import net.neoforged.neoforge.client.event.ScreenEvent.Opening;
import net.neoforged.neoforge.client.gui.VanillaGuiLayers;
import net.neoforged.neoforge.client.network.ClientPacketDistributor;
import net.neoforged.neoforge.client.renderstate.RegisterRenderStateModifiersEvent;
import net.neoforged.neoforge.client.settings.KeyConflictContext;
import net.neoforged.neoforge.common.NeoForge;
import tnt.tarkovcraft.core.api.event.client.RegisterOnScreenHintEvent;
import tnt.tarkovcraft.core.api.event.client.RegisterPostShaderProgramsEvent;
import tnt.tarkovcraft.core.api.shader.PostEffectShaderProgram;
import tnt.tarkovcraft.core.client.TarkovCraftCoreClient;
import tnt.tarkovcraft.core.client.overlay.StaminaLayer;
import tnt.tarkovcraft.core.client.screen.navigation.CoreNavigators;
import tnt.tarkovcraft.core.client.screen.navigation.NavigationEntry;
import tnt.tarkovcraft.core.client.screen.navigation.OptionalNavigationEntry;
import tnt.tarkovcraft.core.util.helper.TextHelper;
import tnt.tarkovcraft.medsystem.MedicalSystem;
import tnt.tarkovcraft.medsystem.client.config.MedSystemClientConfig;
import tnt.tarkovcraft.medsystem.client.debug.HitResultInfoDebugRenderer;
import tnt.tarkovcraft.medsystem.client.model.properties.BloodVolumeItemModelProperty;
import tnt.tarkovcraft.medsystem.client.model.properties.IsEmptyBloodContainerItemModelProperty;
import tnt.tarkovcraft.medsystem.client.model.tint.BloodTintSource;
import tnt.tarkovcraft.medsystem.client.overlay.HealthLayer;
import tnt.tarkovcraft.medsystem.client.overlay.UnconsciousLayer;
import tnt.tarkovcraft.medsystem.client.particle.BloodDecalParticle;
import tnt.tarkovcraft.medsystem.client.particle.BloodDripParticle;
import tnt.tarkovcraft.medsystem.client.screen.HealthScreen;
import tnt.tarkovcraft.medsystem.client.shader.BloodLossEffectShaderProgram;
import tnt.tarkovcraft.medsystem.client.shader.ConcussionEffectShaderProgram;
import tnt.tarkovcraft.medsystem.client.shader.PainEffectShaderProgram;
import tnt.tarkovcraft.medsystem.client.shader.PainReliefEffectShaderProgram;
import tnt.tarkovcraft.medsystem.client.shader.UnconsciousEffectShaderProgram;
import tnt.tarkovcraft.medsystem.common.blood_system.BloodSystemManager;
import tnt.tarkovcraft.medsystem.common.blood_system.UnconsciousAnimationState;
import tnt.tarkovcraft.medsystem.common.blood_system.assignment.EntityBloodSystem;
import tnt.tarkovcraft.medsystem.common.blood_system.assignment.EntityBloodSystemDefinition;
import tnt.tarkovcraft.medsystem.common.health.HealthSystem;
import tnt.tarkovcraft.medsystem.common.init.MedSystemParticleTypes;
import tnt.tarkovcraft.medsystem.integration.core.GiveUpOnScreenHint;
import tnt.tarkovcraft.medsystem.network.message.C2S_RequestGiveUp;
import tnt.tarkovcraft.medsystem.network.message.C2S_SendMyRotation;

@Mod(value = "medsystem", dist = Dist.CLIENT)
public final class MedicalSystemClient {
   public static final KeyMapping KEY_GIVE_UP = new KeyMapping(
      TextHelper.createKeybindName("medsystem", "give_up"), KeyConflictContext.IN_GAME, Type.KEYSYM, 88, TarkovCraftCoreClient.SHARED_CATEGORY
   );
   public static final KeyMapping KEY_OPEN_HEALTH = new KeyMapping(
      TextHelper.createKeybindName("medsystem", "open_health"),
      KeyConflictContext.IN_GAME,
      Type.KEYSYM,
      InputConstants.UNKNOWN.getValue(),
      TarkovCraftCoreClient.SHARED_CATEGORY
   );
   public static final ParticleLimit BLOOD_PARTICLES_LIMIT = new ParticleLimit(2000);
   private static MedSystemClientConfig config;
   public static final NavigationEntry HEALTH = new OptionalNavigationEntry(TextHelper.createScreenTitle("medsystem", "health"), (var0, userId) -> {
      UUID clientId = Minecraft.getInstance().player.getUUID();
      return userId.equals(clientId);
   }, HealthScreen::new, 25);

   public MedicalSystemClient(IEventBus modEventBus, ModContainer container) {
      config = (MedSystemClientConfig)Configuration.registerSimpleYmlConfig(MedSystemClientConfig.class);
      modEventBus.addListener(this::registerGuiLayer);
      modEventBus.addListener(this::registerConditionalItemModelProperties);
      modEventBus.addListener(this::registerRangeSelectItemModelProperties);
      modEventBus.addListener(this::registerItemModelTintSources);
      modEventBus.addListener(this::registerKeyBinds);
      modEventBus.addListener(this::registerOnScreenHints);
      modEventBus.addListener(this::registerRenderStateExtensions);
      modEventBus.addListener(this::registerShaderPrograms);
      modEventBus.addListener(this::registerParticleProviders);
      modEventBus.addListener(this::registerDebugRenderers);
      modEventBus.addListener(this::registerDebugEntries);
      NeoForge.EVENT_BUS.addListener(this::onKeyInput);
      NeoForge.EVENT_BUS.addListener(this::prepareLayerRender);
      NeoForge.EVENT_BUS.addListener(this::onClientTick);
      NeoForge.EVENT_BUS.addListener(this::displayScreen);
      NeoForge.EVENT_BUS.addListener(EventPriority.HIGHEST, this::onMouseInput);
      NeoForge.EVENT_BUS.addListener(EventPriority.HIGHEST, this::onMouseWheelInput);
      CoreNavigators.CHARACTER_NAVIGATION_PROVIDER.register(HEALTH);
   }

   public static MedSystemClientConfig getConfig() {
      return config;
   }

   private void registerRenderStateExtensions(RegisterRenderStateModifiersEvent event) {
      @SuppressWarnings({ "unchecked", "rawtypes" })
      Class rendererClass = LivingEntityRenderer.class;
      event.registerEntityModifier(rendererClass, (entity, state) -> {
         if (!(entity instanceof net.minecraft.world.entity.LivingEntity livingEntity)) {
            return;
         }

         EntityBloodSystem bloodSystem = EntityBloodSystem.getAttached(livingEntity);
         if (bloodSystem != null) {
            EntityBloodSystemDefinition definition = bloodSystem.getDefinition();
            state.setRenderData(RenderStateExtensions.SPECIAL_POSE, definition.hasSpecialUnconsciousPoseRenderer());
            state.setRenderData(RenderStateExtensions.PASSENGER, livingEntity.isPassenger());
            state.setRenderData(RenderStateExtensions.UNCONSCIOUS, bloodSystem.isUnconscious());
            if (bloodSystem.isUnconscious() && bloodSystem.getUnconsciousState().shouldAnimate()) {
               UnconsciousAnimationState animationState = bloodSystem.getUnconsciousAnimationState(state.partialTick);
               state.setRenderData(RenderStateExtensions.UNCONSCIOUS_ANIMATION, animationState);
            }
         }
      });
   }

   private void registerGuiLayer(RegisterGuiLayersEvent event) {
      event.registerAbove(StaminaLayer.LAYER_ID, HealthLayer.LAYER_ID, new HealthLayer());
      event.registerBelowAll(UnconsciousLayer.LAYER_ID, new UnconsciousLayer());
   }

   private void prepareLayerRender(Pre event) {
      if (!config.renderHealth && event.getName().equals(VanillaGuiLayers.PLAYER_HEALTH)) {
         event.setCanceled(true);
      }
   }

   private void registerKeyBinds(RegisterKeyMappingsEvent event) {
      event.register(KEY_GIVE_UP);
      event.register(KEY_OPEN_HEALTH);
   }

   private void onKeyInput(Key event) {
      Minecraft minecraft = Minecraft.getInstance();
      Player player = minecraft.player;
      if (KEY_GIVE_UP.consumeClick() && BloodSystemManager.canSkipUnconsciousMode(player)) {
         ClientPacketDistributor.sendToServer(new C2S_RequestGiveUp(), new CustomPacketPayload[0]);
      }

      if (KEY_OPEN_HEALTH.consumeClick() && HealthSystem.hasCustomHealth(player)) {
         minecraft.gui.setScreen(new HealthScreen(null, player.getUUID()));
      }
   }

   private void registerOnScreenHints(RegisterOnScreenHintEvent event) {
      event.register(new GiveUpOnScreenHint());
   }

   private void registerConditionalItemModelProperties(RegisterConditionalItemModelPropertyEvent event) {
      event.register(MedicalSystem.createIdentifier("empty_blood_container"), IsEmptyBloodContainerItemModelProperty.CODEC);
   }

   private void registerRangeSelectItemModelProperties(RegisterRangeSelectItemModelPropertyEvent event) {
      event.register(MedicalSystem.createIdentifier("blood_volume"), BloodVolumeItemModelProperty.CODEC);
   }

   private void registerItemModelTintSources(ItemTintSources event) {
      event.register(BloodTintSource.IDENTIFIER, BloodTintSource.CODEC);
   }

   private void onMouseInput(net.neoforged.neoforge.client.event.InputEvent.MouseButton.Pre event) {
      this.cancelInputEventIfUnconscious(event);
   }

   private void onMouseWheelInput(MouseScrollingEvent event) {
      this.cancelInputEventIfUnconscious(event);
   }

   private void registerShaderPrograms(RegisterPostShaderProgramsEvent event) {
      event.registerMany(
         new PostEffectShaderProgram[]{
            new PainEffectShaderProgram(),
            new ConcussionEffectShaderProgram(),
            new BloodLossEffectShaderProgram(),
            new PainReliefEffectShaderProgram(),
            new UnconsciousEffectShaderProgram()
         }
      );
   }

   private void registerParticleProviders(RegisterParticleProvidersEvent event) {
      event.registerSpriteSet(MedSystemParticleTypes.BLOOD_DRIP.get(), BloodDripParticle.Provider::new);
      event.registerSpriteSet(MedSystemParticleTypes.BLOOD_DECAL.get(), BloodDecalParticle.Provider::new);
   }

   private void onClientTick(Post event) {
      Minecraft client = Minecraft.getInstance();
      if (client.player != null && MedicalSystem.getConfig().forceEntityRotationSynchronization) {
         float yBodyRot = Mth.wrapDegrees(client.player.yBodyRot);
         ClientPacketDistributor.sendToServer(new C2S_SendMyRotation(yBodyRot), new CustomPacketPayload[0]);
      }
   }

   private void registerDebugRenderers(RegisterDebugRenderersEvent event) {
      Minecraft client = Minecraft.getInstance();
      if (client.debugEntries.isCurrentlyEnabled(HitResultInfoDebugRenderer.IDENTIFIER)) {
         event.register(HitResultInfoDebugRenderer.INSTANCE);
      }
   }

   private void registerDebugEntries(RegisterDebugEntriesEvent event) {
      event.register(HitResultInfoDebugRenderer.IDENTIFIER, new DebugEntryNoop());
   }

   private void displayScreen(Opening event) {
      Minecraft client = Minecraft.getInstance();
      Player player = client.player;
      if (player != null && BloodSystemManager.isUnconscious(player) && event.getScreen() instanceof InventoryScreen) {
         event.setCanceled(true);
      }
   }

   private <E extends ICancellableEvent> void cancelInputEventIfUnconscious(E event) {
      Minecraft minecraft = Minecraft.getInstance();
      Player player = minecraft.player;
      if (player != null) {
         Screen screen = minecraft.gui.screen();
         if (screen == null) {
            if (BloodSystemManager.isUnconscious(player)) {
               event.setCanceled(true);
            }
         }
      }
   }
}
