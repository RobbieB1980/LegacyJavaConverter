package tnt.tarkovcraft.medsystem.client.config;

import dev.toma.configuration.config.Configurable;
import dev.toma.configuration.config.Configurable.Comment;
import dev.toma.configuration.config.Configurable.DecimalRange;
import dev.toma.configuration.config.Configurable.DependsOn;
import dev.toma.configuration.config.Configurable.Range;
import dev.toma.configuration.config.Configurable.StringPattern;
import dev.toma.configuration.config.Configurable.Synchronized;
import dev.toma.configuration.config.Configurable.Validate;
import dev.toma.configuration.config.Configurable.DependsOn.ConfigValue;
import dev.toma.configuration.config.Configurable.Gui.ColorValue;
import dev.toma.configuration.config.Configurable.Gui.NumberFormat;
import dev.toma.configuration.config.Configurable.Gui.Slider;
import dev.toma.configuration.config.validate.ValidationResult;
import dev.toma.configuration.config.validate.Validator;
import dev.toma.configuration.config.value.IConfigValueReadable;
import net.minecraft.network.chat.Component;
import tnt.tarkovcraft.core.common.data.duration.Duration;

public final class BloodDecalConfig {
   @Configurable
   @Comment("Toggles all blood decals")
   public boolean enableBloodDecals = true;
   @Configurable
   @Comment("Toggles blood decals for ALL entities even if they do not have custom health/blood system enabled")
   public boolean enableGenericBloodDecals = true;
   @Configurable
   @Comment("Forces all blood decals to be have specific color - configure in the option below")
   public boolean forceBloodDecalColor = false;
   @Configurable
   @StringPattern("^#[0-9a-fA-F]{1,6}$")
   @DependsOn(configValues = @ConfigValue(location = "medsystem:bloodDecals/forceBloodDecalColor", accepts = "true"))
   @ColorValue
   public String bloodDecalColor = "#B20000";
   @Configurable
   @Range(min = 100L, max = 72000L)
   @Synchronized
   @Validate(BloodDecalConfig.LifetimeValidator.class)
   public int bloodDecalLifetime = Duration.minutes(1).tickValue();
   @Configurable
   @DecimalRange(min = 0.1F, max = 0.35F)
   @Slider
   @NumberFormat("0.00")
   @Comment("Blood decal rendering scale")
   @Synchronized
   public float bloodDecalScale = 0.15F;
   @Configurable
   @DecimalRange(min = 0.0, max = 1.0)
   @Slider
   @NumberFormat("0.000")
   @Comment("Lifetime percentage at which decals will start to fade out")
   @Synchronized
   public float bloodDecalFadeOutAt = 0.25F;
   @Configurable
   @DecimalRange(min = 0.25)
   @NumberFormat("0.0##")
   @Comment("How much damage entity needs to receive in order for decal to appear")
   public float damageDecalScale = 3.0F;
   @Configurable
   @Range(min = 0L, max = 15L)
   @Slider
   @Comment({"Maximum amount of decals which can appear when damaging entities", "Set to 0 to disable damage decals"})
   public int maxDamageDecalsPerHit = 8;
   @Configurable
   @DecimalRange(min = 0.0, max = 1.5)
   @NumberFormat("0.0#")
   @Slider
   @Comment("How much motion is applied to decals on received damage")
   public float damageMotionScale = 0.25F;
   @Configurable
   @DecimalRange(min = 0.0, max = 1.5)
   @NumberFormat("0.0#")
   @Slider
   @Comment("How much motion is applied to decals on received damage from projectiles")
   public float projectileDamageMotionScale = 0.6F;

   public int getDecalColor(int inputColor) {
      return this.forceBloodDecalColor ? Integer.decode(this.bloodDecalColor) : inputColor;
   }

   public static final class LifetimeValidator implements Validator<Integer> {
      private static final int WARNING_THRESHOLD = Duration.minutes(20).tickValue();
      private static final Component MESSAGE = Component.translatable("label.medsystem.validation.config.decal_lifetime");

      public ValidationResult validate(Integer integer, IConfigValueReadable<Integer> iConfigValueReadable) {
         return integer >= WARNING_THRESHOLD ? ValidationResult.warning(MESSAGE) : ValidationResult.success();
      }
   }
}
