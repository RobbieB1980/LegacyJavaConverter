package tnt.tarkovcraft.medsystem.api.heal;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.UnaryOperator;
import net.minecraft.ChatFormatting;
import net.minecraft.core.Holder;
import net.minecraft.core.component.DataComponentGetter;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.ComponentSerialization;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.Item.TooltipContext;
import net.minecraft.world.item.component.TooltipProvider;
import net.minecraft.world.item.consume_effects.ConsumeEffect;
import tnt.tarkovcraft.core.common.data.duration.TickValue;
import tnt.tarkovcraft.medsystem.common.effect.StatusEffectType;
import tnt.tarkovcraft.medsystem.common.health.HealthContainer;
import tnt.tarkovcraft.medsystem.common.health.Limb;
import tnt.tarkovcraft.medsystem.common.health.applicator.SimpleEffectRecoveryApplicator;
import tnt.tarkovcraft.medsystem.common.item.HealingItem;

public record HealItemAttributes(
   boolean applyGlobally,
   boolean alwaysConsumable,
   int minUseTime,
   Surgery surgery,
   HealthRecovery health,
   List<EffectRecovery> recoveries,
   List<ConsumeEffect> effects,
   List<Component> additionalLabels
) implements TooltipProvider {
   public static final Codec<HealItemAttributes> CODEC = RecordCodecBuilder.<HealItemAttributes>create(
      instance -> instance.group(
            Codec.BOOL.optionalFieldOf("apply_globally", true).forGetter(HealItemAttributes::applyGlobally),
            Codec.BOOL.optionalFieldOf("always_consumable", false).forGetter(HealItemAttributes::alwaysConsumable),
            Codec.INT.optionalFieldOf("min_use_time", 20).forGetter(HealItemAttributes::minUseTime),
            Surgery.CODEC.optionalFieldOf("surgery").forGetter(t -> Optional.ofNullable(t.surgery)),
            HealthRecovery.CODEC.optionalFieldOf("health").forGetter(t -> Optional.ofNullable(t.health)),
            EffectRecovery.CODEC.listOf().optionalFieldOf("recovers", Collections.emptyList()).forGetter(HealItemAttributes::recoveries),
            ConsumeEffect.CODEC.listOf().optionalFieldOf("consume_effects", Collections.emptyList()).forGetter(HealItemAttributes::effects),
            ComponentSerialization.CODEC.listOf().optionalFieldOf("additional_labels", Collections.emptyList()).forGetter(HealItemAttributes::additionalLabels)
         )
         .apply(instance, HealItemAttributes::new)
   );

   private HealItemAttributes(HealItemAttributes.Builder builder) {
      this(
         !builder.requiresLimb,
         builder.alwaysConsumable,
         builder.minUseTime,
         builder.surgery,
         builder.healthRecovery,
         builder.recoveries,
         builder.effects,
         builder.additionalLabels
      );
   }

   private HealItemAttributes(
      boolean applyGlobally,
      boolean alwaysConsumable,
      int minUseTime,
      Optional<Surgery> deadLimbHealing,
      Optional<HealthRecovery> healthRecovery,
      List<EffectRecovery> recoveries,
      List<ConsumeEffect> effects,
      List<Component> additionalLabels
   ) {
      this(applyGlobally, alwaysConsumable, minUseTime, deadLimbHealing.orElse(null), healthRecovery.orElse(null), recoveries, effects, additionalLabels);
   }

   public static HealItemAttributes.Builder builder() {
      return new HealItemAttributes.Builder();
   }

   public static HealItemAttributes withSideEffectsOnly(int minUseTime) {
      return builder().setMinUseTime(minUseTime).setAlwaysConsumable().setNoLimbSelection().build();
   }

   public static HealItemAttributes withSideEffectsOnly(TickValue minUseTime) {
      return withSideEffectsOnly(minUseTime.tickValue());
   }

   public int getUseDuration(int max) {
      int duration = 0;
      if (this.surgery != null) {
         duration += this.surgery.useTime();
      }

      if (this.health != null) {
         duration = this.health.getMaxUseDuration(max);
      }

      return Math.max(duration, this.minUseTime());
   }

   public boolean canUseOn(LivingEntity entity, LivingEntity origin, ItemStack stack, HealthContainer container) {
      if (this.alwaysConsumable) {
         return true;
      } else if (!this.recoveries.isEmpty()
         && this.recoveries.stream().anyMatch(recovery -> HealingItem.checkDurability(stack, recovery.consumption()) && recovery.canUse(container, entity))) {
         return true;
      } else {
         return this.isSurgeryItem() && this.surgery.canHeal(container) ? true : this.health != null && entity.getHealth() < entity.getMaxHealth();
      }
   }

   public boolean canUseOnLimb(Limb limb, ItemStack stack, HealthContainer container, LivingEntity target) {
      if (this.alwaysConsumable) {
         return true;
      }

      if (!this.recoveries.isEmpty()) {
         for (EffectRecovery recovery : this.recoveries) {
            if (HealingItem.checkDurability(stack, recovery.consumption()) && recovery.canRecover(container, target, limb)) {
               return true;
            }
         }
      }

      return this.isSurgeryItem() && limb.isDead() ? true : this.health != null && !limb.isDead() && limb.getHealth() < limb.getMaxHealth();
   }

   public boolean isSurgeryItem() {
      return this.surgery != null;
   }

   public boolean isRecoveryItem() {
      return !this.recoveries.isEmpty();
   }

   public boolean isHealing() {
      return this.health != null;
   }

   public void addToTooltip(TooltipContext context, Consumer<Component> tooltipAdder, TooltipFlag flag, DataComponentGetter componentGetter) {
      if (this.health != null) {
         this.health.addToTooltip(context, tooltipAdder, flag, componentGetter);
      }

      this.additionalLabels.forEach(tooltipAdder);
      if (this.isSurgeryItem()) {
         tooltipAdder.accept(Component.translatable("tooltip.medsystem.heal_attributes.dead_limb.title").withStyle(ChatFormatting.GRAY));
         this.surgery.addToTooltip(context, tooltipAdder, flag, componentGetter);
      }

      if (!this.recoveries.isEmpty()) {
         tooltipAdder.accept(Component.translatable("tooltip.medsystem.heal_attributes.recoveries.title").withStyle(ChatFormatting.GRAY));
         this.recoveries.forEach(recovery -> recovery.addToTooltip(context, tooltipAdder, flag, componentGetter));
      }
   }

   public static final class Builder {
      private boolean requiresLimb = true;
      private boolean alwaysConsumable = false;
      private int minUseTime = 20;
      private Surgery surgery;
      private HealthRecovery healthRecovery;
      private final List<EffectRecovery> recoveries = new ArrayList<>();
      private final List<ConsumeEffect> effects = new ArrayList<>();
      private final List<Component> additionalLabels = new ArrayList<>();

      private Builder() {
      }

      public HealItemAttributes.Builder setNoLimbSelection() {
         this.requiresLimb = false;
         return this;
      }

      public HealItemAttributes.Builder setAlwaysConsumable() {
         this.alwaysConsumable = true;
         return this;
      }

      public HealItemAttributes.Builder setMinUseTime(int minUseTime) {
         this.minUseTime = minUseTime;
         return this;
      }

      public HealItemAttributes.Builder setMinUseTime(TickValue minUseTime) {
         return this.setMinUseTime(minUseTime.tickValue());
      }

      public HealItemAttributes.Builder surgeryItem(UnaryOperator<Surgery.SurgeryBuilder> builder) {
         Surgery.SurgeryBuilder surgeryBuilder = new Surgery.SurgeryBuilder();
         builder.apply(surgeryBuilder);
         this.surgery = surgeryBuilder.buildSurgeryAttributes();
         return this;
      }

      public HealItemAttributes.Builder healing(int duration, int count, float health) {
         if (duration < 20) {
            throw new IllegalArgumentException("duration must be greater than or equal to 20");
         }

         this.healthRecovery = new HealthRecovery(duration, health, count);
         return this;
      }

      public HealItemAttributes.Builder healing(TickValue duration, int count, float health) {
         return this.healing(duration.tickValue(), count, health);
      }

      public HealItemAttributes.Builder unrestrictedHealing(int duration, float health) {
         return this.healing(duration, 0, health);
      }

      public HealItemAttributes.Builder unrestrictedHealing(TickValue duration, float health) {
         return this.unrestrictedHealing(duration.tickValue(), health);
      }

      public HealItemAttributes.Builder removesEffect(int cost, EffectRecoveryApplicator applicator, boolean extendedTooltip) {
         this.recoveries.add(new EffectRecovery(cost, applicator, extendedTooltip));
         return this;
      }

      public HealItemAttributes.Builder removesEffect(int cost, EffectRecoveryApplicator applicator) {
         return this.removesEffect(cost, applicator, true);
      }

      public HealItemAttributes.Builder removesEffect(EffectRecoveryApplicator applicator) {
         return this.removesEffect(1, applicator);
      }

      public HealItemAttributes.Builder removesEffect(int cost, Holder<StatusEffectType<?>> effect) {
         return this.removesEffect(cost, new SimpleEffectRecoveryApplicator(effect), true);
      }

      public HealItemAttributes.Builder consumeEffect(ConsumeEffect effect) {
         this.effects.add(effect);
         return this;
      }

      public HealItemAttributes.Builder label(Component label) {
         this.additionalLabels.add(label);
         return this;
      }

      public <E extends ConsumeEffect> HealItemAttributes.Builder consumeEffectWithLabel(E effect, Function<E, Component> label) {
         return this.consumeEffect(effect).label(label.apply(effect));
      }

      public HealItemAttributes build() {
         return new HealItemAttributes(this);
      }
   }
}
