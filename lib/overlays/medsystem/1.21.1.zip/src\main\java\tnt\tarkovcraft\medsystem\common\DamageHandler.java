package tnt.tarkovcraft.medsystem.common;

import java.util.Map;
import java.util.Map.Entry;
import net.minecraft.resources.Identifier;
import net.minecraft.server.MinecraftServer;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.common.damagesource.DamageContainer.Reduction;
import net.neoforged.neoforge.event.entity.EntityInvulnerabilityCheckEvent;
import net.neoforged.neoforge.event.entity.living.ArmorHurtEvent;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;
import org.jspecify.annotations.Nullable;
import tnt.tarkovcraft.core.api.MovementStaminaComponent;
import tnt.tarkovcraft.core.api.event.LivingDamageApplyEvent;
import tnt.tarkovcraft.core.common.energy.EnergySystem;
import tnt.tarkovcraft.core.common.skill.SkillSystem;
import tnt.tarkovcraft.core.common.statistic.StatisticTracker;
import tnt.tarkovcraft.medsystem.MedicalSystem;
import tnt.tarkovcraft.medsystem.client.config.BloodDecalConfig;
import tnt.tarkovcraft.medsystem.client.particle.BloodDripParticleOptions;
import tnt.tarkovcraft.medsystem.common.armor.ArmorComponent;
import tnt.tarkovcraft.medsystem.common.armor.ArmorSystem;
import tnt.tarkovcraft.medsystem.common.blood_system.BloodConfiguration;
import tnt.tarkovcraft.medsystem.common.blood_system.BloodSystemManager;
import tnt.tarkovcraft.medsystem.common.blood_system.BloodTypeOptions;
import tnt.tarkovcraft.medsystem.common.blood_system.assignment.EntityBloodSystem;
import tnt.tarkovcraft.medsystem.common.config.MedSystemConfig;
import tnt.tarkovcraft.medsystem.common.damage.DamageResolver;
import tnt.tarkovcraft.medsystem.common.health.DamageContext;
import tnt.tarkovcraft.medsystem.common.health.EntityHitboxContainer;
import tnt.tarkovcraft.medsystem.common.health.HealthContainer;
import tnt.tarkovcraft.medsystem.common.health.HealthContainerDefinition;
import tnt.tarkovcraft.medsystem.common.health.HealthSystem;
import tnt.tarkovcraft.medsystem.common.health.Limb;
import tnt.tarkovcraft.medsystem.common.health.LimbContainer;
import tnt.tarkovcraft.medsystem.common.health.calc.HitCalculationContext;
import tnt.tarkovcraft.medsystem.common.health.calc.HitCalculationResult;
import tnt.tarkovcraft.medsystem.common.health.calc.HitCalculationResultDebugInfo;
import tnt.tarkovcraft.medsystem.common.health.calc.HitInfo;
import tnt.tarkovcraft.medsystem.common.health_event.HealthEventContext;
import tnt.tarkovcraft.medsystem.common.health_event.HealthEventParams;
import tnt.tarkovcraft.medsystem.common.init.MedSystemDataAttachments;
import tnt.tarkovcraft.medsystem.common.init.MedSystemHealthEventSources;
import tnt.tarkovcraft.medsystem.common.init.MedSystemSkillEvents;
import tnt.tarkovcraft.medsystem.common.init.MedSystemStats;
import tnt.tarkovcraft.medsystem.util.HealthHelper;

public final class DamageHandler {
   private static HitCalculationResultDebugInfo hitDebugInfo = null;
   private static final float DECAL_MELEE_SCALE = 0.5F;
   private static final float DECAL_PROJECTILE_SCALE = 0.4F;
   private static final double DECAL_MOTION_LIMIT = 0.6;

   @SubscribeEvent(priority = EventPriority.LOWEST)
   private void onInvulnerabilityCheck(EntityInvulnerabilityCheckEvent event) {
      if (!event.isInvulnerable()) {
         Entity entity = event.getEntity();
         if (entity instanceof LivingEntity livingEntity) {
            if (HealthSystem.hasCustomHealth(livingEntity)) {
               HealthContainer container = (HealthContainer)entity.getData(MedSystemDataAttachments.HEALTH_CONTAINER);
               DamageSource source = event.getSource();
               if (BloodSystemManager.isUnconscious(livingEntity) && source.is(DamageTypes.IN_WALL)) {
                  event.setInvulnerable(true);
               } else {
                  HitCalculationContext context = new HitCalculationContext(livingEntity, container, source);
                  DamageResolver resolver = MedicalSystem.DAMAGE_RESOLVER.getResolver(context);
                  HitCalculationResult result = resolver.calculate(context);
                  Level level = entity.level();
                  MinecraftServer server = level.getServer();
                  if (!level.isClientSide() && !server.isDedicatedServer()) {
                     hitDebugInfo = HitCalculationResultDebugInfo.collectDebugData(context, result);
                  }

                  if (result.isMiss()) {
                     event.setInvulnerable(true);
                  } else {
                     livingEntity.getExistingData(MedSystemDataAttachments.DAMAGE_CONTEXT).ifPresent(ctx -> ctx.init(context, result));
                  }
               }
            }
         }
      }
   }

   @SubscribeEvent
   private void onLivingDamage(LivingIncomingDamageEvent event) {
      LivingEntity entity = event.getEntity();
      DamageSource source = event.getSource();
      if (HealthSystem.hasCustomHealth(entity) && !source.is(DamageTypeTags.BYPASSES_ARMOR)) {
         if (!entity.level().isClientSide()) {
            if (event.isCanceled()) {
               entity.getExistingData(MedSystemDataAttachments.DAMAGE_CONTEXT).ifPresent(DamageContext::reset);
            } else {
               ArmorSystem armorSystem = MedicalSystem.getConfig().armor.armorSystem;
               ArmorComponent component = armorSystem.getComponent();
               entity.getExistingData(MedSystemDataAttachments.DAMAGE_CONTEXT).ifPresent(context -> {
                  if (context.isInitialized()) {
                     component.applyDamageReduction(event, context);
                  }
               });
            }
         }
      }
   }

   @SubscribeEvent
   private void onLivingApplyDamage(LivingDamageApplyEvent event) {
      LivingEntity entity = event.getEntity();
      DamageSource damageSource = event.getDamageSource();
      HealthContainer container = HealthContainer.getAttached(entity);
      EntityBloodSystem bloodSystem = EntityBloodSystem.getAttached(entity);
      Integer bloodDecalColor = getBloodColor(entity, container, bloodSystem);
      boolean bloodParticlesHandled = false;
      if (container != null) {
         DamageContext context = (DamageContext)entity.getExistingData(MedSystemDataAttachments.DAMAGE_CONTEXT)
            .orElseThrow(() -> new IllegalStateException("Damage context not set for entity " + entity));
         float damage = event.getHealthDamage();
         Map<Limb, Float> distributedDamage = context.getDamage(damage);
         float armorReduction = event.getReduction(Reduction.ARMOR);
         if (armorReduction > 0.0F) {
            SkillSystem.triggerAndSynchronize(MedSystemSkillEvents.ARMOR_USE, entity, armorReduction);
         }

         LimbContainer limbContainer = container.getLimbContainer();
         limbContainer.hurt(context, damage);
         float totalDamage = distributedDamage.values().stream().reduce(0.0F, Float::sum);
         int lostLimbCount = context.getLostLimbsCount();
         if (totalDamage > 0.0F) {
            context.triggerAdvancements(entity);
            if (!damageSource.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
               SkillSystem.triggerAndSynchronize(MedSystemSkillEvents.DAMAGE_TAKEN, entity, totalDamage);
               triggerStatusEffectEvent(entity, container, context, distributedDamage, totalDamage, lostLimbCount);
               if (!context.getHits().isEmpty() && bloodDecalColor != null) {
                  HitInfo hit = context.getHits().getFirst();
                  Limb damagedLimb = hit.limb();
                  HealthContainerDefinition definition = container.getDefinition();
                  EntityHitboxContainer hitboxContainer = definition.hitboxContainer();
                  String entityState = definition.getCurrentEntityState(entity);
                  Vec3 pos;
                  if (hit.entryPoint() != null) {
                     pos = hit.entryPoint();
                  } else {
                     AABB aabb = hitboxContainer.getLimbHitbox(damagedLimb.getLimbCode(), entityState).toWorldSpaceHitbox(entity);
                     pos = aabb.getCenter();
                  }

                  addBloodParticles(entity, damageSource, bloodDecalColor, pos, totalDamage);
               }
            }
         }

         bloodParticlesHandled = true;
         entity.getExistingData(MedSystemDataAttachments.DAMAGE_CONTEXT).ifPresent(DamageContext::reset);
         HealthHelper.synchronizeHealth(entity, container);
         HealthSystem.synchronizeEntity(entity);
         if (container.isDead()) {
            entity.setHealth(0.0F);
            return;
         }

         if (lostLimbCount > 0) {
            StatisticTracker.incrementOptional(entity, MedSystemStats.LIMBS_LOST, lostLimbCount);
         }

         MovementStaminaComponent component = (MovementStaminaComponent)EnergySystem.MOVEMENT_STAMINA.getComponent();
         if (entity.isSprinting() && !component.canSprint(entity)) {
            entity.setSprinting(false);
         }
      }

      if (!bloodParticlesHandled && bloodDecalColor != null && event.getHealthDamage() > 0.0F) {
         AABB box = entity.getBoundingBox();
         addBloodParticles(entity, damageSource, bloodDecalColor, box.getCenter(), event.getHealthDamage());
      }
   }

   @SubscribeEvent
   private void onArmorHit(ArmorHurtEvent event) {
      if (!event.isCanceled()) {
         LivingEntity entity = event.getEntity();
         if (HealthSystem.hasCustomHealth(entity)) {
            MedSystemConfig config = MedicalSystem.getConfig();
            ArmorSystem system = config.armor.armorSystem;
            ArmorComponent component = system.getComponent();
            entity.getExistingData(MedSystemDataAttachments.DAMAGE_CONTEXT).ifPresent(context -> component.applyItemDamage(event, context));
         }
      }
   }

   private static void triggerStatusEffectEvent(
      LivingEntity entity, HealthContainer container, DamageContext context, Map<Limb, Float> damage, float total, int lostLimbs
   ) {
      HealthEventContext globalCtx = HealthEventContext.withParams(entity, container, container.getRootLimb(), builder -> {
         builder.add(HealthEventParams.DAMAGE_CONTEXT, context);
         builder.add(HealthEventParams.DAMAGE_AMOUNT, total);
         builder.add(HealthEventParams.LIMBS_LOST, lostLimbs);
      });
      MedicalSystem.HEALTH_EVENT.triggerEvent(MedSystemHealthEventSources.INCOMING_DAMAGE_GLOBAL, globalCtx);

      for (Entry<Limb, Float> entry : damage.entrySet()) {
         Limb limb = entry.getKey();
         float localDamage = entry.getValue();
         HealthEventContext ctx = HealthEventContext.withParams(entity, container, limb, builder -> {
            builder.add(HealthEventParams.DAMAGE_CONTEXT, context);
            builder.add(HealthEventParams.DAMAGE_AMOUNT, total);
            builder.add(HealthEventParams.DAMAGE_AMOUNT_LIMB, localDamage);
         });
         MedicalSystem.HEALTH_EVENT.triggerEvent(MedSystemHealthEventSources.INCOMING_DAMAGE, ctx);
      }
   }

   public static @Nullable Integer getBloodColor(LivingEntity entity, @Nullable HealthContainer container, @Nullable EntityBloodSystem bloodSystem) {
      MedSystemConfig config = MedicalSystem.getConfig();
      if (!config.bloodDecals.enableBloodDecals) {
         return null;
      }

      if (bloodSystem != null) {
         Identifier bloodType = bloodSystem.getBloodType();
         BloodConfiguration bloodConfiguration = MedicalSystem.BLOOD_SYSTEM.getConfig();
         BloodTypeOptions options = bloodConfiguration.getOptions(bloodType).orElse(null);
         if (options != null) {
            return options.color();
         }
      }

      if (container != null) {
         HealthContainerDefinition definition = container.getDefinition();
         return definition.decalSettings().getColor(entity);
      } else {
         return config.bloodDecals.enableGenericBloodDecals ? Integer.decode(config.bloodDecals.bloodDecalColor) : null;
      }
   }

   private static void addBloodParticles(LivingEntity entity, DamageSource source, int color, Vec3 position, float damage) {
      BloodDecalConfig config = MedicalSystem.getConfig().bloodDecals;
      int particleCount = Math.min(Mth.floor(damage / config.damageDecalScale), config.maxDamageDecalsPerHit);
      if (particleCount > 0) {
         boolean projectile = source.is(DamageTypeTags.IS_PROJECTILE);
         Vec3 direction = getDirection(source, projectile);
         BloodDripParticleOptions options = new BloodDripParticleOptions(color);
         double dx = Math.min(direction.x, 0.6);
         double dy = 0.05;
         double dz = Math.min(direction.z, 0.6);
         HealthHelper.submitServerBleedParticles(options, particleCount, position.x, position.y, position.z, dx, dy, dz, 0.6, entity);
      }
   }

   private static Vec3 getDirection(DamageSource source, boolean projectile) {
      Entity damagingEntity = projectile ? source.getDirectEntity() : source.getEntity();
      Vec3 direction = Vec3.ZERO;
      float motionScale = 0.0F;
      if (damagingEntity != null) {
         direction = projectile ? damagingEntity.getDeltaMovement() : damagingEntity.getLookAngle();
         motionScale = projectile ? 0.4F : 0.5F;
      }

      return direction.multiply(motionScale, 1.0, motionScale);
   }

   public static HitCalculationResultDebugInfo getHitDebugInfo() {
      return hitDebugInfo;
   }
}
