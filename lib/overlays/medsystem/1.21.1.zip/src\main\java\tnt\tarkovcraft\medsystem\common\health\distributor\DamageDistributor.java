package tnt.tarkovcraft.medsystem.common.health.distributor;

import java.util.Map;
import tnt.tarkovcraft.medsystem.common.health.DamageContext;
import tnt.tarkovcraft.medsystem.common.health.Limb;

public interface DamageDistributor {
   Map<Limb, Float> distribute(DamageContext var1, float var2);
}
