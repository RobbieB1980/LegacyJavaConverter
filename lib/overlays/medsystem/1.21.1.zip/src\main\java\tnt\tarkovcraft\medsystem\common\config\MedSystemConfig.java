package tnt.tarkovcraft.medsystem.common.config;

import dev.toma.configuration.config.Config;
import dev.toma.configuration.config.Configurable;
import dev.toma.configuration.config.FieldVisibility;
import dev.toma.configuration.config.Configurable.Comment;
import dev.toma.configuration.config.Configurable.DecimalRange;
import dev.toma.configuration.config.Configurable.Synchronized;
import dev.toma.configuration.config.Configurable.Gui.NumberFormat;
import dev.toma.configuration.config.Configurable.Gui.Visibility;
import tnt.tarkovcraft.medsystem.client.config.BloodDecalConfig;

@Config(id = "medsystem", filename = "medicalsystem")
public final class MedSystemConfig {
   @Configurable
   @Synchronized
   @Visibility(FieldVisibility.ADVANCED)
   @Comment("Forces player rotation synchronization between server and clients")
   public boolean forceEntityRotationSynchronization = true;
   @Configurable
   @Synchronized
   @DecimalRange(min = 0.0, max = 0.5)
   @Visibility(FieldVisibility.ADVANCED)
   @NumberFormat("0.000")
   @Comment("Expands entity hitbox for projectile detection purposes by this amount in all directions")
   public float defaultEntityHitboxInflation = 0.2F;
   @Configurable
   @Comment("Uses less hit traces for explosions to save performance")
   public boolean useExplosionPerformanceMode = false;
   @Configurable
   @Comment("Allows interactions (such as healing) with other entities")
   @Synchronized
   public boolean allowThirdPartyEntityInteractions = true;
   @Configurable
   @Comment("Health related configurations")
   public HealthConfig health = new HealthConfig();
   @Configurable
   public ArmorSystemConfig armor = new ArmorSystemConfig();
   @Configurable
   @Comment("Blood/Unconscious system related configurations")
   public BloodSystemConfig bloodSystem = new BloodSystemConfig();
   @Configurable
   public StatusEffectConfig statusEffects = new StatusEffectConfig();
   @Configurable
   public BloodDecalConfig bloodDecals = new BloodDecalConfig();
}
