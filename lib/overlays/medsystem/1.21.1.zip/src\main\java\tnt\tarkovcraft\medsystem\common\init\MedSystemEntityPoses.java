package tnt.tarkovcraft.medsystem.common.init;

import com.mojang.serialization.MapCodec;
import net.minecraft.core.Holder;
import net.neoforged.neoforge.registries.DeferredRegister;
import tnt.tarkovcraft.core.common.init.CoreRegistries.Keys;
import tnt.tarkovcraft.core.common.pose.EntityPose;
import tnt.tarkovcraft.core.common.pose.EntityPose.Type;
import tnt.tarkovcraft.medsystem.common.pose.UnconsciousDraggedEntityPose;
import tnt.tarkovcraft.medsystem.common.pose.UnconsciousEntityPose;
import tnt.tarkovcraft.medsystem.common.pose.UnconsciousSittingEntityPose;

public final class MedSystemEntityPoses {
   public static final DeferredRegister<Type<?>> REGISTRY = DeferredRegister.create(Keys.ENTITY_POSE, "medsystem");
   public static final Holder<Type<?>> UNCONSCIOUS = register("unconscious", UnconsciousEntityPose.CODEC);
   public static final Holder<Type<?>> UNCONSCIOUS_SITTING = register("unconscious_sitting", UnconsciousSittingEntityPose.CODEC);
   public static final Holder<Type<?>> UNCONSCIOUS_DRAGGED = register("unconscious_dragged", UnconsciousDraggedEntityPose.CODEC);

   private static Holder<Type<?>> register(String name, MapCodec<? extends EntityPose> codec) {
      return REGISTRY.register(name, key -> new Type(key, codec));
   }
}
