package tnt.tarkovcraft.medsystem.client.screen.widget;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.Hud.HeartType;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.narration.NarrationElementOutput;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.input.MouseButtonInfo;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.util.ARGB;
import net.minecraft.util.Mth;
import tnt.tarkovcraft.core.client.screen.listener.SimpleClickListener;
import tnt.tarkovcraft.core.util.helper.MathHelper;
import tnt.tarkovcraft.core.util.helper.RenderUtils;
import tnt.tarkovcraft.medsystem.client.MedicalSystemClient;
import tnt.tarkovcraft.medsystem.client.config.HealthDisplayType;
import tnt.tarkovcraft.medsystem.client.config.HealthOverlayConfiguration;
import tnt.tarkovcraft.medsystem.client.config.MedSystemClientConfig;
import tnt.tarkovcraft.medsystem.client.overlay.HealthLayer;
import tnt.tarkovcraft.medsystem.common.effect.StatusEffect;
import tnt.tarkovcraft.medsystem.common.effect.StatusEffectType;
import tnt.tarkovcraft.medsystem.common.effect.util.EffectVisibility;
import tnt.tarkovcraft.medsystem.common.health.Limb;
import tnt.tarkovcraft.medsystem.common.init.MedSystemTags;

public class LimbHealthWidget extends AbstractWidget {
   private final Font font;
   private final Limb limb;
   private int frameSize = 1;
   private int frameColor = -1;
   private int frameHoverColor = -256;
   private int backgroundColor = -16777216;
   private int textColor = -1;
   private int textHoverColor = -256;
   private int effectScale = 12;
   private SimpleClickListener onClick;
   private List<StatusEffect> effects;
   private boolean effectDetail = true;
   private LimbHealthWidget.DisplayComponent displayComponent = this.getDefaultComponent();

   public LimbHealthWidget(int x, int y, int width, int height, Font font, Limb limb) {
      super(x, y, width, height, CommonComponents.EMPTY);
      this.font = font;
      this.limb = limb;
   }

   public void setEffects(List<StatusEffect> effects) {
      this.effects = effects;
   }

   public void setEffectIconSize(int effectIconSize) {
      this.effectScale = effectIconSize;
   }

   public void setClickListener(SimpleClickListener onClick) {
      this.onClick = onClick;
   }

   public void setFrameSize(int frameSize) {
      this.frameSize = frameSize;
   }

   public void setFrameColor(int frameColor) {
      this.frameColor = frameColor;
   }

   public void setFrameHoverColor(int frameHoverColor) {
      this.frameHoverColor = frameHoverColor;
   }

   public void setBackgroundColor(int backgroundColor) {
      this.backgroundColor = backgroundColor;
   }

   public void setTextColor(int textColor) {
      this.textColor = textColor;
   }

   public void setTextHoverColor(int textHoverColor) {
      this.textHoverColor = textHoverColor;
   }

   public void setEffectDetail(boolean effectDetail) {
      this.effectDetail = effectDetail;
   }

   public void setDisplayComponent(LimbHealthWidget.DisplayComponent displayComponent) {
      this.displayComponent = displayComponent;
   }

   protected boolean isValidClickButton(MouseButtonInfo info) {
      return this.onClick != null;
   }

   public void onClick(MouseButtonEvent event, boolean doubleClick) {
      this.onClick.onClick();
   }

   protected void extractWidgetRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float partialTick) {
      if (this.frameSize > 0 && RenderUtils.isVisibleColor(this.frameColor)) {
         int frameColor = this.isHovered ? this.frameHoverColor : this.frameColor;
         graphics.fill(this.getX(), this.getY(), this.getRight(), this.getBottom(), frameColor);
      }

      if (RenderUtils.isVisibleColor(this.backgroundColor)) {
         graphics.fill(
            this.getX() + this.frameSize,
            this.getY() + this.frameSize,
            this.getRight() - this.frameSize,
            this.getBottom() - this.frameSize,
            this.backgroundColor
         );
      }

      this.displayComponent.extractContents(graphics, this);
      if (this.height >= 19 + this.effectScale + this.frameSize * 2 && this.effects != null && !this.effects.isEmpty()) {
         List<StatusEffect> visibleEffects = this.effects.stream().filter(effectx -> StatusEffectType.isVisible(effectx, EffectVisibility.UI)).toList();
         if (visibleEffects.isEmpty()) {
            return;
         }

         int bounds = this.width - this.frameSize - 2;
         int maxEffects = Math.min(visibleEffects.size(), bounds / this.effectScale);

         for (int i = 0; i < maxEffects; i++) {
            StatusEffect effect = visibleEffects.get(i);
            StatusEffectType<?> type = effect.getType();
            int effectX = this.getX() + this.frameSize + 1 + i * this.effectScale;
            int effectY = this.getBottom() - this.frameSize - 1 - this.effectScale;
            RenderUtils.blitFull(graphics, type.getIcon(effect), effectX, effectY, effectX + this.effectScale, effectY + this.effectScale);
            if (this.effectDetail && MathHelper.isWithinBounds(mouseX, mouseY, effectX, effectY, this.effectScale, this.effectScale)) {
               List<Component> tooltip = new ArrayList<>();
               tooltip.add(type.getDisplayName(effect).copy().withStyle(type.getContextualEffectType(effect)));
               effect.addAdditionalInfo(tooltip::add);
               if (effect.hasVisibleDuration() && !effect.isInfinite()) {
                  tooltip.add(StatusEffect.getDurationLabel(effect.getDuration()));
               }

               if (type.is(MedSystemTags.StatusEffects.IS_PAIN_CAUSING)) {
                  tooltip.add(StatusEffect.PAINFUL_LABEL);
               }

               effect.addCustomTags(tooltip::add);
               graphics.setTooltipForNextFrame(this.font, tooltip, Optional.empty(), mouseX, mouseY);
            }
         }
      }
   }

   protected void updateWidgetNarration(NarrationElementOutput narrationElementOutput) {
   }

   private Component getStatusTitle(int scale) {
      return (Component)(this.isHovered
         ? this.limb.getDisplayName()
         : Component.literal(Mth.floor(this.limb.getHealth() * scale) + "/" + Mth.floor(this.limb.getMaxHealth() * scale)));
   }

   private LimbHealthWidget.DisplayComponent getDefaultComponent() {
      MedSystemClientConfig config = MedicalSystemClient.getConfig();
      return config.healthDisplayType == HealthDisplayType.NUMERIC ? LimbHealthWidget.DisplayComponent.NUMERIC : LimbHealthWidget.DisplayComponent.ICON;
   }

   public sealed interface DisplayComponent
      permits LimbHealthWidget.DisplayComponent.NumericDisplayComponent,
      LimbHealthWidget.DisplayComponent.IconDisplayComponent {
      LimbHealthWidget.DisplayComponent NUMERIC = new LimbHealthWidget.DisplayComponent.NumericDisplayComponent();
      LimbHealthWidget.DisplayComponent ICON = new LimbHealthWidget.DisplayComponent.IconDisplayComponent();

      void extractContents(GuiGraphicsExtractor var1, LimbHealthWidget var2);

      final class IconDisplayComponent implements LimbHealthWidget.DisplayComponent {
         @Override
         public void extractContents(GuiGraphicsExtractor graphics, LimbHealthWidget parent) {
            Limb limb = parent.limb;
            if (parent.isHovered) {
               this.renderLimbName(graphics, parent, limb);
            } else {
               this.renderLimbHealth(graphics, parent, limb);
            }
         }

         private void renderLimbName(GuiGraphicsExtractor graphics, LimbHealthWidget parent, Limb limb) {
            Component displayName = limb.getDisplayName();
            int width = parent.font.width(displayName);
            int left = parent.getX() + parent.frameSize + (parent.width - width - parent.frameSize) / 2;
            graphics.text(parent.font, displayName, left, parent.getY() + parent.frameSize + 5, parent.textHoverColor);
         }

         private void renderLimbHealth(GuiGraphicsExtractor graphics, LimbHealthWidget parent, Limb limb) {
            int maxHealth = Mth.ceil(limb.getMaxHealth());
            int health = Mth.ceil(limb.getHealth());
            int hearts = Mth.ceil(maxHealth / 2.0F);
            boolean vital = limb.isVital();
            int heartsWidth = hearts * 9;
            if (heartsWidth + parent.frameSize * 2 + 2 > parent.width) {
               this.renderSimplifiedDisplay(graphics, parent, health, vital);
            } else {
               this.renderFullDisplay(graphics, parent, hearts, health, vital);
            }
         }

         private void renderFullDisplay(GuiGraphicsExtractor graphics, LimbHealthWidget parent, int hearts, int health, boolean vital) {
            for (int i = 0; i < hearts; i++) {
               int left = parent.getX() + parent.frameSize + 1 + i * 9;
               int top = parent.getY() + parent.frameSize + 5;
               graphics.blitSprite(RenderPipelines.GUI_TEXTURED, HeartType.CONTAINER.getSprite(vital, false, false), left, top, 9, 9);
               int healthOffset = 2 * i;
               if (health > healthOffset) {
                  boolean halfHeart = health - healthOffset == 1;
                  graphics.blitSprite(RenderPipelines.GUI_TEXTURED, HeartType.NORMAL.getSprite(vital, halfHeart, false), left, top, 9, 9);
               }
            }
         }

         private void renderSimplifiedDisplay(GuiGraphicsExtractor graphics, LimbHealthWidget parent, int health, boolean vital) {
            int left = parent.getX() + parent.frameSize + 1;
            int top = parent.getY() + parent.frameSize + 5;
            graphics.blitSprite(RenderPipelines.GUI_TEXTURED, HeartType.CONTAINER.getSprite(vital, false, false), left, top, 9, 9);
            graphics.blitSprite(RenderPipelines.GUI_TEXTURED, HeartType.NORMAL.getSprite(vital, true, false), left, top, 9, 9);
            Component text = Component.literal(health + "x");
            graphics.text(parent.font, text, left + 12, top, -1);
         }
      }

      final class NumericDisplayComponent implements LimbHealthWidget.DisplayComponent {
         @Override
         public void extractContents(GuiGraphicsExtractor graphics, LimbHealthWidget parent) {
            MedSystemClientConfig config = MedicalSystemClient.getConfig();
            int scale = (int)Math.pow(10.0, config.numericHealthScale);
            Component status = parent.getStatusTitle(scale);
            int statusWidth = parent.font.width(status);
            int textColor = parent.limb.isDead() ? -65536 : (parent.isHovered ? parent.textHoverColor : parent.textColor);
            graphics.text(parent.font, status, parent.getX() + (parent.width - statusWidth) / 2, parent.getY() + 3 + parent.frameSize, textColor);
            HealthOverlayConfiguration overlay = config.healthOverlay;
            int background = Integer.decode(overlay.deadLimbColor) | 0xFF000000;
            int secondaryBackground = ARGB.scaleRGB(background, 0.8F);
            int color = HealthLayer.getColor(overlay.deadLimbColor, overlay.colorSchema, parent.limb) | 0xFF000000;
            int secondaryColor = ARGB.scaleRGB(color, 0.8F);
            float f = parent.limb.getHealthPercent();
            graphics.fillGradient(
               parent.getX() + parent.frameSize + 1,
               parent.getY() + parent.frameSize + 13,
               parent.getRight() - parent.frameSize - 1,
               parent.getY() + parent.frameSize + 17,
               background,
               secondaryBackground
            );
            int left = parent.getX() + parent.frameSize + 2;
            int right = parent.getRight() - parent.frameSize - 2;
            graphics.fillGradient(
               left, parent.getY() + parent.frameSize + 14, left + (int)((right - left) * f), parent.getY() + parent.frameSize + 16, color, secondaryColor
            );
         }
      }
   }
}
