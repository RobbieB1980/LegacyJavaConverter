package tnt.tarkovcraft.medsystem.common.effect.util;

import java.util.function.UnaryOperator;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Style;
import net.minecraft.util.StringRepresentable;
import net.minecraft.util.StringRepresentable.EnumCodec;
import net.minecraft.world.effect.MobEffectCategory;

public enum EffectType implements UnaryOperator<Style>, StringRepresentable {
   POSITIVE("positive"),
   NEUTRAL("neutral"),
   NEGATIVE("negative");

   public static final EnumCodec<EffectType> CODEC = StringRepresentable.fromEnum(EffectType::values);
   private final String serializedName;

   EffectType(String serializedName) {
      this.serializedName = serializedName;
   }

   public Style apply(Style style) {
      return style.applyFormat(this == POSITIVE ? ChatFormatting.GREEN : (this == NEGATIVE ? ChatFormatting.RED : ChatFormatting.YELLOW));
   }

   public String getSerializedName() {
      return this.serializedName;
   }

   public <T> T byValue(T positive, T negative, T neutral) {
      return (T)(switch (this) {
         case POSITIVE -> positive;
         case NEUTRAL -> neutral;
         case NEGATIVE -> negative;
      });
   }

   public static EffectType byMobEffectCategory(MobEffectCategory category) {
      return switch (category) {
         case HARMFUL -> NEGATIVE;
         case NEUTRAL -> NEUTRAL;
         case BENEFICIAL -> POSITIVE;
         default -> throw new MatchException(null, null);
      };
   }
}
