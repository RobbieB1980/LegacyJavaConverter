package tnt.tarkovcraft.medsystem.common.config;

import dev.toma.configuration.config.Configurable;
import dev.toma.configuration.config.Configurable.Range;
import net.minecraft.util.RandomSource;

public final class TimeRange {
   @Configurable
   @Range(min = 0L)
   public int minDuration;
   @Configurable
   @Range(min = 0L)
   public int maxDuration;

   public TimeRange(int minDuration, int maxDuration) {
      this.minDuration = minDuration;
      this.maxDuration = maxDuration;
   }

   public int getDurationInSeconds(RandomSource random) {
      int min = Math.min(this.minDuration, this.maxDuration);
      int bound = Math.max(this.minDuration, this.maxDuration) - min;
      return 20 * (bound > 0 ? min + random.nextInt(bound) : min);
   }
}
