package tnt.tarkovcraft.medsystem.api.heal;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.Locale;
import java.util.function.Consumer;
import net.minecraft.ChatFormatting;
import net.minecraft.core.component.DataComponentGetter;
import net.minecraft.network.chat.Component;
import net.minecraft.util.ExtraCodecs;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.Item.TooltipContext;
import net.minecraft.world.item.component.TooltipProvider;
import tnt.tarkovcraft.core.common.data.duration.Duration;
import tnt.tarkovcraft.core.util.Codecs;

public record HealthRecovery(int cycleDuration, float healthPerCycle, int maxCycles) implements TooltipProvider {
   public static final Codec<HealthRecovery> CODEC = RecordCodecBuilder.<HealthRecovery>create(
      instance -> instance.group(
            ExtraCodecs.POSITIVE_INT.optionalFieldOf("duration", 20).forGetter(HealthRecovery::cycleDuration),
            ExtraCodecs.POSITIVE_FLOAT.fieldOf("amount").forGetter(HealthRecovery::healthPerCycle),
            Codecs.NON_NEGATIVE_INT.optionalFieldOf("max_cycles", 1).forGetter(HealthRecovery::maxCycles)
         )
         .apply(instance, HealthRecovery::new)
   );

   public int getMaxUseDuration(int itemLimit) {
      return this.maxCycles > 0 ? this.maxCycles * this.cycleDuration : itemLimit;
   }

   public void addToTooltip(TooltipContext context, Consumer<Component> tooltipAdder, TooltipFlag flag, DataComponentGetter componentGetter) {
      Component healthPoints = Component.literal(String.format(Locale.ROOT, "%.1f", this.healthPerCycle)).withStyle(ChatFormatting.GREEN);
      Component duration = Duration.format(this.cycleDuration).copy().withStyle(ChatFormatting.GREEN);
      if (this.maxCycles > 0) {
         Component healLimit = Component.literal(String.format(Locale.ROOT, "%.1f", this.healthPerCycle * this.maxCycles)).withStyle(ChatFormatting.YELLOW);
         tooltipAdder.accept(
            Component.translatable("tooltip.medsystem.heal_attributes.heal.limited", new Object[]{healthPoints, duration, healLimit})
               .withStyle(ChatFormatting.GRAY)
         );
      } else {
         tooltipAdder.accept(
            Component.translatable("tooltip.medsystem.heal_attributes.heal.infinite", new Object[]{healthPoints, duration}).withStyle(ChatFormatting.GRAY)
         );
      }
   }
}
