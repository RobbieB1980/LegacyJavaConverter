package tnt.tarkovcraft.medsystem.common.blood_system;

import com.google.gson.JsonParser;
import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import com.mojang.serialization.JsonOps;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.io.IOException;
import java.io.Reader;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.Map.Entry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.resources.FileToIdConverter;
import net.minecraft.resources.Identifier;
import net.minecraft.server.packs.resources.Resource;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.server.packs.resources.SimpleJsonResourceReloadListener;
import net.minecraft.server.packs.resources.SimplePreparableReloadListener;
import net.minecraft.util.profiling.ProfilerFiller;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.neoforged.neoforge.event.AddServerReloadListenersEvent;
import org.apache.logging.log4j.Marker;
import org.apache.logging.log4j.MarkerManager;
import tnt.tarkovcraft.core.util.Codecs;
import tnt.tarkovcraft.core.util.helper.EntityHelper;
import tnt.tarkovcraft.medsystem.MedicalSystem;
import tnt.tarkovcraft.medsystem.common.blood_system.assignment.EntityBloodSystem;
import tnt.tarkovcraft.medsystem.common.blood_system.assignment.EntityBloodSystemDefinition;
import tnt.tarkovcraft.medsystem.common.config.MedSystemConfig;

public final class BloodSystemManager {
   private static final Marker MARKER = MarkerManager.getMarker("BloodSystemManager");
   private final BloodSystemManager.ConfigurationLoader configLoader = new BloodSystemManager.ConfigurationLoader();
   private final BloodSystemManager.BloodAssignmentLoader assignmentLoader = new BloodSystemManager.BloodAssignmentLoader();

   public static boolean isEnabled() {
      MedSystemConfig config = MedicalSystem.getConfig();
      return config.bloodSystem.useBloodSystem;
   }

   public static boolean isEnabled(LivingEntity entity) {
      return isEnabled() && EntityBloodSystem.getAttached(entity) != null;
   }

   public static boolean isUnconscious(LivingEntity entity) {
      return isEnabled(entity) && EntityBloodSystem.getAttached(entity).isUnconscious();
   }

   public static void synchronize(LivingEntity entity) {
      EntityBloodSystem system = EntityBloodSystem.getAttached(entity);
      if (system != null) {
         system.synchronizeImmediately(entity);
      }
   }

   public static void handleNewEntity(LivingEntity entity) {
      if (isEnabled()) {
         EntityBloodSystem existingBloodSystem = EntityBloodSystem.getAttached(entity);
         if (existingBloodSystem != null && existingBloodSystem.isValidBloodAttachment(entity)) {
            EntityBloodSystemDefinition definition = EntityBloodSystemDefinition.forEntity(entity);
            definition.bindListeners(existingBloodSystem, entity);
            return;
         }

         EntityBloodSystem.detach(entity);
         EntityBloodSystemDefinition definition = EntityBloodSystemDefinition.forEntity(entity);
         if (definition != null) {
            definition.bind(entity);
         }
      } else {
         EntityBloodSystem.detach(entity);
      }
   }

   public static boolean canSkipUnconsciousMode(LivingEntity entity) {
      EntityBloodSystem bloodSystem = EntityBloodSystem.getAttached(entity);
      if (bloodSystem == null) {
         return false;
      }

      UnconsciousState unconsciousState = bloodSystem.getUnconsciousState();
      UnconsciousOptions options = unconsciousState.getUnconsciousOptions();
      return !bloodSystem.hasBledOut() && bloodSystem.isUnconscious() && options.allowSkip() && !EntityHelper.isCreativeOrSpectator(entity);
   }

   public static float causeBloodLoss(LivingEntity entity, float amount) {
      EntityBloodSystem bloodSystem = EntityBloodSystem.getAttached(entity);
      if (bloodSystem != null && !EntityHelper.isCreativeOrSpectator(entity)) {
         float amountLost = bloodSystem.causeBloodLoss(amount);
         bloodSystem.synchronizeImmediately(entity);
         return amountLost;
      } else {
         return -1.0F;
      }
   }

   public void registerServerDataListeners(AddServerReloadListenersEvent event) {
      event.addListener(BloodSystemManager.ConfigurationLoader.ID, this.configLoader);
      event.addListener(BloodSystemManager.BloodAssignmentLoader.ID, this.assignmentLoader);
      event.addDependency(BloodSystemManager.ConfigurationLoader.ID, BloodSystemManager.BloodAssignmentLoader.ID);
   }

   public BloodConfiguration getConfig() {
      return this.configLoader.config;
   }

   public EntityBloodSystemDefinition getAssignment(EntityType<?> type) {
      return this.assignmentLoader.assignmentMap.get(type);
   }

   public Set<Identifier> getAvailableBloodTypes() {
      return this.getConfig().bloodTypes().keySet();
   }

   public BloodSystemManager.NetworkData prepareSynchronizationData() {
      return new BloodSystemManager.NetworkData(this.configLoader.config, this.assignmentLoader.assignmentMap);
   }

   public void receiveServerData(BloodSystemManager.NetworkData networkData) {
      this.configLoader.importServerConfiguration(networkData.configuration());
      this.assignmentLoader.importServerAssignments(networkData.assignments());
   }

   private final class BloodAssignmentLoader extends SimpleJsonResourceReloadListener<EntityBloodSystemDefinition> {
      private static final Identifier ID = MedicalSystem.createIdentifier("blood_assignment");
      private final Map<EntityType<?>, EntityBloodSystemDefinition> assignmentMap = new HashMap<>();

      private BloodAssignmentLoader() {
         super(EntityBloodSystemDefinition.CODEC, FileToIdConverter.json("tarkovcraft/blood_system/entity"));
      }

      protected void apply(Map<Identifier, EntityBloodSystemDefinition> map, ResourceManager resourceManager, ProfilerFiller profiler) {
         MedicalSystem.LOGGER.debug(BloodSystemManager.MARKER, "Loading entity blood assignment data");
         this.assignmentMap.clear();
         Set<Identifier> bloodTypeRegistry = BloodSystemManager.this.getAvailableBloodTypes();

         for (Entry<Identifier, EntityBloodSystemDefinition> entry : map.entrySet()) {
            Identifier id = entry.getKey();
            EntityBloodSystemDefinition definition = entry.getValue();
            this.validateAndRegister(id, definition, bloodTypeRegistry);
         }

         MedicalSystem.LOGGER.info(BloodSystemManager.MARKER, "Loaded {} entity blood assignments", this.assignmentMap.size());
      }

      private void validateAndRegister(Identifier fileId, EntityBloodSystemDefinition definition, Set<Identifier> bloodTypeRegistry) {
         for (Identifier bloodType : definition.getAvailableBloodTypes()) {
            if (!bloodTypeRegistry.contains(bloodType)) {
               MedicalSystem.LOGGER.error(BloodSystemManager.MARKER, "Unknown blood type '{}' defined within file '{}'", bloodType, fileId);
               return;
            }
         }

         for (EntityType<?> entity : definition.getEntityTypes()) {
            if (this.assignmentMap.put(entity, definition) != null) {
               MedicalSystem.LOGGER.warn(BloodSystemManager.MARKER, "Detected blood assignment override for entity '{}' from '{}'", entity, fileId);
            }
         }
      }

      void importServerAssignments(Map<EntityType<?>, EntityBloodSystemDefinition> data) {
         this.assignmentMap.clear();
         this.assignmentMap.putAll(data);
      }
   }

   private static final class ConfigurationLoader extends SimplePreparableReloadListener<BloodConfiguration> {
      private static final Identifier ID = MedicalSystem.createIdentifier("blood_configuration");
      private BloodConfiguration config = BloodConfiguration.missingConfiguration();

      protected BloodConfiguration prepare(ResourceManager resourceManager, ProfilerFiller profiler) {
         Optional<Resource> optional = resourceManager.getResource(MedicalSystem.createIdentifier("tarkovcraft/blood_system/blood_configuration.json"));
         Resource resource = optional.orElseThrow(() -> new IllegalStateException("Blood configuration file not found"));

         try (Reader reader = resource.openAsReader()) {
            DataResult<BloodConfiguration> result = BloodConfiguration.CODEC.parse(JsonOps.INSTANCE, JsonParser.parseReader(reader));
            return (BloodConfiguration)result.getPartialOrThrow(err -> new IllegalStateException("Failed to parse blood config file: " + err));
         } catch (IOException e) {
            throw new IllegalStateException("Failed to load blood configuration file", e);
         }
      }

      protected void apply(BloodConfiguration configuration, ResourceManager resourceManager, ProfilerFiller profiler) {
         this.config = configuration;
         MedicalSystem.LOGGER.info(BloodSystemManager.MARKER, "Blood configuration loaded");
         if (MedicalSystem.LOGGER.isDebugEnabled(BloodSystemManager.MARKER)) {
            Set<Identifier> bloodTypes = this.config.bloodTypes().keySet();
            bloodTypes.forEach(id -> MedicalSystem.LOGGER.debug(BloodSystemManager.MARKER, "Registered blood type: {}", id));
         }
      }

      void importServerConfiguration(BloodConfiguration configuration) {
         this.config = configuration;
      }
   }

   public record NetworkData(BloodConfiguration configuration, Map<EntityType<?>, EntityBloodSystemDefinition> assignments) {
      public static final Codec<BloodSystemManager.NetworkData> CODEC = RecordCodecBuilder.<BloodSystemManager.NetworkData>create(
         instance -> instance.group(
               BloodConfiguration.CODEC.fieldOf("configuration").forGetter(BloodSystemManager.NetworkData::configuration),
               Codec.unboundedMap(BuiltInRegistries.ENTITY_TYPE.byNameCodec(), EntityBloodSystemDefinition.CODEC)
                  .fieldOf("assignments")
                  .forGetter(BloodSystemManager.NetworkData::assignments)
            )
            .apply(instance, BloodSystemManager.NetworkData::new)
      );
      public static final StreamCodec<FriendlyByteBuf, BloodSystemManager.NetworkData> STREAM_CODEC = StreamCodec.of(
         (buffer, value) -> buffer.writeNbt(Codecs.encodeWithCodec(CODEC, value)),
         buffer -> (BloodSystemManager.NetworkData)Codecs.decodeWithCodec(CODEC, buffer.readNbt())
      );
   }
}
