package tnt.tarkovcraft.medsystem.common.effect;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.function.Consumer;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.util.StringRepresentable;
import net.minecraft.util.StringRepresentable.EnumCodec;
import net.minecraft.world.entity.LivingEntity;
import org.jspecify.annotations.Nullable;
import tnt.tarkovcraft.medsystem.MedicalSystem;
import tnt.tarkovcraft.medsystem.common.blood_system.BloodSystemManager;
import tnt.tarkovcraft.medsystem.common.blood_system.assignment.EntityBloodSystem;
import tnt.tarkovcraft.medsystem.common.blood_system.assignment.EntityBloodSystemDefinition;
import tnt.tarkovcraft.medsystem.common.init.MedSystemStatusEffects;

public class BloodLossStatusEffect extends IntervalAppliedStatusEffect {
   public static final MapCodec<BloodLossStatusEffect> CODEC = RecordCodecBuilder.<BloodLossStatusEffect>mapCodec(
      instance -> common(instance).and(BloodLossStatusEffect.Stage.CODEC.fieldOf("stage").forGetter(t -> t.stage)).apply(instance, BloodLossStatusEffect::new)
   );
   private final BloodLossStatusEffect.Stage stage;

   private BloodLossStatusEffect(int duration, BloodLossStatusEffect.Stage stage) {
      super(duration);
      this.stage = stage;
   }

   public BloodLossStatusEffect(int duration) {
      this(duration, BloodLossStatusEffect.Stage.MILD);
   }

   public static BloodLossStatusEffect createTemplate(BloodLossStatusEffect.Stage stage) {
      return new BloodLossStatusEffect(-1, stage);
   }

   @Override
   public void applyEffect(StatusEffectContext context) {
      LivingEntity entity = context.entity();
      if (!BloodSystemManager.isEnabled(entity)) {
         this.markForRemoval();
      } else {
         EntityBloodSystem bloodSystem = EntityBloodSystem.getAttached(entity);
         EntityBloodSystemDefinition definition = bloodSystem.getDefinition();
         float f = bloodSystem.getBloodVolume() / definition.getMaxBloodVolume();
         BloodLossStatusEffect.Stage actualStage = definition.getBloodLossStage(f);
         if (actualStage == null) {
            this.markForRemoval();
         }
      }
   }

   @Override
   public void onRemoved(StatusEffectContext context) {
   }

   @Override
   public int getUpdateInterval() {
      return 20;
   }

   @Override
   public boolean hasVisibleDuration() {
      return false;
   }

   @Override
   public @Nullable Component getCustomDisplayName() {
      return this.stage.getTitle();
   }

   @Override
   public @Nullable Identifier getCustomIcon() {
      return this.stage.getIcon();
   }

   @Override
   public void addAdditionalInfo(Consumer<Component> tooltip) {
      Component description = this.stage.getTooltip();
      if (description != null) {
         tooltip.accept(description);
      }
   }

   @Override
   public StatusEffect copy() {
      return new BloodLossStatusEffect(this.getDuration(), this.stage);
   }

   @Override
   public StatusEffectType<?> getType() {
      return (StatusEffectType<?>)MedSystemStatusEffects.BLOODLOSS.value();
   }

   public BloodLossStatusEffect.Stage getStage() {
      return this.stage;
   }

   public enum Stage implements StringRepresentable {
      MILD("mild", null),
      MODERATE("moderate", null),
      SEVERE("severe", Component.translatable("status_effect.medsystem.bloodloss.stage.severe.info").withStyle(ChatFormatting.DARK_GRAY));

      public static final EnumCodec<BloodLossStatusEffect.Stage> CODEC = StringRepresentable.fromEnum(BloodLossStatusEffect.Stage::values);
      private final String serializedName;
      private final Component title;
      private final Identifier icon;
      private final @Nullable Component tooltip;

      Stage(String serializedName, @Nullable Component tooltip) {
         this.serializedName = serializedName;
         this.title = Component.translatable("status_effect.medsystem.bloodloss.stage." + serializedName);
         this.icon = MedicalSystem.createIdentifier("textures/icons/status_effect/bloodloss_" + serializedName + ".png");
         this.tooltip = tooltip;
      }

      public String getSerializedName() {
         return this.serializedName;
      }

      public Component getTitle() {
         return this.title;
      }

      public Identifier getIcon() {
         return this.icon;
      }

      public @Nullable Component getTooltip() {
         return this.tooltip;
      }
   }
}
