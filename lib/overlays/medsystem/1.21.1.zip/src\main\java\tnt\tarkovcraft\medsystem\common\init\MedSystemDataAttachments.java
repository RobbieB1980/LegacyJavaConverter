package tnt.tarkovcraft.medsystem.common.init;

import com.mojang.serialization.Codec;
import java.util.function.Supplier;
import net.minecraft.network.codec.ByteBufCodecs;
import net.neoforged.neoforge.attachment.AttachmentType;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.NeoForgeRegistries.Keys;
import tnt.tarkovcraft.medsystem.api.heal.SideEffectHolder;
import tnt.tarkovcraft.medsystem.common.blood_system.assignment.EntityBloodSystem;
import tnt.tarkovcraft.medsystem.common.health.DamageContext;
import tnt.tarkovcraft.medsystem.common.health.HealthContainer;

public final class MedSystemDataAttachments {
   public static final DeferredRegister<AttachmentType<?>> REGISTRY = DeferredRegister.create(Keys.ATTACHMENT_TYPES, "medsystem");
   public static final Supplier<AttachmentType<HealthContainer>> HEALTH_CONTAINER = REGISTRY.register(
      "health_container",
      () -> AttachmentType.builder(HealthContainer::invalid).serialize(HealthContainer.MAP_CODEC).sync(new HealthContainer.SyncHandler()).build()
   );
   public static final Supplier<AttachmentType<SideEffectHolder>> SIDE_EFFECTS = REGISTRY.register(
      "side_effects", () -> AttachmentType.builder(SideEffectHolder::empty).serialize(SideEffectHolder.MAP_CODEC).build()
   );
   public static final Supplier<AttachmentType<DamageContext>> DAMAGE_CONTEXT = REGISTRY.register(
      "damage_context", () -> AttachmentType.builder(DamageContext::createEmptyInstance).build()
   );
   public static final Supplier<AttachmentType<EntityBloodSystem>> BLOOD_SYSTEM = REGISTRY.register(
      "blood_system",
      () -> AttachmentType.builder(EntityBloodSystem::invalid).serialize(EntityBloodSystem.CODEC).sync(new EntityBloodSystem.SyncHandler()).build()
   );
   public static final Supplier<AttachmentType<Boolean>> EXTERNALLY_CONTROLLED = REGISTRY.register(
      "externally_controlled", () -> AttachmentType.builder(() -> false).serialize(Codec.BOOL.fieldOf("active")).sync(ByteBufCodecs.BOOL).build()
   );
}
