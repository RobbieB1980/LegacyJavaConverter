package tnt.tarkovcraft.medsystem.common.config;

import dev.toma.configuration.config.Configurable;
import dev.toma.configuration.config.Configurable.Comment;
import dev.toma.configuration.config.Configurable.DecimalRange;
import dev.toma.configuration.config.Configurable.Range;
import dev.toma.configuration.config.Configurable.Synchronized;
import dev.toma.configuration.config.Configurable.Gui.NumberFormat;
import dev.toma.configuration.config.Configurable.Gui.Slider;
import tnt.tarkovcraft.core.common.data.duration.Duration;

public final class BloodSystemConfig {
   @Configurable
   @Synchronized
   @Comment("Enables blood system simulation, unconscious player state")
   public boolean useBloodSystem = true;
   @Configurable
   @Synchronized
   @Comment("Enables blood level display in health UI")
   public boolean showBloodLevel = false;
   @Configurable
   @Synchronized
   @Comment("Enables blood type display in health UI")
   public boolean showBloodType = true;
   @Configurable
   @Comment(
      {
            "Specifies when entities can target unconscious players",
            "ALWAYS - unconscious players will always be attacked",
            "IGNORE_RESCUE - unconscious players will be attacked as long as they're not in rescue mode",
            "NEVER - unconscious players will never be attacked"
      }
   )
   public UnconsciousEntityTargeting unconsciousEntityTargeting = UnconsciousEntityTargeting.NEVER;
   @Configurable
   @Comment("Will trigger downed state if playing alone in singleplayer")
   public boolean allowDownedSingleplayer = false;
   @Configurable
   @DecimalRange(min = 0.0, max = 1.0)
   @NumberFormat("0.00")
   @Slider
   @Comment("Chance specifying if you can enter unconscious state instead of dying so that you may be rescued by your friends")
   public float unconsciousOnDeathChance = 1.0F;
   @Configurable
   @Comment("Will prevent entering unconscious state on death if your head limb is dead too")
   @DecimalRange(min = 0.0, max = 1.0)
   @NumberFormat("0.00")
   @Slider
   public float unconsciousOnHeadDeathChance = 1.0F;
   @Configurable
   @Range(min = 200L)
   @Comment("Rescue waiting period before dying while in death unconscious state")
   public int rescueWaitDuration = Duration.parse("2m30s").tickValue();
   @Configurable
   @Comment("Unconscious duration interval on unconsciousness due to blood loss")
   public TimeRange unconsciousOnBloodLoss = new TimeRange(5, 10);
   @Configurable
   @DecimalRange(min = 0.0, max = 1.0)
   @NumberFormat("0.00")
   @Slider
   public float unconsciousHeldItemDropChance = 0.6F;
   @Configurable
   @Synchronized
   @DecimalRange(min = 0.0, max = 1.0)
   @NumberFormat("0.00")
   @Slider
   public float unconsciousSoundVolumeScale = 0.2F;
   @Configurable
   @Synchronized
   @DecimalRange(min = 0.0, max = 1.0)
   @NumberFormat("0.00")
   @Slider
   public float unconsciousSoundPitchScale = 0.7F;
   @Configurable
   @Synchronized
   public UnconsciousOverlayType unconsciousOverlayType = UnconsciousOverlayType.BLINKING;
   @Configurable
   @DecimalRange(min = 0.0, max = 1.0)
   @NumberFormat("0.000")
   @Slider
   public float shockPerHpLoss = 0.04F;
   @Configurable
   @DecimalRange(min = 0.0, max = 1.0)
   @NumberFormat("0.000")
   @Slider
   public float shockPerLimbLoss = 0.25F;
   @Configurable
   @DecimalRange(min = 0.0, max = 1.0)
   @NumberFormat("0.000")
   @Slider
   public float shockPerFracture = 0.1F;
}
