package tnt.tarkovcraft.medsystem.api.heal;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import java.util.Optional;
import java.util.function.Consumer;
import java.util.function.Function;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.LivingEntity;
import tnt.tarkovcraft.medsystem.common.effect.StatusEffect;
import tnt.tarkovcraft.medsystem.common.health.HealthContainer;
import tnt.tarkovcraft.medsystem.common.health.Limb;
import tnt.tarkovcraft.medsystem.common.init.MedSystemRegistries;

public interface EffectRecoveryApplicator {
   Codec<EffectRecoveryApplicator> CODEC = MedSystemRegistries.EFFECT_RECOVERY_APPLICATOR
      .byNameCodec()
      .dispatch(EffectRecoveryApplicator::codec, Function.identity());

   Optional<StatusEffect> findRecoverableEffect(HealthContainer var1, LivingEntity var2, Limb var3);

   void apply(HealthContainer var1, LivingEntity var2, StatusEffect var3, Limb var4);

   void addLabels(Consumer<Component> var1, Consumer<Component> var2);

   MapCodec<? extends EffectRecoveryApplicator> codec();
}
