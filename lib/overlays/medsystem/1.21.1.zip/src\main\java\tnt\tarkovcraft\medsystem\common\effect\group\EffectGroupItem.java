package tnt.tarkovcraft.medsystem.common.effect.group;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import java.util.function.Consumer;
import java.util.function.Function;
import net.minecraft.network.chat.Component;
import tnt.tarkovcraft.medsystem.common.effect.StatusEffectContext;
import tnt.tarkovcraft.medsystem.common.init.MedSystemRegistries;

public interface EffectGroupItem {
   Codec<EffectGroupItem> CODEC = MedSystemRegistries.EFFECT_GROUP_ITEM.byNameCodec().dispatch(EffectGroupItem::codec, Function.identity());

   void init(EffectGroupHolder var1, StatusEffectContext var2);

   void apply(EffectGroupHolder var1, StatusEffectContext var2);

   void cleanup(EffectGroupHolder var1, StatusEffectContext var2);

   void addInformation(EffectGroupHolder var1, Consumer<Component> var2, boolean var3);

   default boolean visible() {
      return true;
   }

   EffectGroupItem copy();

   EffectGroupHolder tryToMergeWith(EffectGroupHolder var1, EffectGroupHolder var2);

   MapCodec<? extends EffectGroupItem> codec();
}
