package tnt.tarkovcraft.medsystem.client.config;

import dev.toma.configuration.config.Configurable;
import dev.toma.configuration.config.Configurable.Comment;
import dev.toma.configuration.config.Configurable.DecimalRange;
import dev.toma.configuration.config.Configurable.Range;
import dev.toma.configuration.config.Configurable.Gui.ColorValue;
import dev.toma.configuration.config.Configurable.Gui.NumberFormat;
import dev.toma.configuration.config.Configurable.Gui.Slider;
import tnt.tarkovcraft.core.client.config.ConfigurableOverlay;
import tnt.tarkovcraft.core.util.HorizontalAlignment;
import tnt.tarkovcraft.core.util.VerticalAlignment;

public class HealthOverlayConfiguration extends ConfigurableOverlay {
   @Configurable
   @DecimalRange(min = 0.5, max = 2.5)
   @Slider
   @NumberFormat("0.0#")
   @Comment("Health overlay scale")
   public float scale = 1.0F;
   @Configurable
   @Range(min = 0L, max = 255L)
   @Slider
   @Comment("Health overlay transparency")
   public int transparency = 136;
   @Configurable
   @ColorValue
   @Comment("Overlay color for dead limbs")
   public String deadLimbColor = "#444444";
   @Configurable
   @ColorValue
   @Comment("Color schema used for color blending of limb overlay based on the part health")
   public String[] colorSchema = new String[]{"#00FF00", "#FFFF00", "#FF0000"};

   public HealthOverlayConfiguration(boolean enabled, HorizontalAlignment horizontalAlignment, VerticalAlignment verticalAlignment, int x, int y) {
      super(enabled, horizontalAlignment, verticalAlignment, x, y);
   }
}
