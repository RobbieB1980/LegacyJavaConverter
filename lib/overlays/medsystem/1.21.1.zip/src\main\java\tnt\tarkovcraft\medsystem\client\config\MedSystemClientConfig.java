package tnt.tarkovcraft.medsystem.client.config;

import dev.toma.configuration.config.Config;
import dev.toma.configuration.config.Configurable;
import dev.toma.configuration.config.Configurable.Comment;
import dev.toma.configuration.config.Configurable.DependsOn;
import dev.toma.configuration.config.Configurable.Range;
import dev.toma.configuration.config.Configurable.DependsOn.ConfigValue;
import dev.toma.configuration.config.Configurable.Gui.Slider;
import tnt.tarkovcraft.core.util.HorizontalAlignment;
import tnt.tarkovcraft.core.util.VerticalAlignment;

@Config(id = "medsystem-client", filename = "medicalsystem-client", group = "medsystem")
public final class MedSystemClientConfig {
   @Configurable
   public HealthOverlayConfiguration healthOverlay = new HealthOverlayConfiguration(true, HorizontalAlignment.LEFT, VerticalAlignment.TOP, 0, 0);
   @Configurable
   @Comment("Allows you to toggle default health HUD overlay")
   public boolean renderHealth = true;
   @Configurable
   @Comment("Set limb health detail render mode")
   public HealthDisplayType healthDisplayType = HealthDisplayType.HEARTS;
   @Configurable
   @Range(min = 0L, max = 2L)
   @DependsOn(configValues = @ConfigValue(location = "medsystem-client:healthDisplayType", accepts = "NUMERIC"))
   @Slider
   public int numericHealthScale = 1;
}
