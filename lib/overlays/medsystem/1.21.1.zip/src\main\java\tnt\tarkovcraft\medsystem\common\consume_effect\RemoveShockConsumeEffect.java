package tnt.tarkovcraft.medsystem.common.consume_effect;

import com.mojang.serialization.MapCodec;
import java.util.Locale;
import java.util.function.UnaryOperator;
import net.minecraft.ChatFormatting;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.consume_effects.ConsumeEffect;
import net.minecraft.world.item.consume_effects.ConsumeEffect.Type;
import net.minecraft.world.level.Level;
import tnt.tarkovcraft.core.common.data.number.NumberProvider;
import tnt.tarkovcraft.medsystem.common.blood_system.BloodSystemManager;
import tnt.tarkovcraft.medsystem.common.blood_system.assignment.EntityBloodSystem;
import tnt.tarkovcraft.medsystem.common.init.MedSystemConsumeEffects;

public record RemoveShockConsumeEffect(float amount) implements ConsumeEffect {
   public static final MapCodec<RemoveShockConsumeEffect> CODEC = NumberProvider.POSITIVE_FLOAT
      .xmap(RemoveShockConsumeEffect::new, RemoveShockConsumeEffect::amount)
      .fieldOf("amount");
   public static final StreamCodec<RegistryFriendlyByteBuf, RemoveShockConsumeEffect> STREAM_CODEC = ByteBufCodecs.fromCodecWithRegistries(CODEC.codec());

   public static Component createTooltipLabel(float amount) {
      return createTooltipLabel(String.format(Locale.ROOT, "%.1f%%", amount * 100.0F), style -> style.withColor(ChatFormatting.GREEN));
   }

   public static Component createTooltipLabel(String amount, UnaryOperator<Style> styleApplicator) {
      Component value = Component.literal(amount).withStyle(styleApplicator);
      return Component.translatable("tooltip.medsystem.heal_attributes.shock_reduction", new Object[]{value}).withStyle(ChatFormatting.GRAY);
   }

   public Component createTooltipLabel() {
      return createTooltipLabel(this.amount);
   }

   public boolean apply(Level level, ItemStack stack, LivingEntity entity) {
      if (BloodSystemManager.isEnabled(entity)) {
         EntityBloodSystem bloodSystem = EntityBloodSystem.getAttached(entity);
         bloodSystem.removeShock(this.amount);
         return true;
      } else {
         return false;
      }
   }

   public Type<? extends ConsumeEffect> getType() {
      return (Type<? extends ConsumeEffect>)MedSystemConsumeEffects.REMOVE_SHOCK.value();
   }
}
