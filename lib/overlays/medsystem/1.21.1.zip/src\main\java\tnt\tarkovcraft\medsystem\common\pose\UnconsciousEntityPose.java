package tnt.tarkovcraft.medsystem.common.pose;

import com.mojang.serialization.MapCodec;
import java.util.Set;
import tnt.tarkovcraft.core.common.pose.CoreEntityPoseFlags;
import tnt.tarkovcraft.core.common.pose.EntityPoseFlag;
import tnt.tarkovcraft.core.common.pose.EntityStatusPose;
import tnt.tarkovcraft.core.common.pose.EntityPose.Type;
import tnt.tarkovcraft.medsystem.common.init.MedSystemEntityPoses;

public final class UnconsciousEntityPose extends EntityStatusPose {
   public static final UnconsciousEntityPose INSTANCE = new UnconsciousEntityPose();
   public static final MapCodec<UnconsciousEntityPose> CODEC = MapCodec.unit(INSTANCE);
   public static final Set<EntityPoseFlag> UNCONSCIOUS_FLAGS = Set.of(
      CoreEntityPoseFlags.NO_INTERACTION, CoreEntityPoseFlags.NO_MOVEMENT, CoreEntityPoseFlags.NO_KNOCKBACK
   );

   private UnconsciousEntityPose() {
   }

   public Set<EntityPoseFlag> getFlags() {
      return UNCONSCIOUS_FLAGS;
   }

   public Type<?> getType() {
      return (Type<?>)MedSystemEntityPoses.UNCONSCIOUS.value();
   }
}
