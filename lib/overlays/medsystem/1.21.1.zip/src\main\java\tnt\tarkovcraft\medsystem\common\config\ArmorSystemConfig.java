package tnt.tarkovcraft.medsystem.common.config;

import dev.toma.configuration.config.Configurable;
import dev.toma.configuration.config.UpdateRestrictions;
import dev.toma.configuration.config.Configurable.Comment;
import dev.toma.configuration.config.Configurable.DecimalRange;
import dev.toma.configuration.config.Configurable.Synchronized;
import dev.toma.configuration.config.Configurable.UpdateRestriction;
import dev.toma.configuration.config.Configurable.Gui.NumberFormat;
import java.util.Set;
import net.minecraft.world.entity.EquipmentSlot;
import tnt.tarkovcraft.medsystem.common.armor.ArmorSystem;
import tnt.tarkovcraft.medsystem.common.health.LimbType;

public class ArmorSystemConfig {
   @Configurable
   @Comment(
      {
            "Defines armor calculation logic with custom health system",
            "SIMULATED - modular armor with fully simulated logic such as deflections, blunt damage and so on",
            "MODULAR - modular armor - getting entryPoint in head damages only helmet",
            "MODULAR_BOOSTED - same as above, but each armor piece has additional protection. Configurable below",
            "VANILLA - vanilla armor calculation, full armor is used for any damage calculations"
      }
   )
   @UpdateRestriction(UpdateRestrictions.MAIN_MENU)
   public ArmorSystem armorSystem = ArmorSystem.SIMULATED;
   @Configurable
   @Synchronized
   @DecimalRange(min = 0.0)
   @NumberFormat("0.000")
   @Comment("Additional armor protection per armor piece when using MODULAR_BOOSTED armor system")
   public float modularBoostedArmorMultiplier = 2.5F;
   @Configurable
   @Comment("Configure which limbs are covered by specific armor pieces. Does nothing when using VANILLA armor system")
   public ArmorSystemConfig.LimbArmorProtectionAreas limbArmorProtectionAreas = new ArmorSystemConfig.LimbArmorProtectionAreas();

   public Set<EquipmentSlot> getProtectedAreasForLimb(LimbType limb) {
      EquipmentSlot[] slots = switch (limb) {
         case HEAD -> this.limbArmorProtectionAreas.head;
         case TORSO -> this.limbArmorProtectionAreas.chest;
         case STOMACH -> this.limbArmorProtectionAreas.stomach;
         case ARM -> this.limbArmorProtectionAreas.arms;
         case LEG -> this.limbArmorProtectionAreas.legs;
         case ANIMAL -> this.limbArmorProtectionAreas.animalBody;
         default -> this.limbArmorProtectionAreas.other;
      };
      return Set.of(slots);
   }

   public static class LimbArmorProtectionAreas {
      @Configurable
      public EquipmentSlot[] head = new EquipmentSlot[]{EquipmentSlot.HEAD};
      @Configurable
      public EquipmentSlot[] chest = new EquipmentSlot[]{EquipmentSlot.CHEST};
      @Configurable
      public EquipmentSlot[] stomach = new EquipmentSlot[]{EquipmentSlot.CHEST};
      @Configurable
      public EquipmentSlot[] arms = new EquipmentSlot[0];
      @Configurable
      public EquipmentSlot[] legs = new EquipmentSlot[]{EquipmentSlot.LEGS, EquipmentSlot.FEET};
      @Configurable
      public EquipmentSlot[] animalBody = new EquipmentSlot[]{EquipmentSlot.BODY};
      @Configurable
      public EquipmentSlot[] other = new EquipmentSlot[0];
   }
}
