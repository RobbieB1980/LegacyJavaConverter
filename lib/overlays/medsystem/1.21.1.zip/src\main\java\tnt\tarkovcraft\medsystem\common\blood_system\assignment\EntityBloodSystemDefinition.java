package tnt.tarkovcraft.medsystem.common.blood_system.assignment;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.ExtraCodecs;
import net.minecraft.util.RandomSource;
import net.minecraft.util.random.WeightedList;
import net.minecraft.util.random.WeightedList.Builder;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import org.joml.Vector2fc;
import tnt.tarkovcraft.core.common.attribute.AttributeSystem;
import tnt.tarkovcraft.core.common.data.number.NumberProvider;
import tnt.tarkovcraft.core.common.util.AttributeNumber;
import tnt.tarkovcraft.core.util.Cached;
import tnt.tarkovcraft.core.util.Codecs;
import tnt.tarkovcraft.medsystem.MedicalSystem;
import tnt.tarkovcraft.medsystem.common.blood_system.BloodSystemManager;
import tnt.tarkovcraft.medsystem.common.blood_system.effect.BloodLevelEffectHolder;
import tnt.tarkovcraft.medsystem.common.effect.BloodLossStatusEffect;
import tnt.tarkovcraft.medsystem.common.health.HealthBloodSystemIntegration;
import tnt.tarkovcraft.medsystem.common.health.HealthContainer;
import tnt.tarkovcraft.medsystem.common.health.HealthSystem;
import tnt.tarkovcraft.medsystem.common.init.MedSystemAttributes;
import tnt.tarkovcraft.medsystem.common.init.MedSystemDataAttachments;

public final class EntityBloodSystemDefinition {
   public static final Codec<EntityBloodSystemDefinition> CODEC = RecordCodecBuilder.<EntityBloodSystemDefinition>create(
      instance -> instance.group(
            Codecs.hashSet(BuiltInRegistries.ENTITY_TYPE.byNameCodec()).fieldOf("entity_types").forGetter(t -> t.entityTypes),
            Codec.unboundedMap(Identifier.CODEC, ExtraCodecs.NON_NEGATIVE_INT).fieldOf("blood_types").forGetter(t -> t.bloodTypes),
            NumberProvider.POSITIVE_FLOAT.fieldOf("blood_volume").forGetter(t -> t.bloodVolume),
            AttributeNumber.CODEC.fieldOf("blood_recovery").forGetter(t -> t.bloodRecovery),
            UnconsciousModeSettings.CODEC.optionalFieldOf("unconscious_mode", UnconsciousModeSettings.DEFAULT).forGetter(t -> t.unconsciousMode),
            EntityShockData.CODEC.optionalFieldOf("shock_attributes", EntityShockData.DEFAULT).forGetter(t -> t.shockData),
            BloodEffectAttributes.CODEC.optionalFieldOf("blood_effect_attributes", BloodEffectAttributes.DEFAULT).forGetter(t -> t.effectAttributes),
            Codecs.list(BloodLevelEffectHolder.CODEC).optionalFieldOf("effect_list", Collections.emptyList()).forGetter(t -> t.effectList)
         )
         .apply(instance, EntityBloodSystemDefinition::new)
   );
   public static final int BLOOD_COLOR = 11665408;
   private final Set<EntityType<?>> entityTypes;
   private final Map<Identifier, Integer> bloodTypes;
   private final float bloodVolume;
   private final AttributeNumber bloodRecovery;
   private final UnconsciousModeSettings unconsciousMode;
   private final EntityShockData shockData;
   private final BloodEffectAttributes effectAttributes;
   private final List<BloodLevelEffectHolder> effectList;
   private final WeightedList<Identifier> weightedBloodTypes;
   private final Cached<EntityDimensions> unconsciousModeDimensions;

   private EntityBloodSystemDefinition(
      Set<EntityType<?>> entityTypes,
      Map<Identifier, Integer> bloodTypes,
      float bloodVolume,
      AttributeNumber bloodRecovery,
      UnconsciousModeSettings unconsciousMode,
      EntityShockData shockData,
      BloodEffectAttributes effectAttributes,
      List<BloodLevelEffectHolder> effectList
   ) {
      this.entityTypes = entityTypes;
      this.bloodTypes = bloodTypes;
      this.bloodVolume = bloodVolume;
      this.bloodRecovery = bloodRecovery;
      this.unconsciousMode = unconsciousMode;
      this.shockData = shockData;
      this.effectAttributes = effectAttributes;
      this.effectList = effectList;
      this.weightedBloodTypes = this.computeWeightedList();
      this.unconsciousModeDimensions = Cached.create(() -> {
         Vector2fc dims = this.unconsciousMode.dimensions();
         return EntityDimensions.scalable(dims.x(), dims.y());
      });
   }

   public static EntityBloodSystemDefinition forEntity(LivingEntity entity) {
      EntityType<?> type = entity.getType();
      return forEntityType(type);
   }

   public static EntityBloodSystemDefinition forEntityType(EntityType<?> type) {
      BloodSystemManager manager = MedicalSystem.BLOOD_SYSTEM;
      return manager.getAssignment(type);
   }

   public void bind(LivingEntity entity) {
      EntityType<?> type = entity.getType();
      Identifier bloodType = (Identifier)this.weightedBloodTypes.getRandomOrThrow(entity.getRandom());
      EntityBloodSystem system = new EntityBloodSystem(type, bloodType, this.getMaxBloodVolume());
      entity.setData(MedSystemDataAttachments.BLOOD_SYSTEM, system);
      this.bindListeners(system, entity);
   }

   public void bindListeners(EntityBloodSystem bloodSystem, LivingEntity entity) {
      if (HealthSystem.hasCustomHealth(entity)) {
         HealthContainer container = HealthContainer.getAttached(entity);
         bloodSystem.eventHandler.subscribe(new HealthBloodSystemIntegration(container));
      }
   }

   public void applyEffects(LivingEntity entity, ServerLevel level, EntityBloodSystem bloodSystem) {
      float bloodVolume = bloodSystem.getBloodVolume();

      for (BloodLevelEffectHolder effect : this.effectList) {
         if (effect.canApply(bloodVolume)) {
            effect.apply(entity, level, bloodSystem);
         }
      }
   }

   public float getMaxBloodVolume() {
      return this.bloodVolume;
   }

   public boolean canUseBloodType(Identifier bloodType) {
      return this.bloodTypes.containsKey(bloodType);
   }

   public boolean isUnconsciousModeAllowed() {
      return this.unconsciousMode.enabled();
   }

   public boolean hasSpecialUnconsciousPoseRenderer() {
      return this.unconsciousMode.hasCustomPose();
   }

   public boolean isDownedStateEnabled() {
      return this.isUnconsciousModeAllowed() && this.unconsciousMode.downedOnDeath();
   }

   public Map<String, Float> calculateUnconsciousPose(RandomSource random) {
      List<String> animationFields = this.unconsciousMode.animationFields();
      if (animationFields.isEmpty()) {
         return Collections.emptyMap();
      }

      Map<String, Float> metadata = new HashMap<>();
      animationFields.forEach(field -> metadata.put(field, random.nextFloat()));
      return metadata;
   }

   public EntityDimensions getDimensionsForUnconsciousMode() {
      return (EntityDimensions)this.unconsciousModeDimensions.get();
   }

   public boolean isInPain(float bloodPct) {
      return this.effectAttributes.isInPain(bloodPct);
   }

   public float getGrayscaleAmount(float bloodPct) {
      return this.effectAttributes.getGrayscale(bloodPct);
   }

   public boolean shouldApplyGrayscaleShader(float bloodPct) {
      return this.effectAttributes.shouldApplyGrayscale(bloodPct);
   }

   public float getBloodRegenerationAmount(LivingEntity entity) {
      return (float)this.bloodRecovery.getValue(entity);
   }

   public BloodLossStatusEffect.Stage getBloodLossStage(float percentage) {
      return this.effectAttributes.getBloodLossStage(percentage);
   }

   public List<Identifier> getAvailableBloodTypes() {
      return this.bloodTypes.entrySet().stream().filter(entry -> entry.getValue() > 0).map(Entry::getKey).toList();
   }

   public Collection<EntityType<?>> getEntityTypes() {
      return this.entityTypes;
   }

   public float getShockRecoveryRate(boolean inShock) {
      float multiplier = inShock ? this.shockData.inShockRecoveryMultiplier() : 1.0F;
      return this.shockData.recoveryRate() * multiplier;
   }

   public float getReceivedShockValue(float incoming, LivingEntity entity) {
      return AttributeSystem.getFloatValue(entity, MedSystemAttributes.SHOCK_SCALE, 1.0F) * (incoming * this.shockData.receptionMultiplier());
   }

   public boolean isInShock(boolean unconscious, float value) {
      return this.shockData.isUnconscious(unconscious, value);
   }

   private WeightedList<Identifier> computeWeightedList() {
      Builder<Identifier> builder = WeightedList.builder();
      this.bloodTypes.forEach(builder::add);
      return builder.build();
   }
}
